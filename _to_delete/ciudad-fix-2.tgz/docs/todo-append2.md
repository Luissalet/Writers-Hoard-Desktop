
## Revisión de Luis (2026-08-15, misma tarde)

Tres preguntas suyas, las tres con causa real:

**1 · «¿Por qué "río" añade un foso? Eso debería ser "foso".»** El foso se echaba
a suertes (0,66) al final de la fábrica militar, o sea por detrás del río, del
litoral y del bucle de torres —que gasta un número de sorteos que depende de la
LONGITUD del anillo—. Todo el plano sale de un hilo de números en orden de
llamada, así que el interruptor «Río» barajaba el hilo entero. Medido: movía el
foso en **61 de 120** planos, y lo AÑADÍA en **38 de 200**, que es imposible por
geometría (el agua sólo puede quitar perímetro donde cavar). Ahora el foso
decide con su propio hilo (`city:moat`) y es un parámetro suyo (`moat?: boolean`)
con interruptor propio en la ficha. El sorteo del hilo principal se sigue
gastando donde estaba, a propósito: quitarlo desplazaba barrios, plazas y casas
y bajaba la fachada del 92,3 % al 89,3 % sin que nada estuviera peor, sólo
distinto. **Poner río añade foso: 0 de 200.**

**2 · «¿Por qué hay murallas en el agua del río?»** El lienzo se clipaba contra
el mar pero nunca contra el cauce: en una ciudad de cruce salían **11 de 41**
vértices de sillería plantados en mitad del canal. Una muralla que cruza su río
se cierra con una PUERTA DE AGUA —dos torres y la cadena entre ellas—, no con
piedra sobre el agua. `Fortification.wet` marca los vértices mojados; el anillo
sigue entero en el modelo (puertas, avenidas y radio se calculan sobre él) y el
dibujante se salta ese tramo y sus almenas, con torre en la última piedra seca
de cada orilla.

**3 · «Ni río ni costa deberían ser opciones; lo otro depende de dónde la
coloques.»** Tiene razón y era una contradicción a un clic: se le podía apagar el
río a una ciudad fluvial y ponerle mar a una de tierra adentro, y el plano
contradecía el mapa. Fuera los interruptores de **Río** y **Costa**; dentro
**Catedral** (`cathedral?: boolean`) y **Foso**. Lo que se elige es lo que mandó
construir su señor; el emplazamiento lo pone el atlas.

Y lo que preguntaba de arrastrar el pueblo YA funciona: mover Quliiti nueve
celdas cambia `río=true costa=true modo=crossing` → `río=false costa=false
modo=bank`, porque `cityParamsFor` re-mide el suelo desde `settlementCellCenter`
y la caché de planos va por `geographyContentKey`. La edición existe
(`kind: 'move'` en `core/edits.ts`).

- `city-quality`: **32/32 en verde** (fachada 92,3 %, peor ciudad 90,0 %).
- `city-ground-context`: **83/83 en verde** (eran 75). Nuevas: puerta de agua con
  torre en cada orilla, «poner río nunca añade foso», el foso se fuerza y se
  quita sin mover una manzana ni una casa ni una calle, y la catedral es una
  decisión del pueblo.

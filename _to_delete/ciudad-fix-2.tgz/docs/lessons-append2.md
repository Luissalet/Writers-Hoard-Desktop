
## #52 — Un interruptor que baraja el hilo de números cambia cosas que no menciona
**Fecha:** 2026-08-15
**Contexto:** El plano urbano entero sale de un `Rng` en orden de llamada, así
que cualquier rama condicional que consuma un sorteo desplaza a todas las de
detrás. El interruptor «Río» de la ficha movía el FOSO en 61 de 120 planos —y en
38 de 200 lo AÑADÍA, que es imposible por geometría— además de los lóbulos, los
barrios y las plazas. Luis lo vio antes que cualquier banco: «¿por qué "río"
añade un foso?».
**Regla:** Una decisión que el usuario puede encender y apagar necesita su propio
hilo derivado de la semilla (`createRng(seed, 'city:moat')`). Y al sacarla del
hilo común hay que SEGUIR GASTANDO el sorteo que ocupaba, o el arreglo de una
cosa cambia todas las demás: quitarlo bajó la fachada a espacio público del
92,3 % al 89,3 % sin que nada estuviera peor, sólo distinto.
**Corolario, y es de Luis:** lo que se ofrece como opción tiene que ser lo que
alguien DECIDIÓ, no dónde está la cosa. Murallas, ciudadela, catedral y foso son
opciones; río y costa son el sitio, y ofrecerlos permitía apagarle el río a una
ciudad fluvial y contradecir el mapa a un clic de distancia. Si el emplazamiento
cambia —mover el pueblo— el plano se re-mide solo.

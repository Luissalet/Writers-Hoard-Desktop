
### 11.2 · Lo que se elige y lo que viene del sitio (2026-08-15)

`CityParams` separa ahora las dos familias. **Del sitio** (las pone el atlas y
sólo cambian si el pueblo se mueve): `river`, `coast`, `riverCourse`,
`shoreLine`, `urbanCenter`, `riverMode`, `slopeDir`, `roadBearings`. **De quien
manda** (interruptores en la ficha): `walls`, `citadel`, `cathedral`, `moat`.
La ficha ya no ofrece «Río» ni «Costa»: apagarle el río a una ciudad fluvial
producía un plano que contradecía el mapa a un clic de distancia.

Cada decisión encendible tiene su propio hilo de números
(`createRng(seed, 'city:moat')`) **y sigue gastando el sorteo que ocupaba en el
hilo principal**. Lo primero hace que el interruptor no dependa de nada de
arriba; lo segundo, que arreglarlo no mueva barrios, plazas ni casas.

`Fortification.wet` marca los vértices del lienzo que caen sobre el cauce. El
anillo sigue entero —puertas, avenidas y radio se calculan sobre él— y el
dibujante se salta ese tramo y sus almenas: una muralla que cruza su río se
cierra con una puerta de agua, dos torres y una cadena, no con sillería sobre el
agua.

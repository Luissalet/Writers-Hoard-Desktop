# Worldgen 2D: la ciudad consciente, segunda pasada

**Started:** 2026-08-15

Las ciudades ya recibían su contexto (pasada del 14) pero el resultado «iba
regular». Medido sobre el mundo por defecto del banco, ANTES de tocar nada:

- 32 ciudades con cauce medido · **32 en modo orilla · CERO puentes en todo el
  planeta**. La rama de cruce era código muerto.
- **78 m de media** entre la casa más cercana y su propia orilla. Ninguna de las
  32 tenía frente de agua, muelle ni almacenes al río.
- Casco desplazado hasta **0,9 R0** del ancla del atlas.
- El plano de recorte de la orilla se alejaba hasta **13,7 u (55 m)** del cauce
  real en un río curvo.
- El canal del plano se abría de **0,6× a 1,38×** su ancho a lo largo del
  pueblo, mientras `Map2D` repinta encima el vector del mundo de ancho CONSTANTE.

## Especificación verificable

- [x] Una ciudad fluvial se asoma a su río: primera fachada a menos de 14 u de
      la orilla, con muelle y molino.
- [x] Un mundo con ríos tiene ciudades de cruce, y cada una levanta su puente.
- [x] El cauce del plano tiene el mismo ancho que el vector del mapa (±12 %).
- [x] El emplazamiento no cambia según haya llegado o no la geografía humana.
- [x] Una ciudad amurallada conserva su muralla tras el recorte de orilla, y
      `radius` describe todo el plano.
- [x] La caché de planos va por CONTENIDO, no por identidad de objeto.

## Plan

- [x] Medir el estado real con sondas nuevas (`city-bank-probe`, `city-look`,
      `city-one`) sobre el mundo por defecto, no sobre un caso de laboratorio.
- [x] Separar CANAL (hidrológico) de RIBERA (urbano) en `generate.ts`.
- [x] Recortar la orilla por el cauce con signo, no por su plano medio.
- [x] Criterio de cruce por luz de vano en metros + absorción por el casco.
- [x] Podar el componente conexo DESPUÉS del recorte, y también sin costa.
- [x] Canal de ancho constante; tablero de puente que apea en tierra.
- [x] Embarcadero de barca donde el camino muere en el agua.
- [x] Caché por `worldContentKey` + `geographyContentKey`; `tileCoverage` en vez
      de `tilePlanDebug`; un solo pase de río a escala de calle.
- [x] Regresiones nuevas en `city-ground-context.ts` y bancos verdes.

## Review — los números, después

| medida | antes | después |
| --- | --- | --- |
| hueco casa→orilla (media, 32 ciudades) | 78 m | **18 m** |
| ciudades de cruce / con cauce | 0 / 32 | **7 / 32** |
| puentes en el mundo | 0 | **20** |
| muelles y embarcaderos | 18 | **55** |
| desfase plano de corte ↔ cauce | hasta 55 m | **0** (campo con signo) |
| ancho del canal a lo largo del pueblo | 0,60–1,38× | **0,965–1,035×** |
| suelo urbano sellado (`gate-pinch-probe`) | 7,0 % | **6,5 %** |
| fachada a espacio público (`city-quality`) | 92,4 % (peor 89,6) | 92,3 % (**peor 90,0**) |

- `harness/city-quality.ts`: **32/32 en verde**, incluidos «0 vados de 14
  cruces» y el determinismo byte a byte.
- `harness/city-ground-context.ts`: **75/75 en verde** (eran 61). Nuevas: la
  ciudad se asoma a su río, ancho de canal igual al del atlas, muralla y radio
  tras el recorte, emplazamiento independiente de la geografía humana, caché por
  contenido en sus dos caras, y «un mundo con ríos tiene cruces».
- `tile-ink`, `map2d-layer-contract`, `display-tile-plan`, `road-overlay`,
  `satellite-handoff`, `satellite-lod-cohesion`, `river-hierarchy`,
  `geography-client`, `tile-service`, `places-policy`, `gate-blind-probe`,
  `gate-pinch-probe`, `city-shape`: todos en verde.
- `npx tsc -p tsconfig.app.json`: cero errores en `worldgen`. `eslint` sobre los
  ficheros tocados: mismo recuento que antes de la pasada (ruido preexistente
  del plugin de React, no de este trabajo).
- Trabajo local sobre `main`, sin rama, staging, commit ni push.

---

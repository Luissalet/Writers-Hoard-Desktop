
## #51 — Una constante afinada contra una magnitud falsa se rompe al arreglar la magnitud
**Fecha:** 2026-08-15
**Contexto:** Durante años el ancho del río en el plano urbano fue una licencia
del dibujante (`PLAN_RIVER_SQUEEZE = 0,10`, ≈0,09·radio). Todas las reglas de
«aquí no se construye» se escribieron como MÚLTIPLOS de ese ancho: 1,5× para la
plaza, 1,6× para el foso, 0,8× para el edificio, 2× para separar puentes, 1,9×
para el tablero, 5× para el molino. Al pasar el ancho a físico —correcto, porque
`Map2D` repinta encima el vector del mundo— cada uno de esos múltiplos creció con
el caudal: un río de 200 m esterilizaba una franja de 600 m dentro de una ciudad
de 1 km. El resultado medido: 78 m de media entre la casa más cercana y su propia
orilla, en las 32 ciudades fluviales del mundo, y ni un muelle. Todos los bancos
seguían en verde porque medían sobre ciudades SINTÉTICAS, donde el ancho no había
cambiado.
**Regla:** Cuando una magnitud pasa de ser una licencia de dibujo a ser física,
hay que auditar TODA constante expresada como múltiplo suyo. Y, mejor, no
escribirlas así: separar la magnitud del mundo (el canal, hidrológico) de la
magnitud del oficio (el muelle y la vega, urbanas, en unidades absolutas). Una
distancia de retranqueo no escala con el caudal — un muelle mide diez metros
tanto en el Sena como en un arroyo.
**Corolario:** Un umbral de decisión que compara una magnitud FÍSICA con el
TAMAÑO DEL DIBUJO (`ancho ≤ 0,64·R0`) no es un criterio, es una coincidencia de
escala. Un puente se mide en metros de luz; con el criterio anterior el planeta
entero se quedó sin un solo puente y el banco no lo vio porque sólo miraba dos
ciudades de su propio mundo de pruebas, las dos sobre estuarios de 600 m.


## Mover deja de ser el gesto por defecto (Luis, 2026-08-15)

**Síntoma:** «cada vez que clico se puede arrastrar una ciudad, ruina, letrero…
No paro de moverlas sin querer al moverme por el mapa.»

**Causa:** `movableAt` no pedía modo ninguno. Bastaba con que el puntero cayera a
menos de diez píxeles de un pueblo, una ruina o un rótulo para que el arrastre se
lo llevara en vez de desplazar el mapa. El comentario que lo defendía decía que
«no hace falta ningún modo, el impacto es de diez píxeles»: falso en cuanto el
mapa se llena: la mitad de su superficie son topónimos y puntos. Y cada arrastre
accidental es una edición `kind: 'move'` guardada, que sobrevive a cerrar el
mundo.

**Arreglo:** mover es ahora su propia herramienta — `PaintMode` `'move'`,
«Mover», en el grupo de Punto junto a Punto, Camino y Frontera. `movableAt`
devuelve `null` con cualquier otra herramienta, y de ahí cuelga todo lo demás:
el cursor de mover, el fantasma que sigue la mano y el `drop`. `brushing` la
excluye —mover no deja tinta— así que sobre suelo vacío el arrastre sigue siendo
la cámara y con la herramienta puesta el mapa se sigue pudiendo pasear.

- `PaintMode` += `'move'`; botón en `GROUPS` (grupo Punto).
- `Map2D`: guarda en `movableAt`, `brushing` excluye `move`, rótulo de ayuda
  propio en la barra inferior (`worldgen.map.moveToolHint`).
- La chuleta del «?» ya no promete el gesto a secas: ahora dice «con la
  herramienta Mover».
- i18n es/en en paridad: `paint.mode.move`, `paint.mode.move.hint`,
  `map.moveToolHint`, y `map.moveHint` reescrito.

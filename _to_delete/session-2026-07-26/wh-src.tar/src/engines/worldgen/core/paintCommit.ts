// ============================================
// Turning a gesture into an edit
// ============================================
// One brush, three views. The carta, the satellite map and the 3D world all
// have to produce the SAME edit for the same stroke, or the reader discovers
// that a river drawn in one place is not the river they get back — and the
// storage contract (seed + params + edit list) means a divergence here is not a
// display bug, it is a corrupted world.
//
// So the translation from "a list of world cells the pointer passed through"
// to "a WorldEdit" lives here, once, and every view calls it. The views keep
// only what is genuinely theirs: how a screen point becomes a world cell.

import {
  editKey, type EditTarget, type LandOp, type Pt, type TerrainOp, type WorldEdit,
} from './edits';
import type { HumanGeography, SettlementRank } from './settlements';
import type { BiomeId, RuinKind, WorldData } from './types';

/**
 * Everything the commit needs to know about the brush.
 *
 * Structural, not the UI's `PaintTool` type: `core` may not import from
 * `components`, and the brush box is free to carry fields — a colour swatch, a
 * preview — that have nothing to do with what gets stored.
 */
export interface PaintSpec {
  mode: string;
  terrainOp: TerrainOp;
  landOp: LandOp;
  biome: BiomeId;
  radius: number;
  strength: number;
  softness: number;
  riverWidth: number;
  marker: 'settlement' | 'ruin';
  ruin: RuinKind;
  rank: SettlementRank;
  labelStyle: 'region' | 'water' | 'range' | 'settlement' | 'note';
  labelText: string;
  roadMajor: boolean;
}

export interface CommitContext {
  /** Alt was held: the road brush erases instead of drawing. */
  alt?: boolean;
  /** What generated object is under a point — only the rename/remove brushes need it. */
  pickGenerated?: (x: number, y: number) => { target: EditTarget; key: string; name: string } | null;
  /** How the reader is asked for a new name. Injectable so tests do not open a prompt. */
  askName?: (current: string) => string | null;
}

/**
 * The whole gesture as one edit (or none).
 *
 * Returns the edit rather than calling a callback so the caller decides whether
 * it is one undo step or part of a group — a mirrored sculpt stroke is four
 * edits and one Ctrl+Z.
 */
export function commitPaintStroke(
  p: PaintSpec,
  pts: Pt[],
  ctx: CommitContext = {},
): WorldEdit | null {
  if (!pts.length) return null;
  const stroke = { pts, radius: p.radius, strength: p.strength, softness: p.softness };
  const at = pts[pts.length - 1];

  switch (p.mode) {
    case 'terrain':
      return { kind: 'terrain', op: p.terrainOp, stroke };
    case 'land':
      return { kind: 'land', op: p.landOp, stroke };
    case 'biome':
      return { kind: 'biome', biome: p.biome, stroke };
    case 'river':
      return pts.length >= 2 ? { kind: 'river', pts, width: p.riverWidth } : null;
    case 'erase':
      return { kind: 'eraseMarkers', x: pts[0].x, y: pts[0].y, radius: p.radius };
    case 'marker':
      return p.marker === 'ruin'
        ? { kind: 'marker', marker: 'ruin', x: at.x, y: at.y, ruin: p.ruin }
        : { kind: 'marker', marker: 'settlement', x: at.x, y: at.y, rank: p.rank };
    case 'label': {
      const text = p.labelText.trim();
      return text ? { kind: 'label', x: at.x, y: at.y, text, style: p.labelStyle } : null;
    }
    case 'road':
      if (ctx.alt) {
        return { kind: 'eraseRoads', x: pts[0].x, y: pts[0].y, radius: Math.max(2, p.radius) };
      }
      return pts.length >= 2 ? { kind: 'road', pts, major: p.roadMajor } : null;
    case 'rename':
    case 'remove': {
      const target = ctx.pickGenerated?.(at.x, at.y);
      if (!target) return null;
      if (p.mode === 'remove') return { kind: 'remove', target: target.target, key: target.key };
      const next = ctx.askName
        ? ctx.askName(target.name)
        : window.prompt(`Nuevo nombre para «${target.name}»`, target.name);
      const trimmed = next?.trim();
      if (!trimmed || trimmed === target.name) return null;
      return { kind: 'rename', target: target.target, key: target.key, name: trimmed };
    }
    default:
      return null;
  }
}

/**
 * What generated object is at a world point, and its stable key.
 *
 * Ordered smallest-target-first: a settlement sits inside a realm and often
 * inside a named plain as well, and the reader who clicked on a dot meant the
 * dot. Areas are only offered when nothing pointlike is close.
 *
 * `tolerance` is in world cells and is the caller's job, because "close enough"
 * means sixteen screen pixels and only the view knows how many cells that is.
 */
export function pickGeneratedAt(
  world: WorldData,
  geo: HumanGeography | null | undefined,
  wx: number,
  wy: number,
  tolerance: number,
): { target: EditTarget; key: string; name: string } | null {
  if (!geo) return null;
  const tol = Math.max(2, tolerance);
  const dist = (ax: number, ay: number): number => {
    let dx = Math.abs(ax - wx);
    if (dx > world.width / 2) dx = world.width - dx;
    return Math.hypot(dx, ay - wy);
  };

  let best: { target: EditTarget; key: string; name: string; d: number } | null = null;
  const offer = (target: EditTarget, key: string, name: string, d: number, reach: number): void => {
    if (d > reach) return;
    if (!best || d < best.d) best = { target, key, name, d };
  };

  for (const st of geo.settlements) {
    offer('settlement', editKey('settlement', st.x, st.y), st.name, dist(st.x, st.y), tol);
  }
  for (const ru of geo.ruins) {
    offer('ruin', editKey('ruin', ru.x, ru.y), ru.name, dist(ru.x, ru.y), tol);
  }
  if (best) return best;
  for (const f of geo.features) {
    offer('feature', editKey('feature', f.x, f.y, `${f.kind}:`), f.name,
      dist(f.x, f.y), Math.max(tol, f.extent));
  }
  if (best) return best;

  const ix = (((Math.round(wx) % world.width) + world.width) % world.width);
  const iy = Math.min(world.height - 1, Math.max(0, Math.round(wy)));
  const realmId = geo.realmOf[iy * world.width + ix];
  const realm = geo.realms.find((q) => q.id === realmId);
  if (realm) return { target: 'realm', key: editKey('realm', 0, 0, `${realm.id}:`), name: realm.name };
  return null;
}

/**
 * Does this brush move ground?
 *
 * The distinction matters to every 3D view: a terrain or coast stroke is
 * previewed live on the height texture and committed on release, while a biome,
 * river or marker stroke is only a list of cells until the button comes up.
 */
export function isSculptMode(mode: string): boolean {
  return mode === 'terrain' || mode === 'land';
}

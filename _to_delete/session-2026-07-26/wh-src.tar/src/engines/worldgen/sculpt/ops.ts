// ============================================
// Sculpt — the brushes themselves
// ============================================
// There used to be two implementations of every brush: one in `applyEdits`, which
// is the truth, and one in the live view, which is what you actually see while
// you drag. They were written to agree and they did not — `flatten` levelled to
// the mean of the whole stroke when replayed and to a 3×3 neighbourhood while you
// were drawing it, which is a different tool wearing the same name.
//
// So there is now ONE implementation, here, and both callers go through it. The
// live preview is not "written to match" the committed edit; it *is* the
// committed edit, run over the part of the stroke that exists so far. Divergence
// is not a bug that got fixed, it is a bug that can no longer be written.
//
// Everything in this file obeys three rules, because the storage contract depends
// on them: a brush is a pure function of (seed, stroke, the field before the
// stroke); it never reads its own output; and it never consults anything that is
// not in the edit list.

import type { Stroke, TerrainOp, LandOp } from '../core/edits';
import { SphereNoise } from '../core/noise';

// ---------------------------------------------------------------------------
// Falloff
// ---------------------------------------------------------------------------

/**
 * The shape of the brush's edge.
 *
 * Sculpting programs put this behind a curve editor and it is the control people
 * reach for most after size: a soft round falloff makes hills, a sharp one makes
 * ridges and cliffs, a flat one makes plateaus with a wall round them. Four named
 * curves cover what a curve editor is used for without inventing a widget.
 */
export type Falloff = 'smooth' | 'sharp' | 'linear' | 'flat';

/** f goes 1 at the centre to 0 at the rim; the curve reshapes it. */
export function shapeFalloff(f: number, curve: Falloff): number {
  switch (curve) {
    case 'linear': return f;
    case 'sharp': return f * f * f;
    case 'flat': return f > 0.02 ? 1 : 0;
    default: return f * f * (3 - 2 * f);
  }
}

// ---------------------------------------------------------------------------
// Coverage
// ---------------------------------------------------------------------------

/**
 * How much of the brush landed on each cell.
 *
 * Two shapes implement this: a compact rectangle (what a committed edit builds,
 * once) and a world-sized scratch buffer (what a live drag keeps, so extending a
 * stroke costs one segment instead of re-rasterising the whole path — the
 * difference between a stroke that stays at 60 fps and one that degrades as you
 * draw it).
 */
export interface Brush {
  x0: number; y0: number; w: number; h: number;
  /** Coverage at a wrapped world index. */
  cover(i: number): number;
  each(fn: (i: number, cover: number, x: number, y: number) => void): void;
  /** True when nothing is covered. */
  readonly empty: boolean;
}

/** The heights as they were before this stroke started. */
export interface BaseField {
  at(i: number): number;
}

class CompactBrush implements Brush {
  x0: number; y0: number; w: number; h: number;
  private m: Float32Array;
  private W: number;
  private H: number;
  empty: boolean;

  constructor(m: Float32Array, x0: number, y0: number, w: number, h: number, W: number, H: number) {
    this.m = m; this.x0 = x0; this.y0 = y0; this.w = w; this.h = h; this.W = W; this.H = H;
    let any = false;
    for (let k = 0; k < m.length; k++) if (m[k] > 0.002) { any = true; break; }
    this.empty = !any;
  }

  cover(i: number): number {
    const W = this.W;
    const x = i % W, y = (i / W) | 0;
    for (let ux = x; ux < this.x0 + this.w; ux += W) {
      if (ux >= this.x0 && y >= this.y0 && y < this.y0 + this.h) {
        return this.m[(y - this.y0) * this.w + (ux - this.x0)];
      }
    }
    for (let ux = x - W; ux >= this.x0; ux -= W) {
      if (ux < this.x0 + this.w && y >= this.y0 && y < this.y0 + this.h) {
        return this.m[(y - this.y0) * this.w + (ux - this.x0)];
      }
    }
    return 0;
  }

  each(fn: (i: number, cover: number, x: number, y: number) => void): void {
    const W = this.W, H = this.H;
    for (let gy = 0; gy < this.h; gy++) {
      const wy = this.y0 + gy;
      if (wy < 0 || wy >= H) continue;
      for (let gx = 0; gx < this.w; gx++) {
        const c = this.m[gy * this.w + gx];
        if (c <= 0.002) continue;
        const wx = (((this.x0 + gx) % W) + W) % W;
        fn(wy * W + wx, c, wx, wy);
      }
    }
  }
}

/**
 * Rasterise a stroke into a coverage mask over its own bounding box.
 *
 * The mask is the MAXIMUM of the per-sample falloffs rather than their sum. That
 * distinction is the whole difference between a brush and a stain: summing makes
 * the paint darker wherever the pointer happened to move slowly, and every
 * hand-rolled paint tool has that bug once.
 */
export function strokeMask(stroke: Stroke, W: number, H: number): Brush | null {
  const r = Math.max(0.5, stroke.radius);
  const soft = Math.min(1, Math.max(0, stroke.softness ?? 0.6));
  const curve = stroke.curve ?? 'smooth';
  if (!stroke.pts.length) return null;

  // Bounding box in unwrapped coordinates around the first point, so a stroke
  // across the seam stays contiguous.
  const ax = stroke.pts[0].x;
  const un = stroke.pts.map((p) => {
    let x = p.x;
    while (x - ax > W / 2) x -= W;
    while (x - ax < -W / 2) x += W;
    return { x, y: p.y };
  });
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const p of un) {
    minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x);
    minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
  }
  const pad = Math.ceil(r) + 2;
  const x0 = Math.floor(minX) - pad;
  const y0 = Math.max(0, Math.floor(minY) - pad);
  const x1 = Math.ceil(maxX) + pad;
  const y1 = Math.min(H - 1, Math.ceil(maxY) + pad);
  const w = x1 - x0 + 1, h = y1 - y0 + 1;
  if (w <= 0 || h <= 0 || w > W * 2) return null;
  const mask = new Float32Array(w * h);

  const inner = r * (1 - soft);
  for (let k = 0; k < un.length; k++) {
    const a = un[k];
    const b = un[Math.min(un.length - 1, k + 1)];
    // Walk the segment at half-cell steps so a fast drag leaves no gaps.
    const segLen = Math.hypot(b.x - a.x, b.y - a.y);
    const steps = Math.max(1, Math.ceil(segLen * 2));
    for (let s = 0; s < steps; s++) {
      const t = s / steps;
      stampDisc(
        a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, r, inner, curve,
        (gx, gy, v) => {
          if (gx < x0 || gx > x1 || gy < y0 || gy > y1) return;
          const mi = (gy - y0) * w + (gx - x0);
          if (v > mask[mi]) mask[mi] = v;
        },
      );
    }
  }
  return new CompactBrush(mask, x0, y0, w, h, W, H);
}

/**
 * The coverage an op actually wants.
 *
 * Every brush but one paints along the whole path. `grab` does not: its disc is a
 * handle you grip once, and sweeping it would smear the terrain along the drag
 * instead of carrying it.
 */
export function maskForOp(op: TerrainOp, stroke: Stroke, W: number, H: number): Brush | null {
  if (op === 'grab' && stroke.pts.length > 1) {
    return strokeMask({ ...stroke, pts: stroke.pts.slice(0, 1) }, W, H);
  }
  return strokeMask(stroke, W, H);
}

/** One disc of paint. The single place the falloff is evaluated. */
function stampDisc(
  cx: number, cy: number, r: number, inner: number, curve: Falloff,
  put: (gx: number, gy: number, v: number) => void,
): void {
  const gx0 = Math.floor(cx - r), gx1 = Math.ceil(cx + r);
  const gy0 = Math.floor(cy - r), gy1 = Math.ceil(cy + r);
  for (let gy = gy0; gy <= gy1; gy++) {
    for (let gx = gx0; gx <= gx1; gx++) {
      const d = Math.hypot(gx - cx, gy - cy);
      if (d > r) continue;
      const f = d <= inner ? 1 : 1 - (d - inner) / Math.max(1e-6, r - inner);
      put(gx, gy, shapeFalloff(f, curve));
    }
  }
}

// ---------------------------------------------------------------------------
// The live stroke
// ---------------------------------------------------------------------------

/** One arm of a gesture: the stroke itself, or one of its mirror images. */
interface Arm {
  pts: { x: number; y: number }[];
  stroke: Stroke;
  cov: Float32Array;
  /** Everything this arm has ever painted. */
  x0: number; y0: number; x1: number; y1: number;
  /** Just what the latest pointer move painted. */
  sx0: number; sy0: number; sx1: number; sy1: number;
  map: (p: { x: number; y: number }) => { x: number; y: number };
}

export interface GestureSpec {
  kind: 'terrain' | 'land';
  op: TerrainOp | LandOp;
  radius: number;
  strength: number;
  softness: number;
  curve?: Falloff;
  /** Mirror about the prime meridian, the equator, or both. */
  mirrorX?: boolean;
  mirrorY?: boolean;
}

export interface DirtyRect { x0: number; y0: number; x1: number; y1: number }

/**
 * One drag, previewed exactly — including its mirror images.
 *
 * Two world-sized scratch buffers (the heights before the gesture, and a flag for
 * which of them are valid) plus one coverage buffer per arm are allocated when the
 * button goes down. In exchange, extending a stroke costs one segment of
 * rasterisation plus one pass over the dirty rectangle — not a re-rasterisation of
 * the whole path, which is quadratic and turns a long stroke into a slideshow.
 *
 * Every extend puts the field back the way it was and re-runs the WHOLE gesture.
 * That looks wasteful and is the point:
 *
 *   - `flatten`, `terrace` and `grab` are not per-cell functions. Their answer
 *     depends on the entire stroke, so applying them incrementally would give a
 *     different result from replaying them.
 *   - Mirrored arms are separate edits applied in order, and where they overlap —
 *     which is exactly what symmetry is for — the second reads what the first
 *     wrote. Restoring and re-running in the same order is the only way the
 *     preview can land on that.
 */
export class SculptGesture {
  private elev: Float32Array;
  private W: number;
  private H: number;
  private seed: string;
  private spec: GestureSpec;
  private arms: Arm[] = [];
  private base: Float32Array;
  private known: Uint8Array;
  /** The field as it was before the gesture, readable anywhere. */
  private pre: BaseField;
  /** Union of every arm's rectangle, unwrapped x. */
  private rx0 = Infinity; private ry0 = Infinity; private rx1 = -Infinity; private ry1 = -Infinity;

  constructor(elev: Float32Array, W: number, H: number, seed: string, spec: GestureSpec) {
    this.elev = elev; this.W = W; this.H = H; this.seed = seed; this.spec = spec;
    const N = W * H;
    this.base = new Float32Array(N);
    this.known = new Uint8Array(N);
    const base = this.base, known = this.known;
    this.pre = { at: (i: number) => (known[i] ? base[i] : elev[i]) };

    // Order is fixed and is the order the committed edits will be replayed in.
    const maps: ((p: { x: number; y: number }) => { x: number; y: number })[] = [(p) => p];
    if (spec.mirrorX) maps.push((p) => ({ x: W - p.x, y: p.y }));
    if (spec.mirrorY) maps.push((p) => ({ x: p.x, y: H - p.y }));
    if (spec.mirrorX && spec.mirrorY) maps.push((p) => ({ x: W - p.x, y: H - p.y }));
    for (const map of maps) {
      const pts: { x: number; y: number }[] = [];
      this.arms.push({
        pts,
        stroke: {
          pts, radius: spec.radius, strength: spec.strength,
          softness: spec.softness, curve: spec.curve,
        },
        cov: new Float32Array(N),
        x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity,
        sx0: Infinity, sy0: Infinity, sx1: -Infinity, sy1: -Infinity,
        map,
      });
    }
  }

  get dirty(): DirtyRect { return { x0: this.rx0, y0: this.ry0, x1: this.rx1, y1: this.ry1 }; }
  get points(): number { return this.arms[0].pts.length; }
  get arity(): number { return this.arms.length; }

  /** Add a pointer position and rebuild the preview. Returns the dirty rect. */
  extend(p: { x: number; y: number }): DirtyRect {
    // 1. paint the new segment into each arm's accumulated coverage, recording
    //    both what the arm has ever painted and what THIS move painted
    for (const arm of this.arms) {
      arm.sx0 = Infinity; arm.sy0 = Infinity; arm.sx1 = -Infinity; arm.sy1 = -Infinity;
    }
    for (const arm of this.arms) {
      const q = arm.map(p);
      const prev = arm.pts.length ? arm.pts[arm.pts.length - 1] : q;
      arm.pts.push(q);
      const r = Math.max(0.5, this.spec.radius);
      const inner = r * (1 - Math.min(1, Math.max(0, this.spec.softness)));
      const curve = this.spec.curve ?? 'smooth';
      if (this.spec.op === 'grab') {
        // Grab is not swept. The disc stays where the drag began — it is the
        // handle you took hold of — and the ground is pulled through it, so the
        // coverage is stamped once and never grows. Cells outside the disc are
        // read but never written, which is why the rectangle does not follow.
        if (arm.pts.length === 1) this.stamp(arm, prev.x, prev.y, r, inner, curve);
      } else {
        const segLen = Math.hypot(q.x - prev.x, q.y - prev.y);
        const steps = Math.max(1, Math.ceil(segLen * 2));
        for (let s = 0; s < steps; s++) {
          const t = s / steps;
          this.stamp(arm, prev.x + (q.x - prev.x) * t, prev.y + (q.y - prev.y) * t, r, inner, curve);
        }
        this.stamp(arm, q.x, q.y, r, inner, curve);
      }
    }

    // 2. re-run, over as little ground as the brush allows
    this.apply();
    return this.dirty;
  }

  private stamp(arm: Arm, cx: number, cy: number, r: number, inner: number, curve: Falloff): void {
    const W = this.W, H = this.H;
    stampDisc(cx, cy, r, inner, curve, (gx, gy, v) => {
      if (gy < 0 || gy >= H) return;
      const i = gy * W + (((gx % W) + W) % W);
      if (v > arm.cov[i]) arm.cov[i] = v;
      if (gx < arm.x0) arm.x0 = gx;
      if (gx > arm.x1) arm.x1 = gx;
      if (gy < arm.y0) arm.y0 = gy;
      if (gy > arm.y1) arm.y1 = gy;
      if (gx < arm.sx0) arm.sx0 = gx;
      if (gx > arm.sx1) arm.sx1 = gx;
      if (gy < arm.sy0) arm.sy0 = gy;
      if (gy > arm.sy1) arm.sy1 = gy;
      if (gx < this.rx0) this.rx0 = gx;
      if (gx > this.rx1) this.rx1 = gx;
      if (gy < this.ry0) this.ry0 = gy;
      if (gy > this.ry1) this.ry1 = gy;
    });
  }

  /** Walk a rectangle once, doing something to each wrapped index. */
  private sweep(x0: number, y0: number, x1: number, y1: number, fn: (i: number) => void): void {
    if (x1 < x0) return;
    const W = this.W, H = this.H;
    for (let gy = Math.max(0, y0); gy <= Math.min(H - 1, y1); gy++) {
      const row = gy * W;
      for (let gx = x0; gx <= x1; gx++) fn(row + (((gx % W) + W) % W));
    }
  }

  /** Put a rectangle back the way it was before the gesture started. */
  private restore(x0: number, y0: number, x1: number, y1: number): void {
    const base = this.base, known = this.known, e = this.elev;
    this.sweep(x0, y0, x1, y1, (i) => { if (known[i]) e[i] = base[i]; });
  }

  private apply(): void {
    if (this.rx1 < this.rx0) return;
    // The fast path is for ONE arm only.
    //
    // A neighbourhood brush reads cells the last move did not paint, and those
    // cells must read as they were before the gesture — which the gesture's own
    // snapshot gives for free. With mirrors it stops being free: the second arm
    // has to read what the first one wrote, and reconstructing that outside the
    // step rectangle costs more than simply redoing the whole stroke. Symmetry is
    // therefore slower per move, deliberately, because the alternative is a
    // preview that lies about the world you are saving.
    const local = opIsLocal(this.spec.op) && this.arms.length === 1;
    // A local brush only has to redo what the last move painted; a global one has
    // to redo the whole stroke, because one more point changed its answer
    // everywhere.
    const box = (a: Arm) => (local
      ? { x0: a.sx0, y0: a.sy0, x1: a.sx1, y1: a.sy1 }
      : { x0: a.x0, y0: a.y0, x1: a.x1, y1: a.y1 });

    // Every arm's ground goes back to how it started BEFORE any arm runs. Doing it
    // arm by arm would have the second arm's restore wipe the first arm's work
    // wherever a stroke crosses its own mirror.
    const boxes = this.arms.map(box);
    for (const b of boxes) {
      this.restore(b.x0, b.y0, b.x1, b.y1);
      const base = this.base, known = this.known, e = this.elev;
      this.sweep(b.x0, b.y0, b.x1, b.y1, (i) => {
        if (!known[i]) { base[i] = e[i]; known[i] = 1; }
      });
    }

    for (let k = 0; k < this.arms.length; k++) {
      const arm = this.arms[k];
      const b = boxes[k];
      if (b.x1 < b.x0) continue;
      const brush = new LiveBrush(arm.cov, b.x0, b.y0, b.x1 - b.x0 + 1, b.y1 - b.y0 + 1, this.W, this.H);
      // The field as it is RIGHT NOW, before this arm runs — which is what the
      // replay hands each edit in turn. Taken per arm and per move because the arm
      // before it may have written into the same ground.
      if (this.spec.kind === 'land') {
        const bf = local ? this.pre
          : snapshotBase(this.elev, this.W, this.H, b.x0 - 1, b.y0 - 1, brush.w + 2, brush.h + 2);
        applyLandOp(this.spec.op as LandOp, this.elev, bf, this.W, this.H, brush, arm.stroke, this.seed);
      } else {
        const op = this.spec.op as TerrainOp;
        const r = opBaseRect(op, arm.stroke, brush, this.W);
        const bf = local ? this.pre
          : snapshotBase(this.elev, this.W, this.H, r.x0, r.y0, r.w, r.h);
        applyTerrainOp(op, this.elev, bf, this.W, this.H, brush, arm.stroke, this.seed);
      }
    }
  }

  /** Put every touched cell back the way it was. */
  rollback(): void { this.restore(this.rx0, this.ry0, this.rx1, this.ry1); }

  /**
   * The gesture as edits, in the order they must be replayed.
   *
   * Mirrors are separate edits rather than one stroke with a zigzag path, because
   * a single polyline that jumps across the world would sweep a band of paint
   * between the two halves — the brush walks its own path, and the path between
   * mirror images is not somewhere the reader drew.
   */
  edits(): { kind: 'terrain' | 'land'; op: TerrainOp | LandOp; stroke: Stroke }[] {
    return this.arms
      .filter((a) => a.pts.length > 0)
      .map((a) => ({
        kind: this.spec.kind,
        op: this.spec.op,
        stroke: {
          pts: a.pts.slice(),
          radius: this.spec.radius,
          strength: this.spec.strength,
          softness: this.spec.softness,
          curve: this.spec.curve,
        },
      }));
  }
}

/** Coverage held in a world-sized buffer, addressed by a rectangle. */
class LiveBrush implements Brush {
  x0: number; y0: number; w: number; h: number;
  private c: Float32Array;
  private W: number;
  private H: number;
  empty = false;

  constructor(c: Float32Array, x0: number, y0: number, w: number, h: number, W: number, H: number) {
    this.c = c; this.x0 = x0; this.y0 = y0; this.w = w; this.h = h; this.W = W; this.H = H;
  }

  cover(i: number): number { return this.c[i]; }

  each(fn: (i: number, cover: number, x: number, y: number) => void): void {
    const W = this.W, H = this.H;
    for (let gy = Math.max(0, this.y0); gy <= Math.min(H - 1, this.y0 + this.h - 1); gy++) {
      for (let gx = this.x0; gx < this.x0 + this.w; gx++) {
        const wx = ((gx % W) + W) % W;
        const i = gy * W + wx;
        const c = this.c[i];
        if (c <= 0.002) continue;
        fn(i, c, wx, gy);
      }
    }
  }
}

// ---------------------------------------------------------------------------
// The ops
// ---------------------------------------------------------------------------

const idx = (W: number, H: number, x: number, y: number): number =>
  Math.min(H - 1, Math.max(0, y)) * W + (((x % W) + W) % W);

/** Mean of the 3×3 neighbourhood of the PRE-STROKE field. */
function mean3(base: BaseField, W: number, H: number, x: number, y: number): number {
  let sum = 0, n = 0;
  for (let dy = -1; dy <= 1; dy++) {
    const yy = y + dy;
    if (yy < 0 || yy >= H) continue;
    for (let dx = -1; dx <= 1; dx++) { sum += base.at(idx(W, H, x + dx, yy)); n++; }
  }
  return n ? sum / n : base.at(idx(W, H, x, y));
}

function bilinearBase(base: BaseField, W: number, H: number, x: number, y: number): number {
  const fx = Math.floor(x), fy = Math.floor(y);
  const tx = x - fx, ty = y - fy;
  const h00 = base.at(idx(W, H, fx, fy));
  const h10 = base.at(idx(W, H, fx + 1, fy));
  const h01 = base.at(idx(W, H, fx, fy + 1));
  const h11 = base.at(idx(W, H, fx + 1, fy + 1));
  return (h00 * (1 - tx) + h10 * tx) * (1 - ty) + (h01 * (1 - tx) + h11 * tx) * ty;
}

/**
 * Run one terrain op.
 *
 * `elev` is written; `base` is the field as it was before the stroke and is the
 * only thing read. That separation is what lets the live preview restore and
 * re-run on every pointer move and still land on exactly the committed result.
 */
export function applyTerrainOp(
  op: TerrainOp,
  elev: Float32Array,
  base: BaseField,
  W: number,
  H: number,
  brush: Brush,
  stroke: Stroke,
  seed: string,
): void {
  const strength = stroke.strength;
  const amp = 0.9 * strength;

  switch (op) {
    case 'raise':
      brush.each((i, c) => { elev[i] = base.at(i) + amp * c; });
      return;

    case 'lower':
      brush.each((i, c) => { elev[i] = base.at(i) - amp * c; });
      return;

    case 'smooth':
      // Jacobi, not Gauss–Seidel: every cell reads the pre-stroke neighbourhood,
      // so the result does not depend on the order the rectangle is scanned in.
      // The old version read cells it had already written, which made a stroke
      // smear very slightly downward and to the right — invisible, deterministic,
      // and wrong.
      brush.each((i, c, x, y) => {
        const b = base.at(i);
        elev[i] = b + (mean3(base, W, H, x, y) - b) * c * strength;
      });
      return;

    case 'sharpen':
      // The opposite of smooth: push each cell away from its neighbourhood. Ridges
      // gain an edge and valleys deepen — the "pinch" of a sculpting program, which
      // is how you turn a plausible lump into a mountain that looks carved.
      // Clamped to the local range so it cannot run away into spikes.
      brush.each((i, c, x, y) => {
        const b = base.at(i);
        const m = mean3(base, W, H, x, y);
        const lim = Math.abs(b - m) * 2.5 + 0.004;
        elev[i] = b + Math.max(-lim, Math.min(lim, (b - m) * c * strength * 2.2));
      });
      return;

    case 'flatten': {
      // Level to the mean under the brush: a plateau, a terrace, a plaza.
      let mean = 0, n = 0;
      brush.each((i, c) => { mean += base.at(i) * c; n += c; });
      if (n <= 0) return;
      mean /= n;
      brush.each((i, c) => { const b = base.at(i); elev[i] = b + (mean - b) * c * strength; });
      return;
    }

    case 'terrace': {
      // Quantise to steps. Mesas, badlands, the stacked benches of a dry canyon.
      // The step is derived from the relief actually under the brush, so the same
      // control gives sensible results on a coastal plain and on a cordillera.
      let lo = Infinity, hi = -Infinity;
      brush.each((i) => { const b = base.at(i); if (b < lo) lo = b; if (b > hi) hi = b; });
      if (!(hi > lo)) return;
      const steps = 3 + Math.round(strength * 7);
      const q = (hi - lo) / steps;
      brush.each((i, c) => {
        const b = base.at(i);
        const t = lo + Math.round((b - lo) / q) * q;
        elev[i] = b + (t - b) * c * Math.min(1, strength * 1.2);
      });
      return;
    }

    case 'roughen': {
      // Deterministic per-cell jitter: the same stroke always roughens the same
      // way, which matters because the edit list is replayed.
      brush.each((i, c) => {
        const hsh = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
        const n = (hsh - Math.floor(hsh)) * 2 - 1;
        elev[i] = base.at(i) + n * amp * 0.35 * c;
      });
      return;
    }

    case 'gully': {
      // Dissect a slope into ridges and gullies.
      //
      // Deliberately NOT a hydraulic simulation. A world cell here is about twenty
      // kilometres across, and at twenty kilometres a river valley is a single
      // cell — there is no erosion to simulate that anyone could see. What the eye
      // reads as "eroded" at this scale is the TEXTURE of a dissected massif, and
      // that is a ridged multifractal keyed to the slope: flat ground stays flat,
      // steep flanks get cut. Real stream-power erosion lives in the regional
      // sheet, where the cells are two hundred metres and it is visible.
      const noise = new SphereNoise(seed, 'sculpt-gully');
      brush.each((i, c, x, y) => {
        const b = base.at(i);
        const gx = base.at(idx(W, H, x + 1, y)) - base.at(idx(W, H, x - 1, y));
        const gy = base.at(idx(W, H, x, y + 1)) - base.at(idx(W, H, x, y - 1));
        const slope = Math.hypot(gx, gy) * 0.5;
        const u = (x + 0.5) / W, v = (y + 0.5) / H;
        const r = 1 - Math.abs(noise.fbm(u, v, 260, 4));
        const cut = Math.pow(r, 2.2) * Math.min(1, slope * 12) * strength * 0.22;
        elev[i] = b - cut * c;
      });
      return;
    }

    case 'grab': {
      // Move the ground itself.
      //
      // The one brush that is a transform rather than a per-cell rule, and the one
      // that makes the tool feel like sculpting rather than airbrushing: you take
      // hold of a range and drag it somewhere else. Each cell reads the pre-stroke
      // field from a point pulled back along the drag by its own coverage, so the
      // centre travels the full distance and the rim does not move at all.
      if (stroke.pts.length < 2) return;
      const { dx, dy } = grabVector(stroke, W);
      brush.each((i, c, x, y) => {
        elev[i] = bilinearBase(base, W, H, x - dx * c, y - dy * c);
      });
      return;
    }

    default:
      return;
  }
}

/** Paint coastline: max/min against a roughened dome. */
export function applyLandOp(
  op: LandOp,
  elev: Float32Array,
  base: BaseField,
  W: number,
  H: number,
  brush: Brush,
  stroke: Stroke,
  seed: string,
): void {
  const coast = new SphereNoise(seed, 'paint-coast');
  // New land comes out LOW. This brush draws a coastline; the relief brush makes
  // mountains. At the old amplitude a single coast stroke produced a range of
  // peaks, which took the choice away from the reader.
  const amp = op === 'land'
    ? 0.05 + 0.22 * stroke.strength
    : 0.1 + 0.5 * stroke.strength;
  brush.each((i, c, x, y) => {
    const u = (x + 0.5) / W, v = (y + 0.5) / H;
    // Roughen the dome so the new 0-contour is ragged. A clean dome gives a
    // painted island the silhouette of a coin, which no amount of good ink
    // downstream can disguise.
    const n = 0.72 + 0.62 * coast.fbm(u, v, 34, 4);
    const h = amp * c * n;
    const b = base.at(i);
    elev[i] = op === 'land' ? Math.max(b, h) : Math.min(b, -h);
  });
}

/**
 * A base field for a one-shot application: nothing is snapshotted, so `at` reads
 * the live array. Correct only when every cell is written exactly once and no op
 * reads a cell it has written — true for every op except the two that snapshot
 * for themselves below.
 */
export function liveBase(elev: Float32Array): BaseField {
  return { at: (i: number) => elev[i] };
}

/**
 * A base field over a rectangle, copied out before the op runs.
 *
 * Needed by the ops that read cells other than the one they are writing —
 * `smooth`, `sharpen`, `terrace`, `gully`, `grab`. The pad must cover their reach:
 * one cell for a neighbourhood, the whole drag distance for `grab`.
 */
export function snapshotBase(
  elev: Float32Array, W: number, H: number,
  x0: number, y0: number, w: number, h: number,
): BaseField {
  const data = new Float32Array(w * h);
  for (let gy = 0; gy < h; gy++) {
    const wy = Math.min(H - 1, Math.max(0, y0 + gy));
    for (let gx = 0; gx < w; gx++) {
      data[gy * w + gx] = elev[wy * W + ((((x0 + gx) % W) + W) % W)];
    }
  }
  // No loops in the lookup. This function is called several times per cell per
  // brush op — a stroke with a wide brush runs it a few million times a second —
  // and the `while` version that walked the seam one world-width at a time was
  // the single most expensive line in the sculpt path.
  return {
    at: (i: number) => {
      const gy = ((i / W) | 0) - y0;
      if (gy < 0 || gy >= h) return elev[i];
      const gx = ((((i % W) - x0) % W) + W) % W;
      return gx < w ? data[gy * w + gx] : elev[i];
    },
  };
}

/**
 * Does this brush answer per cell, or does it need the whole stroke?
 *
 * `raise` writes `f(height here, coverage here)` and nothing else, so extending a
 * stroke only changes the cells the new segment touched. `flatten` levels to the
 * mean UNDER THE WHOLE BRUSH, `terrace` derives its step from the whole brush's
 * range, and `grab` reads a displacement measured from the first point to the
 * last — for those three, one more pointer move changes every cell the stroke has
 * ever touched.
 *
 * Getting this distinction wrong in either direction is expensive: treat a local
 * brush as global and a long stroke crawls (seventy milliseconds a move with a
 * wide brush, which is a stroke you can watch fall behind your hand); treat a
 * global one as local and the preview stops matching what gets saved.
 */
export function opIsLocal(op: TerrainOp | LandOp): boolean {
  return op !== 'flatten' && op !== 'terrace' && op !== 'grab';
}

/** The drag of a grab stroke, unwrapped across the seam. */
export function grabVector(stroke: Stroke, W: number): { dx: number; dy: number } {
  const pts = stroke.pts;
  if (pts.length < 2) return { dx: 0, dy: 0 };
  const a = pts[0], b = pts[pts.length - 1];
  let dx = b.x - a.x;
  while (dx > W / 2) dx -= W;
  while (dx < -W / 2) dx += W;
  return { dx, dy: b.y - a.y };
}

/**
 * The rectangle an op needs a pre-stroke copy of.
 *
 * A neighbourhood is one cell. `grab` is the awkward one: it reads from the disc
 * pulled back along the drag, so what it needs is the disc UNION the shifted disc
 * — not the disc grown by the drag distance in every direction, which is what the
 * first version did and which made a long grab snapshot a region the size of a
 * continent for the sake of a circle.
 */
export function opBaseRect(
  op: TerrainOp, stroke: Stroke, brush: Brush, W: number,
): { x0: number; y0: number; w: number; h: number } {
  if (op !== 'grab') {
    return { x0: brush.x0 - 1, y0: brush.y0 - 1, w: brush.w + 2, h: brush.h + 2 };
  }
  const { dx, dy } = grabVector(stroke, W);
  const x0 = Math.floor(Math.min(brush.x0, brush.x0 - dx)) - 2;
  const x1 = Math.ceil(Math.max(brush.x0 + brush.w, brush.x0 + brush.w - dx)) + 2;
  const y0 = Math.floor(Math.min(brush.y0, brush.y0 - dy)) - 2;
  const y1 = Math.ceil(Math.max(brush.y0 + brush.h, brush.y0 + brush.h - dy)) + 2;
  return { x0, y0, w: x1 - x0, h: y1 - y0 };
}

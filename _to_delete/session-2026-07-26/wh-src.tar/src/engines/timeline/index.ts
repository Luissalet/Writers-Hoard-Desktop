import { Clock } from 'lucide-react';
import type { EngineDefinition } from '@/engines/_types';
import { registerEngine, registerEntityResolver } from '@/engines/_registry';
import { registerBackupStrategy, makeSimpleBackupStrategy } from '@/engines/_shared';
import { db } from '@/db';
import TimelineEngine from './TimelineEngine';

const timelineEngine: EngineDefinition = {
  id: 'timeline',
  name: 'Timeline',
  description: 'Multi-lane chronological timelines with connections and ranges',
  icon: Clock,
  category: 'core',
  tables: {
    timelines: 'id, projectId',
    timelineEvents: 'id, projectId, timelineId, order, dateMode, eventType',
    timelineConnections: 'id, projectId, timelineId, sourceEventId, targetEventId',
  },
  component: TimelineEngine,
};

registerEngine(timelineEngine);

registerEntityResolver({
  engineId: 'timeline',
  entityTypes: ['timeline', 'timeline-event'],
  resolveEntity: async (entityId: string, entityType: string) => {
    const event = await db.timelineEvents.get(entityId);
    if (!event) return null;
    return {
      id: event.id,
      type: entityType,
      engineId: 'timeline',
      title: event.title,
      subtitle: event.date,
      color: event.color,
    };
  },
  searchEntities: async (query: string) => {
    const q = query.toLowerCase();
    const rows = await db.timelineEvents.filter(e => e.title.toLowerCase().includes(q)).toArray();
    return rows.map(e => ({
      id: e.id,
      type: 'timeline-event',
      engineId: 'timeline',
      title: e.title,
      subtitle: e.date,
      color: e.color,
    }));
  },
});

// Supplemental backup: legacy zipBackup already exports `timelines` and
// `timelineEvents`. We only register `timelineConnections` here so it is no
// longer silently dropped during backup/restore (v15 added the table after
// the original backup code was written).
registerBackupStrategy(makeSimpleBackupStrategy({
  engineId: 'timeline',
  tables: ['timelineConnections'],
  folder: 'timeline-extras',
}));

export { timelineEngine };

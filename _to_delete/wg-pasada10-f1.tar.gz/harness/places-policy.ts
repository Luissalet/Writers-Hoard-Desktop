// ============================================================================
// BANCO DE LA POLÍTICA DE LUGARES (el grifo y el pincel de zonas)
// ============================================================================
// Luis, 2026-08-12: «no he pedido abadías, casas, monasterios». El sembrado
// regional pasa a estar APAGADO por defecto (`sites: 'auto'` sin ediciones),
// se abre entero con `placesEverywhere` y por zonas con `placesZone`. Este
// banco pregunta lo que puede salir mal:
//   A. El defecto de los BANCOS ('everywhere') sigue sembrando — nada viejo
//      cambia de suelo.
//   B. 'auto' sin ediciones: CERO lugares del enrejado; los pueblos del MUNDO
//      y los hitos naturales siguen ahí (no son sembrado).
//   C. 'auto' + grifo abierto == 'everywhere', lugar a lugar — el tick abre
//      exactamente el país de siempre, no uno parecido.
//   D. 'auto' + una zona `add`: lugares SOLO dentro de la zona.
//   E. 'auto' + grifo abierto + zona `remove`: la zona queda vacía y el resto
//      no se entera.
// Y desde el segundo parte de Luis (2026-08-13, «se ha creado ya con ciudades
// y caminos») el grifo también manda EN EL MUNDO:
//   G. Un mundo desnudo (sin ediciones) no genera ciudades, ni calzadas, ni
//      ruinas — nada humano que no esté pintado.
//   H. El grifo abierto reproduce el país de SIEMPRE, ciudad a ciudad — no
//      uno parecido.
import { getWorld } from './world-cache';
import { getGeography } from '../src/engines/worldgen/cartography/texture';
import { generateRegion } from '../src/engines/worldgen/region/generate';
import type { RegionData } from '../src/engines/worldgen/region/types';
import { applyEdits, type WorldEdit } from '../src/engines/worldgen/core/edits';
import { buildHumanGeography, DEFAULT_HUMAN_PARAMS } from '../src/engines/worldgen/core/settlements';

const LATTICE = new Set(['farm', 'hamlet', 'village', 'abbey', 'mill', 'tower',
  'quarry', 'mine', 'inn']);

let rojo = false;
const di = (que: string, ok: boolean, detalle: string) => {
  console.log(`${que}: ${ok ? 'sí' : `NO — ${detalle}`}`);
  if (!ok) rojo = true;
};

// ---- El mundo, dos veces: desnudo y con el grifo abierto -------------------
// `getWorld` desempaqueta un objeto NUEVO por llamada; el grifo de uno no
// alcanza al otro.
const wDes = getWorld({ seed: 'banco-lugares', width: 256 });
const gDes = getGeography(wDes, 'full');

const w = getWorld({ seed: 'banco-lugares', width: 256 });
applyEdits(w, [{ kind: 'placesEverywhere', enabled: true }]);
const g = getGeography(w, 'full');

// G. El mundo desnudo no genera humanidad.
di('G · mundo desnudo: 0 ciudades', gDes.settlements.length === 0, `${gDes.settlements.length}`);
di('G · mundo desnudo: 0 calzadas', gDes.roads.length === 0, `${gDes.roads.length}`);
di('G · mundo desnudo: 0 ruinas', gDes.ruins.length === 0, `${gDes.ruins.length}`);

// H. El grifo abierto == el país de siempre (la receta con `sites` ausente),
// ciudad a ciudad y con las mismas calzadas y ruinas.
const legado = buildHumanGeography(wDes, DEFAULT_HUMAN_PARAMS, 'full', false);
const ciudades = (lista: { name: string; x: number; y: number }[]) =>
  lista.map((s) => `${s.name}:${s.x},${s.y}`).sort().join('\n');
di('H · grifo abierto == legado (ciudad a ciudad)',
  ciudades(g.settlements) === ciudades(legado.settlements),
  `${g.settlements.length} vs ${legado.settlements.length}`);
di('H · mismas calzadas', g.roads.length === legado.roads.length,
  `${g.roads.length} ≠ ${legado.roads.length}`);
di('H · mismas ruinas', ciudades(g.ruins) === ciudades(legado.ruins),
  `${g.ruins.length} vs ${legado.ruins.length}`);

const cap = [...g.settlements].sort((a, b) => b.population - a.population)[0];
const win = { cx: cap.x, cy: cap.y, spanKm: 90 };

function sembrados(r: RegionData) {
  // Sólo el ENREJADO regional: lo del mundo (worldId) y los hitos naturales
  // (landmark) no son sembrado y no deben moverse con el grifo.
  return r.places.filter((p) => p.worldId === undefined && LATTICE.has(p.kind));
}
function huella(r: RegionData): string[] {
  return sembrados(r)
    .map((p) => `${p.kind}:${p.name}:${p.worldX.toFixed(2)},${p.worldY.toFixed(2)}`)
    .sort();
}

const sheet = (sites: 'auto' | 'everywhere', edits?: WorldEdit[]) =>
  generateRegion(w, g, win, { params: { sites }, edits });

// A. El defecto de los bancos sigue sembrando.
const A = sheet('everywhere');
di('A · everywhere siembra', sembrados(A).length > 0, `0 lugares en ${A.places.length}`);

// B. 'auto' sin ediciones: enrejado a cero; mundo e hitos intactos.
const B = sheet('auto');
const mundoB = B.places.filter((p) => p.worldId !== undefined).length;
const hitosB = B.places.filter((p) => p.kind === 'landmark').length;
const mundoA = A.places.filter((p) => p.worldId !== undefined).length;
const hitosA = A.places.filter((p) => p.kind === 'landmark').length;
di('B · auto sin ediciones = 0 sembrados', sembrados(B).length === 0,
  `${sembrados(B).length}: ${huella(B).slice(0, 3).join(' · ')}`);
di('B · los pueblos del mundo se quedan', mundoB === mundoA, `${mundoB} ≠ ${mundoA}`);
// Los hitos naturales NOMBRADOS también piden permiso desde el 2026-08-13
// (Luis: «lo mismo con fuentes, puentes» — el accidente es geografía, su
// nombre es contenido inventado). Grifo cerrado ⇒ cero.
di('B · los hitos nombrados también callan', hitosB === 0, `${hitosB} (A tiene ${hitosA})`);

// C. El grifo abierto reproduce 'everywhere' lugar a lugar.
const C = sheet('auto', [{ kind: 'placesEverywhere', enabled: true }]);
const hA = huella(A).join('\n');
const hC = huella(C).join('\n');
di('C · grifo abierto == everywhere (lugar a lugar)', hA === hC,
  `${huella(A).length} vs ${huella(C).length}`);
const hitosC = C.places.filter((p) => p.kind === 'landmark').length;
di('C · y los hitos vuelven todos', hitosC === hitosA, `${hitosC} ≠ ${hitosA}`);

// D. Una zona `add`: todo dentro, nada fuera.
// EN CELDAS DEL MUNDO Y A ESCALA DE LA HOJA: en un 256 una celda son ~156 km
// y la hoja entera (90 km) cabe en 0,6 celdas — un radio de 6 celdas la
// tragaba entera y las varas D/E medían una zona sin «fuera» (primer rojo de
// este banco, que era del banco). 0,15 celdas ≈ 23 km: un cuarto de hoja.
const R = 0.15;
const zona: WorldEdit = { kind: 'placesZone', mode: 'add', pts: [{ x: cap.x, y: cap.y }], radius: R };
const D = sheet('auto', [zona]);
const dDentro = (p: { worldX: number; worldY: number }) => {
  let dx = Math.abs(p.worldX - cap.x);
  if (dx > w.width / 2) dx = w.width - dx;
  return Math.hypot(dx, p.worldY - cap.y);
};
const dFuera = sembrados(D).filter((p) => dDentro(p) > R + 0.03);
di('D · la zona add siembra', sembrados(D).length > 0, '0 lugares con la zona puesta');
di('D · nada fuera de la zona', dFuera.length === 0,
  dFuera.slice(0, 3).map((p) => `${p.name}@${dDentro(p).toFixed(1)}c`).join(' · '));

// E. Grifo abierto + zona `remove`: la zona queda vacía, el resto igual.
const E = sheet('auto', [
  { kind: 'placesEverywhere', enabled: true },
  { kind: 'placesZone', mode: 'remove', pts: [{ x: cap.x, y: cap.y }], radius: R },
]);
const eDentro = sembrados(E).filter((p) => dDentro(p) <= R - 0.03);
di('E · la zona remove vacía su suelo', eDentro.length === 0,
  eDentro.slice(0, 3).map((p) => p.name).join(' · '));
di('E · fuera de la zona sigue habitado', sembrados(E).length > 0, '0 en toda la hoja');

console.log(`\nresumen: A=${sembrados(A).length} sembrados · B=${sembrados(B).length}`
  + ` · C=${sembrados(C).length} · D=${sembrados(D).length} · E=${sembrados(E).length}`);
process.exit(rojo ? 1 : 0);

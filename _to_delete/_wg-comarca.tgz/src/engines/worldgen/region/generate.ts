// ============================================
// Regional sheet — Generation
// ============================================
// Between the world map (≈20 km per cell) and the town plan (≈5 m) there is a
// gap of four orders of magnitude, and it is exactly the range at which stories
// happen: a day's ride, the next valley, the ford the army has to cross. This
// module fills it.
//
// A sheet is a pure function of (world, window, params). Nothing is stored;
// opening the same window twice produces the same country, and opening the
// window next door produces country that lines up along the shared edge. That
// is the same contract the world itself keeps — seed + params + edits — applied
// one scale down.

import type { HumanGeography } from '../core/settlements';
import type { WorldData } from '../core/types';
import { buildNaturalCover, applyHabitation } from './cover';
import { buildHabitation } from './places';
import { buildTracks } from './tracks';
import { buildFields } from './fields';
import {
  buildElevation, buildHydrology, carveWorldRivers, erodeSheet, extractStreams,
  extractPatch, kmPerWorldCell, regionGeometry, type RegionGeometry,
} from './terrain';
import { DEFAULT_REGION_PARAMS, type RegionData, type RegionParams, type RegionWindow } from './types';

export interface RegionBuildOptions {
  params?: Partial<RegionParams>;
  /** Stage callback for the progress bar. */
  onProgress?: (stage: string, t: number) => void;
}

export function generateRegion(
  world: WorldData,
  geo: HumanGeography,
  win: RegionWindow,
  opts: RegionBuildOptions = {},
): RegionData {
  const params: RegionParams = { ...DEFAULT_REGION_PARAMS, ...opts.params };
  const p = opts.onProgress ?? (() => {});

  p('relieve', 0);
  const g = regionGeometry(world, win, params);
  const patch = extractPatch(world, g);
  const elevation = buildElevation(world, g, patch, params);

  p('agua', 0.22);
  // Carve first, erode second: the world's rivers are a boundary condition, and
  // running the incision over them deepens their valleys rather than inventing
  // rival ones beside them.
  const rivers = carveWorldRivers(world, g, elevation);
  erodeSheet(elevation, g.width, g.height, g.metresPerCell, 3, 0.0055 * params.detail);

  p('cauces', 0.42);
  const t = buildHydrology(world, g, patch, elevation, rivers);
  const streams = extractStreams(g, t, rivers, params);
  nameStreams(streams, world, geo, g);

  p('vegetación', 0.45);
  const natural = buildNaturalCover(world, g, patch, t, params);

  p('poblamiento', 0.6);
  const hab = buildHabitation(world, geo, g, patch, t, natural.cover, streams, params);

  p('cultivo', 0.75);
  const farmed = applyHabitation(world, g, t, natural, hab.places, params);

  p('caminos', 0.85);
  const tracks = buildTracks(world, geo, g, t, farmed.cover, hab.places, streams, hab.fields, params);

  p('cercas', 0.94);
  const { fields, hedges, dykes } = buildFields(g, t, farmed.cover, farmed.tilth, hab.places, params);

  const { title, subtitle } = sheetTitle(world, geo, g, win, params);
  p('listo', 1);

  return {
    window: win,
    params,
    width: g.width,
    height: g.height,
    metresPerCell: g.metresPerCell,
    originX: g.originX,
    originY: g.originY,
    worldPerCellX: g.worldPerCellX,
    worldPerCellY: g.worldPerCellY,
    elevation: t.elevation,
    water: t.water,
    flow: t.flow,
    slope: t.slope,
    wet: t.wet,
    biome: natural.biome,
    cover: farmed.cover,
    streams,
    places: hab.places,
    tracks,
    fields,
    hedges,
    dykes,
    title,
    subtitle,
  };
}

/**
 * Carry the world's river names down onto the sheet.
 *
 * The trunk on a regional sheet is not "a river" — it is the SAME river the
 * world map names, and printing a different name on it (or none) is the fastest
 * way to make the two scales feel like two unrelated maps.
 */
function nameStreams(
  streams: RegionData['streams'], world: WorldData, geo: HumanGeography,
  g: { originX: number; originY: number; worldPerCellX: number; worldPerCellY: number },
): void {
  const WW = world.width;
  const named = geo.features.filter((f) => f.kind === 'river');
  if (!named.length) return;
  const toSheet = (wx: number, wy: number) => {
    let dx = wx - g.originX;
    while (dx < -WW / 2) dx += WW;
    while (dx > WW / 2) dx -= WW;
    return { x: dx / g.worldPerCellX, y: (wy - g.originY) / g.worldPerCellY };
  };
  for (const s of streams) {
    if (!s.trunk) continue;
    let best: string | undefined;
    let bd = Infinity;
    for (const f of named) {
      for (const c of f.cells ?? []) {
        const p = toSheet(c % WW, (c / WW) | 0);
        for (const q of [s.pts[0], s.pts[s.pts.length >> 1], s.pts[s.pts.length - 1]]) {
          const d = (p.x - q.x) ** 2 + (p.y - q.y) ** 2;
          if (d < bd) { bd = d; best = f.name; }
        }
      }
    }
    // A world river's cells are 20 km apart, so "close" has to be generous —
    // but not so generous that every brook borrows the Danube's name.
    if (best && bd < 900) s.name = best;
  }
}

function sheetTitle(
  world: WorldData, geo: HumanGeography, g: RegionGeometry,
  win: RegionWindow, params: RegionParams,
): { title: string; subtitle: string } {
  const WW = world.width;
  const cx = g.originX + (g.width / 2) * g.worldPerCellX;
  const cy = g.originY + (g.height / 2) * g.worldPerCellY;
  const wrap = (dx: number) => { while (dx < -WW / 2) dx += WW; while (dx > WW / 2) dx -= WW; return dx; };

  // The biggest place on the sheet gives it its name, the way a county is named
  // for its town. Failing that, the realm; failing that, the nearest feature.
  let bestTown: { name: string; rank: string; d: number } | null = null;
  for (const s of geo.settlements) {
    const dx = wrap(s.x - cx) / g.worldPerCellX, dy = (s.y - cy) / g.worldPerCellY;
    if (Math.abs(dx) > g.width / 2 || Math.abs(dy) > g.height / 2) continue;
    const w = s.rank === 'capital' ? 0.25 : s.rank === 'city' ? 0.45 : s.rank === 'town' ? 0.8 : 1.6;
    const d = Math.hypot(dx, dy) * w;
    if (!bestTown || d < bestTown.d) bestTown = { name: s.name, rank: s.rank, d };
  }

  let title: string;
  if (bestTown) {
    title = bestTown.rank === 'capital' || bestTown.rank === 'city'
      ? `Contorno de ${bestTown.name}` : `Tierras de ${bestTown.name}`;
  } else {
    const ix = (((Math.round(cx) % WW) + WW) % WW);
    const iy = Math.min(world.height - 1, Math.max(0, Math.round(cy)));
    const realm = geo.realmOf[iy * WW + ix];
    const r = geo.realms.find((x) => x.id === realm);
    let nearest: { name: string; d: number } | null = null;
    for (const f of geo.features) {
      const d = Math.hypot(wrap(f.x - cx), f.y - cy);
      if (!nearest || d < nearest.d) nearest = { name: f.name, d };
    }
    title = r ? `Marca de ${r.name}` : nearest ? `Cercanías de ${nearest.name}` : 'Hoja regional';
  }

  const kmCell = kmPerWorldCell(world);
  const spanY = (g.height * g.worldPerCellY) * kmCell;
  const scale = Math.round(g.metresPerCell / 0.28e-3 / 1000) * 1000; // 0.28 mm per cell on paper
  const subtitle = `${Math.round(win.spanKm)} × ${Math.round(spanY)} km · ${Math.round(g.metresPerCell)} m por celda · ≈ 1:${scale.toLocaleString('es-ES')}`;
  void params;
  return { title, subtitle };
}

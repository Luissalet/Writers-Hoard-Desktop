// ============================================================================
// Real atlas — "find coordinates": geocoding through OpenStreetMap's Nominatim
// ============================================================================
//
// The one other thing on the atlas that reaches the internet, and like the
// tile layer it is opt-in per project (`AtlasMapPrefs.geocodeConsent`). The
// request itself is made by the main process (`electron/atlasGeocode.ts`):
// Nominatim's usage policy asks for an identifying User-Agent and at most one
// request a second, neither of which a renderer can promise — the browser
// owns the header, and two editors could ask at once. Main queues and
// throttles; this side only parses what comes back, so the parsing can be
// tested without a network. This file is also imported by the preload for
// its types, so it must not touch `window`.

export interface GeocodeHit {
  /** Nominatim's display name: "Rossio, Santa Maria Maior, Lisboa, Portugal". */
  name: string;
  lat: number;
  lon: number;
  /** "city", "suburb", "peak"… — Nominatim's `type`, or its `class` when the type says nothing. */
  kind: string;
  country?: string;
}

/** What `window.electronAPI.atlas.geocode` resolves with. */
export type GeocodeResponse =
  | { ok: true; results: unknown }
  | { ok: false; code: 'bad-query' | 'network' | 'timeout' | 'http'; error: string };

export const GEOCODE_MAX_RESULTS = 5;
export const GEOCODE_MAX_QUERY_LENGTH = 200;

function finiteNumber(value: unknown): number | undefined {
  const n = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN;
  return Number.isFinite(n) ? n : undefined;
}

/**
 * Nominatim's `format=jsonv2` array → the hits the picker shows. Anything
 * malformed is dropped rather than shown with NaN coordinates; the list is
 * capped, since the editor only ever asked for five.
 */
export function parseNominatimResults(body: unknown): GeocodeHit[] {
  if (!Array.isArray(body)) return [];
  const hits: GeocodeHit[] = [];
  for (const item of body) {
    if (!item || typeof item !== 'object') continue;
    const record = item as Record<string, unknown>;
    const lat = finiteNumber(record.lat);
    const lon = finiteNumber(record.lon);
    if (lat === undefined || lon === undefined || Math.abs(lat) > 90 || Math.abs(lon) > 180) continue;
    const name = typeof record.display_name === 'string' ? record.display_name.trim() : '';
    if (!name) continue;
    const type = typeof record.type === 'string' ? record.type : '';
    const cls = typeof record.class === 'string' ? record.class : '';
    const address = record.address && typeof record.address === 'object' ? (record.address as Record<string, unknown>) : undefined;
    const country = typeof address?.country === 'string' && address.country.trim() ? address.country.trim() : undefined;
    hits.push({
      name,
      lat: Number(lat.toFixed(5)),
      lon: Number(lon.toFixed(5)),
      kind: type && type !== 'yes' ? type : cls,
      ...(country ? { country } : {}),
    });
    if (hits.length >= GEOCODE_MAX_RESULTS) break;
  }
  return hits;
}

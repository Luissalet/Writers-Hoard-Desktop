// ============================================
// World Generator — 2D atlas map (canvas)
// ============================================
// Pan/zoom canvas with pluggable map projections. The equirect render is
// reprojected through a cached pixel index map; overlays (rivers baked into
// their own layer, landmarks, waypoints, graticule) are forward-projected,
// and pointer interactions are inverse-projected. Cylindrical projections
// wrap seamlessly east–west; the others pan as a single sheet.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from '@/i18n/useTranslation';
import type { LandmarkType, WorldData, ViewMode } from '../core/types';
import { BIOME_COLORS, renderAtlasWindow, renderBase, renderRivers, updateAtlasCells } from '../core/render';
import { SculptGesture } from '../sculpt/ops';
import { PROJECTIONS, reprojectRgba, type Projection } from '../core/projections';
import { commitPaintStroke, isWaypointTool, negativeOf, pickGeneratedAt, restriction } from '../core/paintCommit';
import type { Pt, Stroke, WorldEdit } from '../core/edits';
import { filterFor } from '../core/edits';
import { strokeMask } from '../sculpt/ops';
import { Biome } from '../core/types';
import type { HumanGeography, Settlement } from '../core/settlements';
import type { WorldViewport, WorldWaypoint } from '../types';
import { tipOf, tipOutline } from '../sculpt/ops';
import type { PaintTool } from './PaintPanel';
import {
  resolveWorldLandmarks,
  type WorldSpatialEntity,
} from '../core/spatialEntities';
import { biomeName } from '../core/gazetteer';
import {
  declutterLabels, nextSemanticTier, profileForTier, semanticTier,
  type SemanticZoomTier,
} from '../core/semanticZoom';
import { DisplayTileStore } from '../cartography/tileStore';
import { levelFor, tileId, TILE_PX, type TileKey } from '../cartography/tiles';
import { drawRoadNetwork, roadOverlayAlpha } from '../cartography/roadOverlay';
import { drawRealmBorders, realmBorders } from '../cartography/realmOverlay';
import {
  MAX_SAT_TILE_Z, SAT_DEEP_Z, satPxPerCanonCell, satelliteDeepSupported,
} from '../region/satelliteTile';
import { regionClient } from '../region/client';
import type { TilePlace } from '../region/deepTile';
import { COVER_LABEL_ES } from '../region/types';
import type { RegionData } from '../region/types';
import { regionVisibleRect } from '../region/coordinates';
import {
  EARTH_KM, MIN_SPAN_KM, clampViewport, flightAt, FLIGHT_MS, sameViewport, type FlyTarget,
} from '../core/camera';

export const BIOME_KEYS = [
  'ocean', 'lake', 'iceCap', 'tundra', 'boreal', 'tempForest', 'tempRain',
  'grassland', 'shrubland', 'savanna', 'tropForest', 'tropRain', 'desert',
  'coldDesert', 'alpine', 'glacier', 'beach', 'saltFlat',
] as const;

interface Map2DProps {
  world: WorldData;
  viewMode: ViewMode;
  projection: Projection;
  showRivers: boolean;
  showLandmarks: boolean;
  showWaypoints: boolean;
  showGrid: boolean;
  waypoints: WorldWaypoint[];
  selectedWaypointId: string | null;
  selectedSpatialKey?: string | null;
  regionalEntities?: WorldSpatialEntity[];
  regionDetail?: RegionData | null;
  /** Placing a pin is the Punto tool with Chincheta selected, not a mode of
   *  its own. Both take normalized coordinates, which is how a pin is stored. */
  onPlaceWaypoint?: (u: number, v: number) => void;
  onRemoveWaypoint?: (id: string) => void;
  onSelectWaypoint: (id: string | null) => void;
  onSelectSpatialEntity?: (entity: WorldSpatialEntity | null) => void;
  /**
   * Everything below turns this from a picture of the world into one of the two
   * places it can be edited. The satellite map is the flat, undistorted view —
   * the one where a coastline is a coastline and not a coastline seen at an
   * angle — so it carries the same brush the 3D view does, and the same click
   * into a town.
   */
  geography?: HumanGeography | null;
  showSettlements?: boolean;
  /**
   * The road network, drawn as vectors over the ground.
   *
   * Not a decoration: the Camino brush lays roads BETWEEN the ones that are
   * already there, and until this layer existed the 2D map was the only view
   * that carried the brush and did not show its work.
   */
  showRoads?: boolean;
  /** Realm boundaries. Same switch the Carta uses, so one map cannot claim a
   *  frontier the other denies. */
  showBorders?: boolean;
  /**
   * Named geography and ruins — the seas, ranges, plains and abandoned places
   * the generator sited. The Carta has always drawn them; this view, where they
   * can be renamed and deleted, never did.
   */
  showFeatures?: boolean;
  /**
   * The first town of a road being laid, waiting for its second click. Drawn
   * as a ring so the gesture has a visible half-way state instead of only a
   * line of text under the map.
   */
  roadFrom?: Settlement | null;
  tool?: PaintTool;
  onEdit?: (edit: WorldEdit) => void;
  onPickSettlement?: (s: Settlement) => void;
  /** Double-click: descend a league toward that ground (the parent flies). */
  onZoomTo?: (x: number, y: number) => void;
  /** Shared camera state, used when switching between 2D, 3D, and regions. */
  viewport?: WorldViewport;
  onViewportChange?: (viewport: WorldViewport) => void;
  /** One-shot animated flight request (double-click, "volar aquí"). */
  flyTarget?: FlyTarget | null;
  /** Bumped when an edit changed the world under us, so the raster is rebuilt. */
  revision?: number;
  /**
   * The PRISTINE world plus its serialized strokes.
   *
   * Deep tiles regenerate the canon countryside at 153 m and re-apply the
   * strokes at that resolution; handing them the already-edited world would
   * bake every stroke twice, once as a world-grid smudge and once properly.
   * Absent, the pyramid stops at the levels the world raster can serve.
   */
  canonWorld?: WorldData;
  canonEdits?: string;
}

interface ViewState {
  scale: number; // screen px per projected-map px
  ox: number;    // screen offset of map X=0
  oy: number;
}

/**
 * One thing the last frame put on screen, and how close a pointer has to be.
 *
 * Screen pixels, one entry per east–west copy, so nothing downstream has to
 * redo the wrap arithmetic the drawing already did.
 */
interface Hit {
  kind: 'settlement' | 'entity' | 'waypoint' | 'place';
  x: number;
  y: number;
  reach: number;
  settlement?: Settlement;
  entity?: WorldSpatialEntity;
  waypointId?: string;
  place?: TilePlace;
  /** Ties are broken toward the more important thing, not the nearer one. */
  bias?: number;
}

/**
 * A number that identifies a WORLD OBJECT, not a seed.
 *
 * Every cache key in this view was `${seed}:${revision}`. Re-forging with the
 * same seed — a parameter tweak, which is the normal way to iterate on a world
 * — keeps the seed by design, and a world with no strokes has revision 0. So
 * two different planets produced byte-identical keys: `setGeneration` was a
 * no-op, the whole 320-tile pyramid of the OLD continents kept drawing, and the
 * settled sharp window of the old terrain was blitted over the new base raster
 * until the reader happened to pan.
 */
const WORLD_IDS = new WeakMap<object, number>();
let nextWorldId = 1;
function worldId(w: object): number {
  let id = WORLD_IDS.get(w);
  if (id === undefined) { id = nextWorldId++; WORLD_IDS.set(w, id); }
  return id;
}

/** What the canon calls the things it sites, for the hover readout. */
const PLACE_KIND_ES: Record<string, string> = {
  town: 'población', village: 'aldea', hamlet: 'caserío', farm: 'granja',
  mill: 'molino', abbey: 'abadía', tower: 'torre', inn: 'posada',
  ruin: 'ruina', crag: 'risco', ford: 'vado', bridge: 'puente',
  quarry: 'cantera', mine: 'mina', shrine: 'ermita', dock: 'muelle',
};

function makeCanvas(px: Uint8ClampedArray<ArrayBuffer>, w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  c.getContext('2d')!.putImageData(new ImageData(px, w, h), 0, 0);
  return c;
}

export default function Map2D({
  world, viewMode, projection, showRivers, showLandmarks, showWaypoints, showGrid,
  waypoints, selectedWaypointId, onPlaceWaypoint, onRemoveWaypoint, onSelectWaypoint,
  selectedSpatialKey, regionalEntities = [], regionDetail, onSelectSpatialEntity,
  geography, showSettlements, showRoads = true, showBorders = false,
  showFeatures = true, roadFrom = null,
  tool, onEdit, onPickSettlement, onZoomTo,
  viewport, onViewportChange, flyTarget, revision = 0, canonWorld, canonEdits,
}: Map2DProps) {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const viewRef = useRef<ViewState | null>(null);
  const viewportRef = useRef(viewport);
  viewportRef.current = viewport;
  const dragRef = useRef<{ x: number; y: number; ox: number; oy: number; moved: boolean } | null>(null);
  const rafRef = useRef(0);
  const [hover, setHover] = useState<{ x: number; y: number; text: string } | null>(null);

  /** Cells the pointer has crossed this stroke, and where the ring is drawn. */
  const stroke = useRef<Pt[] | null>(null);
  /**
   * Live terrain/land sculpting on the satellite: the SAME SculptGesture the
   * 3D view and the sculptor run — the world deforms under the brush, the
   * dirty window re-renders per move, and on release the gesture ROLLS BACK
   * and its edits replay through the session (rollback-then-commit, so the
   * authoritative replay can never drift from the preview).
   */
  const liveSculpt = useRef<SculptGesture | null>(null);
  /**
   * Live BIOME painting on the satellite. No gesture class here: each move
   * restores the touched cells and re-stamps the whole stroke — the stamp is
   * the SAME mask/dither/guard `applyEdits` runs on replay (kept in lockstep
   * below), so preview and commit agree cell for cell. The eraser stays on
   * the polyline preview: taking paint off needs the pre-overlay biome, and
   * only the session knows that.
   */
  const liveBiome = useRef<{ saved: Map<number, number> } | null>(null);
  /** Where the ring is drawn (screen) and what cell it is over (world), because
   *  a ragged rim is a function of the ground it sits on. */
  const brushAt = useRef<{ x: number; y: number; cx: number; cy: number } | null>(null);
  /** Ctrl at the moment the gesture started: the negative of whatever is out. */
  const negRef = useRef(false);
  /** Where the brush gesture started, in screen pixels. A brush stroke has no
   *  `dragRef` to ask, and the Camino tool needs to tell a click from a drag. */
  const pressAt = useRef<{ x: number; y: number } | null>(null);
  /**
   * WHAT WAS ACTUALLY DRAWN, in screen pixels, as of the last frame.
   *
   * The hit-tests used to walk the MODEL while `draw` walked a filtered subset
   * of it, and the two filters were never the same. Every disagreement was a
   * bug in one direction or the other: a click on open ocean at world zoom
   * opened the plan of a village too small to be drawn (the town search was a
   * flat 14 px over all 160 settlements, which at full extent is 560 km of
   * ground); pins you had switched off stayed clickable and deletable; the
   * hamlets and mills the deep tiles name were drawn and completely inert; and
   * regional entities were drawn at `x/W` but searched at `(x+0.5)/W`, half a
   * cell — about 88 screen pixels at the only zoom where they exist — so they
   * could never be hit at all.
   *
   * One list, filled by the layer that draws each thing, consumed by every
   * pointer question. Dividing them again is how they drift again.
   */
  const painted = useRef<Hit[]>([]);
  /** The tier the view is currently in, advanced with a dead band. Seeded from
   *  the first camera it is given so the opening frame is not a transition. */
  const tierRef = useRef<SemanticZoomTier>(semanticTier(viewport?.spanKm ?? 40075));
  const spaceRef = useRef(false);
  const brushing = !!tool && tool.mode !== 'off' && !!onEdit;
  const brushRef = useRef({ tool, onEdit, geography, brushing });
  brushRef.current = { tool, onEdit, geography, brushing };

  const W = world.width, H = world.height;
  const spec = PROJECTIONS[projection];
  const wraps = spec.wraps;
  const landmarks = useMemo(
    () => resolveWorldLandmarks(world),
    // The edit pipeline mutates the same world object and bumps revision.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [world, revision],
  );
  // (The union of landmarks and regional entities used to live here, for the
  // hit-test to walk. It walks `painted` now — what the frame actually drew —
  // so the two lists cannot fall out of step again.)

  // ---- layers -------------------------------------------------------------
  // `revision` is in the dependency list on purpose: painting MUTATES the world
  // in place, so its object identity is unchanged and a memo keyed on the object
  // alone would keep serving the raster from before the stroke.
  const basePixels = useMemo(
    () => renderBase(world, viewMode),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [world, viewMode, revision],
  );
  const riverPixels = useMemo(
    () => renderRivers(world),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [world, revision],
  );
  /** Palette source for the satellite WINDOW renderer (per-pixel shading needs
   *  the colours unshaded). Only the atlas mode pays for it. */
  const unshadedAtlas = useMemo(
    () => (viewMode === 'atlas' && projection === 'equirect'
      ? renderBase(world, 'atlas', { shade: false }) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [world, viewMode, projection, revision],
  );
  /**
   * The settled satellite window: one canvas rendered at SCREEN resolution for
   * the current view, per-pixel shaded, sub-cell coastline. During a gesture it
   * blits shifted/scaled like every settled layer; 170 ms of stillness renders
   * a fresh one. This is what replaces "magnify 1 px per cell by 28×".
   */
  const sharpSat = useRef<{
    canvas: HTMLCanvasElement; vx: number; vy: number; vw: number; vh: number; key: string;
  } | null>(null);
  const sharpTimer = useRef(0);

  // ---- the satellite pyramid ------------------------------------------------
  // The 2D stops being a magnified picture of the world raster here. Tiles come
  // from the same worker (or Forge process) the Carta and the regional sheets
  // use: above the hand-over level they are the world amplified per pixel,
  // below it they are the canon countryside inked as ground. Everything the
  // gesture needs — ancestor fall-back, LRU, in-flight dedup — lives in
  // DisplayTileStore, which the Carta has been using since the pyramid was
  // built. This view simply asks it for a different paint.
  const tileProps = useRef({ world, geography, canonWorld, canonEdits, showRivers });
  tileProps.current = { world, geography, canonWorld, canonEdits, showRivers };
  const deepPlaces = useRef(new Map<string, TilePlace[]>());
  const requestDrawRef = useRef<() => void>(() => undefined);
  const tileStore = useMemo(() => new DisplayTileStore(
    (key: TileKey) => {
      const q = tileProps.current;
      if (!q.geography) return Promise.resolve(null);
      const deep = key.z >= SAT_DEEP_Z && !!q.canonWorld;
      // The generation this request belongs to, captured NOW.
      const bornAt = tileGeneration.current;
      return regionClient.requestTile(
        deep ? q.canonWorld! : q.world,
        q.geography,
        key,
        {
          ink: 'satellite',
          themeId: 'satellite',
          layers: { rivers: q.showRivers, roads: true, fields: true },
          density: 1,
          reliefAmount: 1,
          edits: deep ? q.canonEdits : undefined,
        },
      ).promise.then((res) => {
        if (!res) return null;
        // The store guards the BITMAP against a stale generation; nothing
        // guarded the places, so a stroke's `clear()` was immediately undone by
        // the pre-stroke requests landing, and hamlet names from the previous
        // country were lettered over the new ground indefinitely.
        if (res.places?.length && bornAt === tileGeneration.current) {
          const places = deepPlaces.current;
          const id = tileId(key);
          // LRU, and big enough to outlast the bitmap cache it shadows: a FIFO
          // of 256 against a 320-tile LRU store meant names were evicted while
          // their tile was still resident, and `fetch` returns early for a
          // cached tile — so they never came back.
          places.delete(id);
          places.set(id, res.places);
          while (places.size > 400) {
            const oldest = places.keys().next().value;
            if (oldest === undefined) break;
            places.delete(oldest);
          }
        }
        return res.bitmap;
      }).catch(() => null);
    },
    () => requestDrawRef.current(),
  ), []);
  useEffect(() => () => tileStore.dispose(), [tileStore]);
  const tileGeneration = useRef('');
  /** Level the pyramid is drawing at, for the parts of the UI outside draw(). */
  const tileLevel = useRef(-1);

  /**
   * The canon under the cursor.
   *
   * The hover readout has always answered from the WORLD cell, which is twenty
   * to forty kilometres of ground averaged into one number — a fair answer when
   * that was all the view could show, and a useless one now that the same
   * screen draws a hedge. At canon depth the reading comes from the 153 m
   * ground instead: the real height here, what is growing on it, how steep it
   * is, whether it is wet.
   *
   * The probe never GENERATES. If the canon under the cursor is not resident it
   * says nothing and the world reading stands — which costs nothing and cannot
   * turn a hover into a nine-second stall.
   */
  const probe = useRef<{
    key: string;
    data: import('../region/workerProtocol').RegionProbe | null;
  } | null>(null);
  const probeTimer = useRef(0);
  useEffect(() => () => window.clearTimeout(probeTimer.current), []);

  /**
   * The deepest this camera may go, in screen pixels per world cell.
   *
   * Not a constant. The old `Math.min(28, …)` pinned the view at roughly a
   * kilometre of ground per screen — twenty-eight screen pixels for one
   * twenty-kilometre cell, which is the porridge this whole change exists to
   * remove. The honest ceiling is whatever the deepest AVAILABLE tile level
   * carries: with the canon behind it that is z18, one canon cell per 256-pixel
   * tile, about 0,6 m per pixel. Half a level of slack on top so the last level
   * can be magnified a little rather than stopping dead.
   */
  const maxScaleRef = useRef(28);
  const maxScale = useMemo(() => {
    const zTop = canonWorld && geography ? MAX_SAT_TILE_Z : 12;
    const usable = viewMode === 'atlas' && projection === 'equirect' && !!geography;
    if (!usable) return 28;
    return (TILE_PX * Math.pow(2, zTop) / world.width) * 1.4;
  }, [canonWorld, geography, viewMode, projection, world.width]);
  maxScaleRef.current = maxScale;

  /** Refresh the palette AND the sharp window over a freshly sculpted rect —
   *  the whole cost of a live brush move, a few hundred cells' worth. */
  const patchLive = useCallback((d: { x0: number; y0: number; x1: number; y1: number }) => {
    if (!unshadedAtlas || d.x1 < d.x0 || d.y1 < d.y0) return;
    updateAtlasCells(world, unshadedAtlas, d.x0 - 1, d.y0 - 1, d.x1 + 1, d.y1 + 1);
    const sh = sharpSat.current;
    if (sh && sh.key === `${worldId(world)}:${revision}`) {
      const ppcX = sh.canvas.width / sh.vw, ppcY = sh.canvas.height / sh.vh;
      // Half-open pixel rect covering the dirty cells plus a blending skirt.
      const x0 = Math.max(sh.vx, d.x0 - 2), x1 = Math.min(sh.vx + sh.vw, d.x1 + 2);
      const y0 = Math.max(sh.vy, d.y0 - 2), y1 = Math.min(sh.vy + sh.vh, d.y1 + 2);
      if (x1 > x0 && y1 > y0) {
        const px0 = Math.max(0, Math.floor((x0 - sh.vx) * ppcX));
        const py0 = Math.max(0, Math.floor((y0 - sh.vy) * ppcY));
        const px1 = Math.min(sh.canvas.width, Math.ceil((x1 - sh.vx) * ppcX));
        const py1 = Math.min(sh.canvas.height, Math.ceil((y1 - sh.vy) * ppcY));
        const OW = px1 - px0, OH = py1 - py0;
        if (OW > 0 && OH > 0) {
          const buf = new Uint8ClampedArray(OW * OH * 4);
          // The subwindow sits on the SAME sample lattice as the full window
          // (origin at an integer pixel offset), so the patch is seamless.
          renderAtlasWindow(world, unshadedAtlas, buf, OW, OH, {
            x: sh.vx + px0 / ppcX, y: sh.vy + py0 / ppcY, w: OW / ppcX, h: OH / ppcY,
          });
          const tctx = sh.canvas.getContext('2d');
          if (tctx) {
            const img = tctx.createImageData(OW, OH);
            img.data.set(buf);
            tctx.putImageData(img, px0, py0);
          }
        }
      }
    }
    scheduleDraw();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [world, revision, unshadedAtlas]);

  /** Restore-then-restamp the in-flight biome stroke. KEEP THE STAMP IN
   *  LOCKSTEP with applyEdits' biome overlay (core/edits.ts §3): same dither
   *  hash, same threshold, same sea guard — that agreement is the contract
   *  that lets the release replay authoritatively. */
  const applyLiveBiome = useCallback(() => {
    const lb = liveBiome.current;
    const pts = stroke.current;
    const { tool: bt } = brushRef.current;
    if (!lb || !pts || !bt || bt.mode !== 'biome') return;
    const { elevation, biome } = world;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const [i, v] of lb.saved) {
      biome[i] = v;
      const x = i % W, y = (i / W) | 0;
      if (x < x0) x0 = x; if (x > x1) x1 = x;
      if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
    const st: Stroke = {
      pts, radius: bt.radius, strength: bt.strength, softness: bt.softness,
      curve: bt.curve, tip: bt.tip, angle: bt.angle, jitter: bt.jitter,
      aspect: bt.aspect, taper: bt.taper,
    };
    const mask = strokeMask(st, W, H);
    if (mask) {
      const only = restriction(bt.only);
      const allow = only ? filterFor(only, elevation, W, H) : null;
      mask.each((i, c) => {
        if (allow && !allow(i)) return;
        const hsh = Math.sin(i * 45.164 + 11.71) * 27183.13;
        const jitter = (hsh - Math.floor(hsh)) * 0.45;
        if (c * st.strength <= 0.35 + jitter * 0.4) return;
        if (elevation[i] <= 0 && bt.biome !== Biome.Ocean && bt.biome !== Biome.Lake) return;
        if (!lb.saved.has(i)) lb.saved.set(i, biome[i]);
        biome[i] = bt.biome;
        const x = i % W, y = (i / W) | 0;
        if (x < x0) x0 = x; if (x > x1) x1 = x;
        if (y < y0) y0 = y; if (y > y1) y1 = y;
      });
    }
    if (x1 >= x0) patchLive({ x0, y0, x1, y1 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [world, patchLive]);

  /** Live paths only arm when they can actually SHOW their work: a fresh
   *  sharp window at satellite depth. Anywhere else the classic preview and
   *  commit-on-release remain exactly as they were. */
  const sharpReady = useCallback((): boolean => {
    const sh = sharpSat.current;
    const v = viewRef.current;
    return !!sh && !!v && v.scale >= 2.5 && sh.key === `${worldId(world)}:${revision}`;
  }, [world, revision]);

  /**
   * A live stroke belongs to ONE world object.
   *
   * `liveSculpt` and `liveBiome` mutate `world.elevation`/`world.biome` in
   * place, and the only rollbacks were on pointerup and pointercancel. Two ways
   * that lost: unmounting mid-stroke (switching view, or the world going null
   * for a render) left the uncommitted deformation baked into the shared world,
   * visible in the 3D and the carta until some other edit forced a replay; and a
   * world SWAP mid-stroke made `rollbackLiveBiome` write the old world's saved
   * biome values into the new world's array at the same flat indices, which is
   * not a stale preview but corruption.
   */
  const liveWorld = useRef<WorldData | null>(null);
  const abandonLive = useCallback(() => {
    const g = liveSculpt.current;
    liveSculpt.current = null;
    liveBiome.current = null;
    stroke.current = null;
    liveWorld.current = null;
    g?.rollback();
  }, []);
  useEffect(() => {
    // On unmount, and whenever the world underneath us is replaced.
    if (liveWorld.current && liveWorld.current !== world) abandonLive();
    return abandonLive;
  }, [world, abandonLive]);

  /** Roll a live biome stroke back to the pre-stroke ground. */
  const rollbackLiveBiome = useCallback(() => {
    // Never against a different world than the one the stroke started on.
    if (liveWorld.current && liveWorld.current !== world) { liveBiome.current = null; return; }
    const lb = liveBiome.current;
    if (!lb) return;
    liveBiome.current = null;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const [i, v] of lb.saved) {
      world.biome[i] = v;
      const x = i % W, y = (i / W) | 0;
      if (x < x0) x0 = x; if (x > x1) x1 = x;
      if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
    if (x1 >= x0) patchLive({ x0, y0, x1, y1 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [world, patchLive]);

  const baseCanvas = useMemo(() => {
    if (projection === 'equirect') return makeCanvas(basePixels, W, H);
    const { px, w, h } = reprojectRgba(basePixels, W, H, projection);
    return makeCanvas(px, w, h);
  }, [basePixels, projection, W, H]);

  const riverCanvas = useMemo(() => {
    if (projection === 'equirect') return makeCanvas(riverPixels, W, H);
    const { px, w, h } = reprojectRgba(riverPixels, W, H, projection);
    return makeCanvas(px, w, h);
  }, [riverPixels, projection, W, H]);

  const regionalCanvas = useMemo(
    () => regionDetail ? makeRegionalTerrainCanvas(regionDetail) : null,
    [regionDetail],
  );

  const PW = baseCanvas.width, PH = baseCanvas.height;

  const computeViewport = useCallback((): WorldViewport | null => {
    const view = viewRef.current;
    const canvas = canvasRef.current;
    if (!view || !canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const mapW = PW * view.scale;
    const mapH = PH * view.scale;
    let X = (rect.width * 0.5 - view.ox) / mapW;
    if (wraps) X = ((X % 1) + 1) % 1;
    const Y = (rect.height * 0.5 - view.oy) / mapH;
    const uv = spec.inverse(X, Math.min(1, Math.max(0, Y)));
    if (!uv) return null;
    return {
      u: ((uv[0] % 1) + 1) % 1,
      v: Math.min(1, Math.max(0, uv[1])),
      spanKm: Math.min(EARTH_KM, Math.max(MIN_SPAN_KM, EARTH_KM * rect.width / Math.max(1, mapW))),
    };
  }, [PH, PW, spec, wraps]);

  /** The last camera this view told the parent about — so an echo of our own
   *  report is not mistaken for someone else moving the camera. */
  const lastReported = useRef<WorldViewport | null>(null);
  const reportViewport = useCallback(() => {
    if (!onViewportChange) return;
    const vp = computeViewport();
    if (vp) { lastReported.current = vp; onViewportChange(vp); }
  }, [computeViewport, onViewportChange]);

  // ---- drawing --------------------------------------------------------------
  const draw = () => {
    const canvas = canvasRef.current;
    const view = viewRef.current;
    if (!canvas || !view) return;
    const ctx = canvas.getContext('2d')!;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = canvas.width / dpr, ch = canvas.height / dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#07070d';
    ctx.fillRect(0, 0, cw, ch);
    // Set ONCE, at the top, for the whole frame. It used to be set as a side
    // effect inside the settlement block, so when towns were off (or on the
    // first frame) every decluttered label rendered about half a line below the
    // box the collision test had reserved for it.
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';

    const { scale } = view;
    const mapW = PW * scale, mapH = PH * scale;
    // Through the HYSTERESIS, not straight from the span. A camera resting near
    // 520, 2 600 or 11 000 km used to flip tier on trackpad jitter, and each
    // flip took a whole layer of names — and, worse, re-issued a full regional
    // worker generation, because `regionalResolution` is a dependency of that
    // effect. `nextSemanticTier` has provided a 14 % dead band since it was
    // written and no caller had ever used it.
    const spanKm = 40075 * cw / Math.max(1, mapW);
    tierRef.current = nextSemanticTier(tierRef.current, spanKm);
    const semantic = profileForTier(tierRef.current);
    // Filled as each layer draws; swapped in at the end so a half-built frame
    // can never be what the pointer is tested against.
    const hits: Hit[] = [];
    const mapLabels: Array<{
      value: { text: string; color: string; size: number; weight: number };
      x: number;
      y: number;
      width: number;
      height: number;
      priority: number;
    }> = [];
    const queueLabel = (
      text: string,
      x: number,
      y: number,
      color: string,
      size: number,
      weight: number,
      priority: number,
    ) => {
      ctx.font = `${weight} ${size}px "Source Sans 3", sans-serif`;
      mapLabels.push({
        value: { text, color, size, weight },
        x,
        y,
        width: ctx.measureText(text).width,
        height: size * 1.4,
        priority,
      });
    };

    // Copies for wrap-around; single sheet otherwise.
    let firstOx = view.ox;
    let lastOx = view.ox;
    if (wraps) {
      firstOx = view.ox % mapW;
      if (firstOx > 0) firstOx -= mapW;
      lastOx = cw;
    }

    // The satellite mode goes through the WINDOW renderer past this scale —
    // under it, everything stays smoothed (crisp cell blocks remain the
    // deliberate look of the analytic modes only).
    const sharpEligible = viewMode === 'atlas' && projection === 'equirect'
      && scale >= 2.5 && !!unshadedAtlas;
    ctx.imageSmoothingEnabled = scale < 3 || sharpEligible;
    ctx.imageSmoothingQuality = 'high';

    for (let ox = firstOx; ox <= lastOx; ox += mapW) {
      ctx.drawImage(baseCanvas, ox, view.oy, mapW, mapH);
      if (sharpEligible && sharpSat.current && sharpSat.current.key === `${worldId(world)}:${revision}`) {
        const sh = sharpSat.current;
        ctx.drawImage(sh.canvas, ox + sh.vx * scale, view.oy + sh.vy * scale, sh.vw * scale, sh.vh * scale);
      }
      if (showRivers && viewMode !== 'plates' && viewMode !== 'flow') {
        ctx.drawImage(riverCanvas, ox, view.oy, mapW, mapH);
      }

      if (!wraps) break;
    }

    // ---- the satellite pyramid ---------------------------------------------
    // Drawn OVER the world raster, never instead of it. The raster is the
    // fallback that is always there and always current — including mid-stroke,
    // when the brush has changed the ground under the reader's hand and no
    // tile can know it yet — and the pyramid covers it wherever a tile, or an
    // ancestor's quarter, is resident. Blurry then sharp, never blank.
    // NOT `&& !stroke.current`. That term deleted the entire satellite pyramid
    // for the duration of a gesture — so at the depth the satellite exists for,
    // pressing the brush replaced photographic ground with a 20 km/cell wash
    // and the reader painted blind until they let go. The tiles are drawn UNDER
    // the live sharp window (which `patchLive` keeps current over the dirty
    // rect), so leaving them up is exactly what the block's own comment below
    // already claims happens: "never instead of it … including mid-stroke".
    const tilesEligible = viewMode === 'atlas' && projection === 'equirect' && !!geography;
    let tileZ = -1;
    if (!tilesEligible) tileLevel.current = -1;
    if (tilesEligible) {
      // A painted stroke is a different country: bumping the generation empties
      // the store rather than showing tiles of the world as it was.
      // Keyed on the world OBJECT and on the geography object, not on the seed:
      // a re-forge keeps the seed, and a geography rebuild (which happens
      // every time the brush is put away) changes the roads and towns that
      // are INKED INTO resident tiles without touching any of the old key.
      const gen = `${worldId(world)}:${revision}:${geography ? worldId(geography) : 0}`
        + `:${showRivers ? 1 : 0}:${canonWorld ? worldId(canonWorld) : 0}:${canonEdits?.length ?? 0}`;
      if (gen !== tileGeneration.current) {
        tileGeneration.current = gen;
        deepPlaces.current.clear();
      }
      tileStore.setGeneration(gen);
      tileZ = levelFor(world, scale, canonWorld ? MAX_SAT_TILE_Z : 12);
      const tv = { x: -view.ox / scale, y: -view.oy / scale, w: cw / scale, h: ch / scale };
      tileLevel.current = tileZ;
      tileStore.want(world, tileZ, tv);
      const got = tileStore.draw(ctx, world, tileZ, tv, { x: 0, y: 0, w: cw, h: ch });
      // Say so when the ground under the reader is still an ancestor's blur.
      // A stroke empties the store — the canon has to be rebuilt with it — and
      // without a word of warning that reads as "the paint did nothing".
      if (got.exact < got.needed) {
        const msg = `terreno · ${got.exact}/${got.needed}`;
        ctx.font = '500 11px "Source Sans 3", sans-serif';
        const tw = ctx.measureText(msg).width;
        ctx.fillStyle = 'rgba(7,7,13,0.62)';
        ctx.beginPath();
        ctx.roundRect(10, ch - 26, tw + 16, 18, 5);
        ctx.fill();
        ctx.fillStyle = '#d8d2c6';
        ctx.fillText(msg, 18, ch - 13);
      }
    }

    // Book a fresh window once the view rests. Booked from draw() so any
    // gesture reschedules it; rendered synchronously after 170 ms of quiet,
    // which is the same "still, then real" contract the other views keep.
    if (sharpEligible) {
      const want = {
        x: -view.ox / scale, y: -view.oy / scale, w: cw / scale, h: ch / scale,
      };
      const cur = sharpSat.current;
      const key = `${worldId(world)}:${revision}`;
      const stale = !cur || cur.key !== key
        || Math.abs(cur.vx - want.x) > 1e-6 || Math.abs(cur.vy - want.y) > 1e-6
        || Math.abs(cur.vw - want.w) > 1e-6;
      if (stale) {
        window.clearTimeout(sharpTimer.current);
        sharpTimer.current = window.setTimeout(() => {
          const v2 = viewRef.current;
          const c2 = canvasRef.current;
          if (!v2 || !c2 || !unshadedAtlas) return;
          const dpr2 = Math.min(window.devicePixelRatio || 1, 2);
          const cw2 = c2.width / dpr2, ch2 = c2.height / dpr2;
          // Screen-resolution budget: css pixels, capped so a huge monitor
          // still settles in ~one carto-quick-pass worth of time.
          const budget = 900_000;
          const pxCount = cw2 * ch2;
          const f = pxCount > budget ? Math.sqrt(budget / pxCount) : 1;
          const OW = Math.max(64, Math.round(cw2 * f));
          const OH = Math.max(64, Math.round(ch2 * f));
          const rect = {
            x: -v2.ox / v2.scale, y: -v2.oy / v2.scale,
            w: cw2 / v2.scale, h: ch2 / v2.scale,
          };
          const buf = new Uint8ClampedArray(OW * OH * 4);
          renderAtlasWindow(world, unshadedAtlas, buf, OW, OH, rect);
          let target = sharpSat.current?.canvas;
          if (!target) target = document.createElement('canvas');
          if (target.width !== OW || target.height !== OH) {
            target.width = OW; target.height = OH;
          }
          const tctx = target.getContext('2d');
          if (!tctx) return;
          const img = tctx.createImageData(OW, OH);
          img.data.set(buf);
          tctx.putImageData(img, 0, 0);
          sharpSat.current = { canvas: target, ...{ vx: rect.x, vy: rect.y, vw: rect.w, vh: rect.h }, key };
          scheduleDraw();
        }, 170);
      }
    }

    // Screen position for a map point in a given copy.
    const toScreen = (u: number, v: number, copyOx: number): [number, number] => {
      const [X, Y] = spec.forward(u, v);
      return [copyOx + X * mapW, view.oy + Y * mapH];
    };

    const copies: number[] = [];
    if (wraps) {
      for (let ox = firstOx; ox <= lastOx; ox += mapW) copies.push(ox);
    } else {
      copies.push(view.ox);
    }

    // The regional composite: a single 1024-cell window over the ground the
    // reader is looking at, painted over the world raster once semantic zoom
    // reaches its scale. It predates the pyramid and is now the LOWER of the
    // two — so where tiles are drawing it must stay out of the way, or it
    // would paint a coarse wash straight over the sharp ground at exactly the
    // zoom levels this change exists to fix. Its places still feed the
    // regional entity overlay, which is why it is still requested.
    // `viewMode === 'atlas'` is not optional: the composite's pixels are BIOME
    // colours (`makeRegionalTerrainCanvas` reads `BIOME_COLORS`), and the only
    // reason it ever drew in the elevation/temperature/precipitation/plates/flow
    // modes is that `tilesEligible` is false in exactly those modes. So a green
    // forest and a tan desert were being pasted over the middle of a temperature
    // map, at alpha 0.82–0.96.
    if (regionalCanvas && regionDetail && semantic.showRegionalTerrain
      && !tilesEligible && viewMode === 'atlas' && projection === 'equirect') {
      const visible = regionVisibleRect(regionDetail);
      const worldX0 = regionDetail.originX + visible.x * regionDetail.worldPerCellX;
      const worldY0 = regionDetail.originY + visible.y * regionDetail.worldPerCellY;
      const worldX1 = worldX0 + visible.width * regionDetail.worldPerCellX;
      const worldY1 = worldY0 + visible.height * regionDetail.worldPerCellY;
      const u0 = ((worldX0 / W) % 1 + 1) % 1;
      const u1 = ((worldX1 / W) % 1 + 1) % 1;
      const v0 = Math.min(1, Math.max(0, worldY0 / H));
      const v1 = Math.min(1, Math.max(0, worldY1 / H));
      ctx.save();
      ctx.globalAlpha = semantic.tier === 'local' ? 0.96 : 0.82;
      for (const copyOx of copies) {
        const [x0, y0] = toScreen(u0, v0, copyOx);
        const [projectedX1, bottom] = toScreen(u1, v1, copyOx);
        let x1 = projectedX1;
        if (wraps) {
          while (x1 - x0 > mapW / 2) x1 -= mapW;
          while (x1 - x0 < -mapW / 2) x1 += mapW;
        }
        const left = Math.min(x0, x1);
        const top = Math.min(y0, bottom);
        const width = Math.abs(x1 - x0);
        const height = Math.abs(bottom - y0);
        if (width > 1 && height > 1
            && left < cw + 20 && left + width > -20
            && top < ch + 20 && top + height > -20) {
          ctx.drawImage(regionalCanvas, left, top, width, height);
        }
      }
      ctx.restore();
    }

    // Graticule — sampled polylines so curved projections curve.
    //
    // The step follows the zoom. It was a hard 30° lattice, which meant that
    // below about three thousand kilometres of span the "malla" switch was on
    // and NOTHING was on screen: the nearest parallel and the nearest meridian
    // were both off the edge.
    if (showGrid) {
      const stepDeg = semantic.tier === 'planetary' ? 30
        : semantic.tier === 'continental' ? 10
          : semantic.tier === 'regional' ? 2 : 0.5;
      ctx.lineWidth = 1;
      for (const copyOx of copies) {
        for (let lat = -90 + stepDeg; lat <= 90 - stepDeg / 2; lat += stepDeg) {
          const v = 0.5 - lat / 180;
          if (v < 0 || v > 1) continue;
          // Cheap reject: a parallel entirely off the top or bottom costs
          // nothing to skip and 120 forward projections to draw.
          const [, probeY] = toScreen(0.5, v, copyOx);
          if (probeY < -40 || probeY > ch + 40) continue;
          const major = Math.abs(lat) < 1e-6;
          ctx.strokeStyle = major ? 'rgba(232,229,224,0.28)' : 'rgba(232,229,224,0.14)';
          ctx.setLineDash(major ? [] : [4, 4]);
          ctx.beginPath();
          for (let k = 0; k <= 120; k++) {
            const [sx, sy] = toScreen(k / 120, v, copyOx);
            if (k === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
          }
          ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(232,229,224,0.14)';
        ctx.setLineDash([4, 4]);
        for (let lon = -180; lon < 180; lon += stepDeg) {
          const u = 0.5 + lon / 360;
          const [probeX] = toScreen(u, 0.5, copyOx);
          if (probeX < -40 || probeX > cw + 40) continue;
          ctx.beginPath();
          for (let k = 0; k <= 60; k++) {
            const [sx, sy] = toScreen(u, k / 60, copyOx);
            if (k === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
          }
          ctx.stroke();
        }
        ctx.setLineDash([]);
      }
    }

    // ---- realm boundaries ---------------------------------------------------
    // Under the roads and everything else human: a frontier is a fact about the
    // ground, and a road crosses it rather than the other way round. Lines only,
    // no political wash — see `realmOverlay` for why.
    if (showBorders && geography && geography.realms.length) {
      const segs = realmBorders(world, geography);
      const tv = { x: -view.ox / scale, y: -view.oy / scale, w: cw / scale, h: ch / scale };
      for (const copyOx of copies) {
        drawRealmBorders(ctx, segs, {
          worldWidth: W,
          worldHeight: H,
          toScreen: (u, v) => toScreen(u, v, copyOx),
          width: cw,
          height: ch,
          pxPerCell: (PW * scale) / W,
          view: tv,
          alpha: 0.72,
        });
      }
    }

    // ---- the roads ----------------------------------------------------------
    // Over the ground, under everything that is a mark rather than a place: a
    // road runs THROUGH the country and the towns sit ON it, so a dot must
    // never end up hidden under a calzada.
    //
    // The deep tiles ink their own draped tracks, but only from the level where
    // a canon cell is 1,5 output pixels — z11 on a 2048 world. Above that this
    // layer is the only road there is; from there it fades out so the two
    // drawings of the same road cross over instead of blinking.
    if (showRoads && geography && geography.roads.length) {
      // `satelliteDeepSupported` matters: on a world whose canon lattice does
      // not divide the display grid the pyramid never reaches canon ground, so
      // nothing else would ever draw a road and fading out would leave the map
      // with none at any zoom.
      const inkedPx = tilesEligible && canonWorld && tileZ >= SAT_DEEP_Z
        && satelliteDeepSupported(world, tileZ)
        ? satPxPerCanonCell(world, tileZ) : 0;
      const alpha = roadOverlayAlpha(inkedPx);
      if (alpha > 0.01) {
        for (const copyOx of copies) {
          drawRoadNetwork(ctx, geography.roads, {
            worldWidth: W,
            worldHeight: H,
            toScreen: (u, v) => toScreen(u, v, copyOx),
            width: cw,
            height: ch,
            pxPerCell: (PW * scale) / W,
            alpha,
          });
        }
      }
    }

    // Landmarks
    if (showLandmarks) {
      for (const copyOx of copies) {
        for (const lm of landmarks) {
          if (!semantic.showMinorLandmarks && lm.importance < 0.26) continue;
          const [sx, sy] = toScreen((lm.x + 0.5) / W, (lm.y + 0.5) / H, copyOx);
          if (sx < -20 || sx > cw + 20 || sy < -20 || sy > ch + 20) continue;
          hits.push({
            kind: 'entity', x: sx, y: sy, entity: lm,
            reach: 9 * Math.max(0.75, lm.style.size ?? 1), bias: 0.9,
          });
          drawLandmark(ctx, lm, sx, sy, lm.key === selectedSpatialKey);
          if ((lm.style.labelVisible ?? false)
              || lm.key === selectedSpatialKey
              || semantic.tier === 'local') {
            queueLabel(
              lm.name,
              sx + 8,
              sy,
              lm.style.color ?? '#f6efe0',
              10,
              600,
              65 + lm.importance * 20,
            );
          }
        }
      }
    }

    if (regionalEntities.length && semantic.showRegionalTerrain) {
      ctx.font = '600 10px "Source Sans 3", sans-serif';
      for (const copyOx of copies) {
        for (const entity of regionalEntities) {
          if (entity.hidden) continue;
          const natural = entity.type === 'volcano' || entity.type === 'cave'
            || entity.type === 'waterfall' || entity.type === 'gorge'
            || entity.type === 'hotspring' || entity.kind === 'landmark';
          if ((natural && !showLandmarks) || (!natural && !showSettlements)) continue;
          const [sx, sy] = toScreen(
            ((entity.x / W) % 1 + 1) % 1,
            Math.min(1, Math.max(0, entity.y / H)),
            copyOx,
          );
          if (sx < -30 || sx > cw + 30 || sy < -20 || sy > ch + 20) continue;
          hits.push({
            kind: 'entity', x: sx, y: sy, entity,
            reach: 9 * Math.max(0.75, entity.style.size ?? 1), bias: 0.85,
          });
          drawRegionalEntity(ctx, entity, sx, sy, entity.key === selectedSpatialKey);
          if (semantic.tier === 'local' || entity.importance > 0.55
              || entity.style.labelVisible || entity.key === selectedSpatialKey) {
            queueLabel(
              entity.name,
              sx + 7,
              sy,
              entity.style.color ?? '#f6efe0',
              10,
              600,
              30 + entity.importance * 30,
            );
          }
        }
      }
    }

    // ---- ruins --------------------------------------------------------------
    // Before the towns, so a living place always wins the space fight: a ruin
    // crowding out a city is the wrong way round. Below the regional tier they
    // are clutter rather than information, which is the Carta's rule too.
    if (showFeatures && geography && geography.ruins.length
      && (semantic.tier === 'regional' || semantic.tier === 'local')) {
      ctx.save();
      ctx.globalAlpha = 0.82;
      for (const copyOx of copies) {
        for (const ru of geography.ruins) {
          const [sx, sy] = toScreen((ru.x + 0.5) / W, (ru.y + 0.5) / H, copyOx);
          if (sx < -20 || sx > cw + 20 || sy < -20 || sy > ch + 20) continue;
          const r = ru.kind === 'city' ? 4.2 : ru.kind === 'fort' ? 3.8 : 3.2;
          // A broken square: the universal "this was a building and is not any
          // more", and legible at four pixels where a drawn ruin symbol is mud.
          ctx.strokeStyle = 'rgba(226,214,190,0.85)';
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(sx - r, sy + r); ctx.lineTo(sx - r, sy - r); ctx.lineTo(sx, sy - r);
          ctx.moveTo(sx + r, sy - r * 0.2); ctx.lineTo(sx + r, sy + r); ctx.lineTo(sx + r * 0.1, sy + r);
          ctx.stroke();
          if (semantic.tier === 'local') {
            queueLabel(ru.name, sx + r + 4, sy, '#ddd2ba', 9.5, 500, 20 + ru.importance * 20);
          }
        }
      }
      ctx.restore();
    }

    // ---- named geography ----------------------------------------------------
    // The seas, ranges, plains and capes the generator named. No mark, only
    // type: a named sea IS its extent, and a dot in the middle of it would be a
    // lie about where it is. Sized by importance, gated on the feature actually
    // being big enough on screen to carry its own name — the classic way a
    // generated map betrays itself is a continent label wider than its continent.
    if (showFeatures && geography && geography.features.length) {
      for (const copyOx of copies) {
        for (const f of geography.features) {
          if (f.kind === 'river' || f.kind === 'peak') continue;
          if (f.extent * ((PW * scale) / W) < 46) continue;
          const [sx, sy] = toScreen((f.x + 0.5) / W, (f.y + 0.5) / H, copyOx);
          if (sx < -80 || sx > cw + 80 || sy < -30 || sy > ch + 30) continue;
          const water = f.kind === 'sea' || f.kind === 'bay' || f.kind === 'strait'
            || f.kind === 'ocean' || f.kind === 'lake' || f.kind === 'marsh';
          queueLabel(
            f.name.toUpperCase(),
            sx, sy,
            water ? 'rgba(178,214,236,0.92)' : 'rgba(238,228,205,0.9)',
            Math.max(9, Math.min(17, 10 + f.importance * 7)),
            600,
            // Above the towns: at the zoom where a sea has room for its name,
            // the sea is what you are looking at.
            120 + f.importance * 30,
          );
        }
      }
    }

    // ---- the names the reader typed -----------------------------------------
    // `painted.labels` had exactly one consumer in the whole tree — the Carta.
    // The Rótulo tool is only usable in THIS view and in the 3D, so every label
    // anyone has ever placed was invisible at the moment of placing it.
    if (world.painted?.labels?.length) {
      for (const copyOx of copies) {
        for (const pl of world.painted.labels) {
          const [sx, sy] = toScreen((pl.x + 0.5) / W, (pl.y + 0.5) / H, copyOx);
          if (sx < -100 || sx > cw + 100 || sy < -30 || sy > ch + 30) continue;
          queueLabel(
            pl.style === 'region' || pl.style === 'range' ? pl.text.toUpperCase() : pl.text,
            sx, sy,
            pl.style === 'water' ? 'rgba(178,214,236,0.96)' : '#ffe9c2',
            Math.max(9, Math.min(22, pl.size ?? 12)),
            600,
            // Highest band there is: the reader wrote it, so it outranks
            // anything the generator came up with.
            400,
          );
        }
      }
    }

    // Towns. Drawn before the waypoints so a pin the reader placed is never
    // hidden behind a dot the generator placed.
    // At canon depth the tiles carry the real buildings AND re-emit the world's
    // own towns as places, so drawing the rank dots too stamped a second, darker
    // dot on every town and put two identical names into the declutterer to
    // fight each other. The Carta solved this long ago with `settlements:
    // wantMarks && !deep`; this is the same rule.
    const deepMarks = tilesEligible && tileZ >= SAT_DEEP_Z;
    if (showSettlements && geography && !deepMarks) {
      // Only as much of the gazetteer as the zoom can carry: every village at
      // full extent is a grey smear along every coast.
      const maxRank = semantic.settlementRank;
      const order: Record<string, number> = { capital: 0, city: 1, town: 2, village: 3 };
      ctx.font = '600 11px "Source Sans 3", sans-serif';
      ctx.textBaseline = 'middle';
      for (const copyOx of copies) {
        for (const s of geography.settlements) {
          const rank = order[s.rank] ?? 3;
          // The town a road is being laid FROM always draws, whatever the zoom
          // says about its rank: half a gesture with an invisible first end is
          // the reader wondering whether the click registered at all.
          const pending = roadFrom?.id === s.id;
          if (rank > maxRank && !pending) continue;
          const [sx, sy] = toScreen((s.x + 0.5) / W, (s.y + 0.5) / H, copyOx);
          if (sx < -40 || sx > cw + 40 || sy < -20 || sy > ch + 20) continue;
          const r = rank === 0 ? 5 : rank === 1 ? 4 : rank === 2 ? 3 : 2.2;
          // The reach is the DOT plus a finger's worth, not a flat 14 px over
          // every town in the world — see the note on `painted`.
          hits.push({
            kind: 'settlement', x: sx, y: sy, settlement: s,
            reach: r + 9, bias: [0.45, 0.65, 0.85, 1][rank] ?? 1,
          });
          if (pending) {
            ctx.beginPath();
            ctx.arc(sx, sy, r + 5, 0, Math.PI * 2);
            ctx.lineWidth = 2;
            ctx.strokeStyle = 'rgba(255,214,120,0.95)';
            ctx.setLineDash([3, 3]);
            ctx.stroke();
            ctx.setLineDash([]);
          }
          ctx.beginPath();
          ctx.arc(sx, sy, r, 0, Math.PI * 2);
          ctx.fillStyle = pending ? '#ffd479' : rank === 0 ? '#ffd479' : '#f4ead4';
          ctx.fill();
          ctx.lineWidth = 1.5;
          ctx.strokeStyle = 'rgba(6,8,13,0.92)';
          ctx.stroke();
          if (rank === 0
              || (rank <= 1 && semantic.tier !== 'planetary')
              || (rank <= 2 && (semantic.tier === 'regional' || semantic.tier === 'local'))
              || semantic.tier === 'local') {
            queueLabel(
              s.name,
              sx + r + 5,
              sy,
              '#f6efe0',
              rank <= 1 ? 11 : 10,
              rank <= 1 ? 600 : 500,
              100 - rank * 15,
            );
          }
        }
      }
    }

    // Names the deep tiles found. Hamlets, farms, mills and named crags exist
    // only in the canon, so nothing above knows about them; they are lettered
    // live here, like every other label, because a name baked into a tile is
    // pinned to the wrong pixels the moment the view moves.
    if (tilesEligible && tileZ >= SAT_DEEP_Z) {
      const prefix = `${tileZ}/`;
      for (const [id, places] of deepPlaces.current) {
        if (!id.startsWith(prefix)) continue;
        for (const p of places) {
          for (const copyOx of copies) {
            const [sx, sy] = toScreen(p.worldX / W, p.worldY / H, copyOx);
            if (sx < -80 || sx > cw + 80 || sy < -30 || sy > ch + 30) continue;
            const big = p.kind === 'town' || p.kind === 'village';
            hits.push({ kind: 'place', x: sx, y: sy, place: p, reach: big ? 10 : 8, bias: 1.1 });
            ctx.beginPath();
            ctx.arc(sx, sy, big ? 3 : 2, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(20,18,14,0.75)';
            ctx.fill();
            queueLabel(
              p.name, sx + 5, sy, '#f2ecdd',
              big ? 11 : 9.5, big ? 600 : 500,
              40 + p.importance * 30,
            );
          }
        }
      }
    }

    // Waypoints
    if (showWaypoints) {
      ctx.font = '600 11px "Source Sans 3", sans-serif';
      for (const copyOx of copies) {
        for (const wp of waypoints) {
          const [sx, sy] = toScreen(wp.u, wp.v, copyOx);
          if (sx < -60 || sx > cw + 60 || sy < -30 || sy > ch + 30) continue;
          const selected = wp.id === selectedWaypointId;
          // A pin the reader put down outranks everything the generator placed.
          hits.push({ kind: 'waypoint', x: sx, y: sy, waypointId: wp.id, reach: 11, bias: 0.35 });
          ctx.beginPath();
          ctx.arc(sx, sy, selected ? 6 : 4.5, 0, Math.PI * 2);
          ctx.fillStyle = wp.color;
          ctx.fill();
          ctx.lineWidth = selected ? 2 : 1.25;
          ctx.strokeStyle = selected ? '#e8e5e0' : 'rgba(7,7,13,0.85)';
          ctx.stroke();
          // Through the declutterer like every other name. Drawn directly, pin
          // labels overlapped each other and everything else, and were not
          // counted against the label budget — so a cluster of pins was a pile
          // of unreadable pills on top of the map's own type.
          queueLabel(
            wp.name, sx + (selected ? 9 : 8), sy,
            selected ? '#e4a853' : '#e8e5e0', 11, 600,
            // Highest band: the reader put this here on purpose.
            500,
          );
        }
      }
    }

    // The frame is complete: what it drew is now what the pointer answers to.
    painted.current = hits;

    for (const candidate of declutterLabels(mapLabels, semantic.labelBudget, 3)) {
      const item = candidate.value;
      ctx.font = `${item.weight} ${item.size}px "Source Sans 3", sans-serif`;
      ctx.lineWidth = 3;
      ctx.lineJoin = 'round';
      ctx.strokeStyle = 'rgba(6,8,13,0.88)';
      ctx.strokeText(item.text, candidate.x, candidate.y);
      ctx.fillStyle = item.color;
      ctx.fillText(item.text, candidate.x, candidate.y);
    }

    // The stroke IN FLIGHT, before the ring. Nothing painted until release was
    // the single most-hated thing about these brushes: the committed result
    // costs half a second of derivation, but showing WHERE the paint will land
    // costs one translucent polyline. Round caps and joins make a stroked path
    // exactly the coverage of a round head; other heads read close enough for
    // a preview, and the cursor outline already tells the truth about the rim.
    {
      const pts0 = stroke.current;
      const bt0 = brushRef.current.tool;
      const anchor = brushAt.current;
      // When the ground itself is deforming live (satellite sculpt), the tint
      // trail would just smear over real terrain — the cursor ring suffices.
      if (pts0 && pts0.length > 0 && bt0 && anchor && !liveSculpt.current) {
        const pxPerCell = (PW * scale) / W;
        const tint = bt0.mode === 'biome'
          ? `rgba(${(BIOME_COLORS[bt0.biome] ?? [120, 160, 90]).join(',')},0.5)`
          : bt0.mode === 'river'
            ? 'rgba(64,124,196,0.55)'
            : bt0.mode === 'land'
              ? (bt0.landOp === 'sea' ? 'rgba(38,74,128,0.45)' : 'rgba(196,176,128,0.5)')
              : bt0.mode === 'terrain'
                ? (bt0.terrainOp === 'lower' ? 'rgba(30,34,44,0.4)' : 'rgba(255,255,255,0.35)')
                : null;
        if (tint) {
          // Screen position through the RING'S anchor, so the preview stays on
          // the copy of the world the pointer is actually over when the map
          // wraps — the same trick the cursor outline uses.
          const px = (p: Pt) => {
            let dx = p.x - anchor.cx;
            while (dx > W / 2) dx -= W;
            while (dx < -W / 2) dx += W;
            return anchor.x + dx * pxPerCell;
          };
          const py = (p: Pt) => anchor.y + (p.y - anchor.cy) * pxPerCell;
          const wCells = bt0.mode === 'river' ? Math.max(0.8, bt0.riverWidth) : bt0.radius * 2;
          ctx.save();
          ctx.beginPath();
          for (let k = 0; k < pts0.length; k++) {
            if (k === 0) ctx.moveTo(px(pts0[k]), py(pts0[k])); else ctx.lineTo(px(pts0[k]), py(pts0[k]));
          }
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.lineWidth = Math.max(2, wCells * pxPerCell);
          ctx.strokeStyle = tint;
          ctx.stroke();
          if (pts0.length === 1) {
            // A press with no movement yet: a dot, not an invisible zero-length line.
            ctx.beginPath();
            ctx.fillStyle = tint;
            ctx.arc(px(pts0[0]), py(pts0[0]), Math.max(1.5, (wCells / 2) * pxPerCell), 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }
      }
    }

    // ---- scale bar ----------------------------------------------------------
    // The 2D had no scale of any kind: nothing on screen said whether you were
    // looking at five hundred kilometres of ground or five. The Carta has had a
    // scale bar since it existed. A round number of ground units, drawn to the
    // width they actually occupy.
    {
      const kmPerPx = spanKm / cw;
      const want = kmPerPx * 150;                       // aim for ~150 px
      const pow = Math.pow(10, Math.floor(Math.log10(Math.max(1e-6, want))));
      const nice = [1, 2, 5, 10].find((f) => f * pow >= want) ?? 10;
      const barKm = nice * pow;
      const barPx = barKm / kmPerPx;
      const label = barKm >= 1 ? `${barKm >= 1000 ? Math.round(barKm) : barKm} km`
        : `${Math.round(barKm * 1000)} m`;
      const bx = 12, by = ch - 34;
      ctx.save();
      ctx.font = '600 10px "Source Sans 3", sans-serif';
      ctx.textBaseline = 'alphabetic';
      const tw = ctx.measureText(label).width;
      ctx.fillStyle = 'rgba(7,7,13,0.55)';
      ctx.beginPath();
      ctx.roundRect(bx - 5, by - 13, Math.max(barPx, tw) + 12, 24, 4);
      ctx.fill();
      ctx.strokeStyle = 'rgba(240,236,228,0.9)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(bx, by - 4); ctx.lineTo(bx, by + 2); ctx.lineTo(bx + barPx, by + 2);
      ctx.lineTo(bx + barPx, by - 4);
      ctx.stroke();
      ctx.fillStyle = '#f0ece4';
      ctx.fillText(label, bx, by - 6);
      ctx.restore();
      ctx.textBaseline = 'middle';
    }

    // The brush ring, last, over everything. Two circles: where the stroke
    // stops, and where it stops being at full strength — softness is otherwise a
    // number you set and then discover the effect of.
    const at = brushAt.current;
    const bt = brushRef.current.tool;
    if (at && bt && brushRef.current.brushing) {
      const pxPerCell = (PW * scale) / W;
      const tip = tipOf(bt as unknown as Stroke);
      // The ring is the shape of the HEAD. `tipOutline` solves the rim in the
      // same metric the brush culls with, so the outline and the paint are one
      // figure — a circle drawn over a square brush is just a wrong answer.
      const ring = (rCells: number) => {
        const pts2 = tipOutline(tip, Math.max(0.6, rCells), at.cx, at.cy, 96);
        ctx.beginPath();
        for (let k = 0; k < pts2.length; k++) {
          const px = at.x + (pts2[k].x - at.cx) * pxPerCell;
          const py = at.y + (pts2[k].y - at.cy) * pxPerCell;
          if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.stroke();
      };
      const rOuter = Math.max(3, bt.radius * pxPerCell);
      ctx.lineWidth = 2.6;
      ctx.strokeStyle = 'rgba(10,12,18,0.75)';
      ring(bt.radius);
      ctx.lineWidth = 1.6;
      ctx.strokeStyle = 'rgba(255,255,255,0.92)';
      ring(bt.radius);
      const soft = 1 - Math.min(0.98, bt.softness);
      if (rOuter * soft > 2) {
        ctx.strokeStyle = 'rgba(255,220,140,0.75)';
        ctx.setLineDash([3, 3]);
        ring(bt.radius * soft);
        ctx.setLineDash([]);
      }
    }
  };

  // `draw` closes over fresh props every render; the stable scheduler calls
  // the latest one through a ref (kept current in the redraw effect below).
  const drawRef = useRef<(() => void) | null>(null);
  const scheduleDraw = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => drawRef.current?.());
  }, []);

  // ---- sizing / init ----------------------------------------------------------
  // Re-runs on projection change (dims and/or `projection` dep) and starts
  // from a fresh fitted view — the old pan/zoom is meaningless there.
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    viewRef.current = null;

    const fit = () => {
      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
      if (!viewRef.current) {
        const fitScale = Math.min(rect.width / PW, rect.height / PH) * 0.98;
        const initialViewport = viewportRef.current;
        const requestedScale = initialViewport
          ? (EARTH_KM / Math.max(MIN_SPAN_KM, initialViewport.spanKm)) * (rect.width / PW)
          : fitScale;
        const scale = Math.max(fitScale * 0.5, Math.min(maxScaleRef.current, requestedScale));
        const [focusX, focusY] = spec.forward(initialViewport?.u ?? 0.5, initialViewport?.v ?? 0.5);
        viewRef.current = {
          scale,
          ox: rect.width * 0.5 - focusX * PW * scale,
          oy: rect.height * 0.5 - focusY * PH * scale,
        };
        clampView(viewRef.current, rect.width, rect.height, PW, PH, wraps);
      }
      scheduleDraw();
    };

    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(container);
    return () => {
      ro.disconnect();
      cancelAnimationFrame(rafRef.current);
      window.clearTimeout(sharpTimer.current);
    };
  }, [PW, PH, projection, scheduleDraw, spec, wraps]);

  /**
   * Keep the draw closure current — every render, with no redraw.
   *
   * This effect used to have no dependency array AND end in `scheduleDraw()`,
   * so any state change repainted the whole canvas. The state that changes most
   * is `hover`, which `handlePointerMove` sets to a FRESH OBJECT on every
   * pointer event — so simply moving the mouse across the map, button up,
   * repainted base + pyramid + borders + roads + every mark and label and the
   * declutterer at pointer rate. Nothing in `draw` reads `hover`; the tooltip is
   * a DOM node beside the canvas.
   */
  useEffect(() => {
    drawRef.current = draw;
    // The store calls this when a tile lands, so the interim gets one more
    // blit with the new tile in it. Through a ref, or the closure the store
    // was built with goes stale on the first re-render.
    requestDrawRef.current = scheduleDraw;
  });

  // And redraw when something that is actually ON the canvas changes.
  useEffect(() => {
    scheduleDraw();
  }, [
    scheduleDraw, world, revision, viewMode, projection, geography,
    showRivers, showLandmarks, showWaypoints, showGrid, showSettlements,
    showRoads, showBorders, showFeatures, roadFrom, tool,
    waypoints, selectedWaypointId, selectedSpatialKey, regionalEntities,
    regionDetail, canonWorld, canonEdits, landmarks,
  ]);

  // ---- flights ----------------------------------------------------------------
  // A one-shot animated approach (double-click, "volar aquí"): the same
  // interpolation every view uses, applied to this view's private camera.
  const flightRaf = useRef(0);
  const cancelFlight = useCallback(() => {
    if (flightRaf.current) { cancelAnimationFrame(flightRaf.current); flightRaf.current = 0; }
  }, []);

  const applyViewport = useCallback((vp: WorldViewport) => {
    const view = viewRef.current;
    const canvas = canvasRef.current;
    if (!view || !canvas) return;
    const rect = canvas.getBoundingClientRect();
    const fitScale = Math.min(rect.width / PW, rect.height / PH) * 0.98;
    const scale = Math.max(fitScale * 0.5, Math.min(maxScale,
      (EARTH_KM / Math.max(MIN_SPAN_KM, vp.spanKm)) * (rect.width / PW)));
    const [fx, fy] = spec.forward(vp.u, vp.v);
    view.scale = scale;
    view.ox = rect.width * 0.5 - fx * PW * scale;
    view.oy = rect.height * 0.5 - fy * PH * scale;
    clampView(view, rect.width, rect.height, PW, PH, wraps);
    scheduleDraw();
  }, [PW, PH, spec, wraps, scheduleDraw, maxScale]);

  /**
   * Somebody else moved the shared camera. Go there.
   *
   * `viewport` was read exactly once, inside `fit()`, and only when there was no
   * view yet — so "Ver en 2D" from the place inspector and "abrir comarca
   * guardada" did nothing at all whenever the reader was ALREADY in the 2D,
   * which is the most likely place to press them. The carta has adopted the
   * shared camera since it was written; this is the same effect, with the same
   * echo guard so our own report does not bounce back and fight the wheel.
   */
  useEffect(() => {
    if (!viewport || !viewRef.current) return;
    if (sameViewport(viewport, lastReported.current)) return;
    lastReported.current = viewport;
    cancelFlight();
    applyViewport(viewport);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewport]);

  /**
   * When the ceiling drops, bring the camera under it.
   *
   * Leaving the atlas mode or the equirect projection takes `maxScale` from
   * ~45 875 px per cell to 28 — the pyramid and the sharp window are only
   * defined there. The live `view.scale` was left where it was, so the picture
   * became giant flat blocks and the NEXT wheel tick teleported the reader out
   * to a thousand kilometres. Re-clamping makes the transition a zoom-out you
   * can watch rather than an ambush on the next gesture.
   */
  useEffect(() => {
    const view = viewRef.current;
    const canvas = canvasRef.current;
    if (!view || !canvas || view.scale <= maxScale) return;
    const rect = canvas.getBoundingClientRect();
    view.scale = maxScale;
    clampView(view, rect.width, rect.height, PW, PH, wraps);
    reportViewport();
    scheduleDraw();
  }, [maxScale, PW, PH, wraps, reportViewport, scheduleDraw]);

  useEffect(() => {
    if (!flyTarget) return;
    const from = computeViewport();
    if (!from) return;
    cancelFlight();
    const to = clampViewport({ u: flyTarget.u, v: flyTarget.v, spanKm: flyTarget.spanKm ?? from.spanKm });
    const t0 = performance.now();
    const step = () => {
      const t = Math.min(1, (performance.now() - t0) / FLIGHT_MS);
      applyViewport(flightAt(from, to, t));
      if (t < 1) {
        flightRaf.current = requestAnimationFrame(step);
      } else {
        flightRaf.current = 0;
        reportViewport();
      }
    };
    flightRaf.current = requestAnimationFrame(step);
    return cancelFlight;
    // The token IS the request; everything else is read fresh when it fires.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flyTarget?.token]);

  // Wheel zoom — non-passive listener so preventDefault works.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      cancelFlight();
      const view = viewRef.current;
      if (!view) return;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left, my = e.clientY - rect.top;
      const factor = Math.exp(-e.deltaY * 0.0016);
      const minScale = Math.min(rect.width / PW, rect.height / PH) * 0.5;
      const newScale = Math.max(minScale, Math.min(maxScale, view.scale * factor));
      const k = newScale / view.scale;
      view.ox = mx - (mx - view.ox) * k;
      view.oy = my - (my - view.oy) * k;
      view.scale = newScale;
      clampView(view, rect.width, rect.height, PW, PH, wraps);
      scheduleDraw();
      reportViewport();
    };
    canvas.addEventListener('wheel', onWheel, { passive: false });
    return () => canvas.removeEventListener('wheel', onWheel);
  }, [PW, PH, wraps, scheduleDraw, reportViewport, cancelFlight, maxScale]);

  // ---- helpers -------------------------------------------------------------------
  const screenToMap = (sx: number, sy: number): { u: number; v: number } | null => {
    const view = viewRef.current;
    if (!view) return null;
    const mapW = PW * view.scale, mapH = PH * view.scale;
    let X: number;
    if (wraps) {
      X = (((sx - view.ox) / mapW) % 1 + 1) % 1;
    } else {
      X = (sx - view.ox) / mapW;
      if (X < 0 || X > 1) return null;
    }
    const Y = (sy - view.oy) / mapH;
    if (Y < 0 || Y > 1) return null;
    const uv = spec.inverse(X, Y);
    if (!uv) return null;
    return { u: uv[0], v: uv[1] };
  };

  const waypointAt = (sx: number, sy: number): WorldWaypoint | null => {
    const id = hitAt(sx, sy, ['waypoint'])?.waypointId;
    return id ? waypoints.find((wp) => wp.id === id) ?? null : null;
  };

  /**
   * The nearest thing the last frame DREW, of the kinds asked for.
   *
   * Distance is scaled by the entry's bias so a capital beats the village next
   * to it and a pin beats both — the same ordering the old searches had, now
   * applied to one list instead of three that disagreed with the renderer.
   */
  const hitAt = (sx: number, sy: number, kinds: Hit['kind'][]): Hit | null => {
    let best: Hit | null = null;
    let bestScore = Infinity;
    for (const h of painted.current) {
      if (!kinds.includes(h.kind)) continue;
      const d = Math.hypot(sx - h.x, sy - h.y);
      if (d > h.reach) continue;
      const score = d * (h.bias ?? 1);
      if (score < bestScore) { bestScore = score; best = h; }
    }
    return best;
  };

  const landmarkAt = (sx: number, sy: number): WorldSpatialEntity | null =>
    hitAt(sx, sy, ['entity'])?.entity ?? null;

  /** A name the deep tiles found — a hamlet, a farm, a mill, a named crag. */
  const deepPlaceAt = (sx: number, sy: number): TilePlace | null =>
    hitAt(sx, sy, ['place'])?.place ?? null;

  // Space suspends the brush for as long as it is held, the way every paint
  // program does it, so the reader can reposition mid-drawing without changing
  // tool. Ctrl+Z goes to the world's own history, which is shared with 3D.
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.code === 'Space') spaceRef.current = true;
      // NOT while the reader is typing. This listener is on `window` and calls
      // `preventDefault`, so Ctrl+Z in the Rótulo text box — or in any input on
      // the page — silently reverted a brush stroke instead of the typing.
      // World3D has always had this guard; the 2D did not.
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA'
        || (e.target as HTMLElement | null)?.isContentEditable) return;
      if (e.ctrlKey || e.metaKey) {
        // One keymap for both views. They disagreed: here Ctrl+Shift+Z redid,
        // in the 3D the same chord UNDID (its test is `e.key === 'z' || 'Z'`),
        // and Ctrl+Y redid there and did nothing here. The same chord destroying
        // work in one view and restoring it in the other is not a preference.
        const k = e.key.toLowerCase();
        if (k === 'z') {
          e.preventDefault();
          window.dispatchEvent(new CustomEvent(e.shiftKey ? 'wg-redo' : 'wg-undo'));
        } else if (k === 'y') {
          e.preventDefault();
          window.dispatchEvent(new CustomEvent('wg-redo'));
        }
      }
    };
    const up = (e: KeyboardEvent) => { if (e.code === 'Space') spaceRef.current = false; };
    // Alt-tabbing away while Space is held used to leave the brush suspended
    // for ever, because the keyup never arrived.
    const blur = () => { spaceRef.current = false; };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
    };
  }, []);

  /** The nearest town to a screen point, within a screen-sized reach. */
  const settlementAt = (sx: number, sy: number): Settlement | null =>
    hitAt(sx, sy, ['settlement'])?.settlement ?? null;

  // ---- pointer events ----------------------------------------------------------
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const view = viewRef.current;
    if (!view) return;
    cancelFlight();
    (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);
    negRef.current = e.ctrlKey || e.metaKey;
    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;

    if (brushing && e.button === 0 && !spaceRef.current && !e.shiftKey) {
      const m = screenToMap(sx, sy);
      if (!m) return;
      const p0 = { x: m.u * W, y: m.v * H };
      stroke.current = [p0];
      liveWorld.current = world;
      pressAt.current = { x: sx, y: sy };
      brushAt.current = { x: sx, y: sy, cx: p0.x, cy: p0.y };
      const { tool: bt } = brushRef.current;
      if (bt && bt.mode === 'biome' && !negRef.current
        && viewMode === 'atlas' && projection === 'equirect' && unshadedAtlas && sharpReady()) {
        liveBiome.current = { saved: new Map() };
        applyLiveBiome();
      }
      if (bt && (bt.mode === 'terrain' || bt.mode === 'land')
        && viewMode === 'atlas' && projection === 'equirect' && unshadedAtlas && sharpReady()) {
        // Sculpt LIVE: the ground moves under the brush. Negative resolves at
        // the START here — the gesture must deform in the direction the
        // release will commit.
        const spec = negRef.current ? negativeOf(bt) : bt;
        // THE WHOLE HEAD, not just its size.
        //
        // Leaving out curve/tip/angle/jitter/aspect/taper meant the live path
        // built a plain round disc while the ring drew a ridge — and because
        // `SculptGesture.edits()` copies the spec straight into the stored
        // stroke, the SAVED edit was a disc too. So the same gesture made
        // different ground depending on whether the reader happened to be
        // zoomed in past 2,5 px per cell. World3D has always passed all of it.
        const g = new SculptGesture(world.elevation, W, H, world.params.seed, {
          kind: spec.mode as 'terrain' | 'land',
          op: spec.mode === 'land' ? spec.landOp : spec.terrainOp,
          radius: spec.radius, strength: spec.strength, softness: spec.softness,
          curve: spec.curve, tip: spec.tip, angle: spec.angle,
          jitter: spec.jitter, aspect: spec.aspect, taper: spec.taper,
        });
        liveSculpt.current = g;
        patchLive(g.extend(p0));
      }
      scheduleDraw();
      return;
    }
    if (!brushing) e.currentTarget.style.cursor = 'grabbing';
    dragRef.current = { x: sx, y: sy, ox: view.ox, oy: view.oy, moved: false };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const view = viewRef.current;
    if (!view) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;

    // The ring follows the pointer whenever a brush is out, button down or not:
    // without it the reader cannot tell how big the next stroke is.
    if (brushing) {
      const mp = screenToMap(sx, sy);
      brushAt.current = { x: sx, y: sy, cx: (mp?.u ?? 0) * W, cy: (mp?.v ?? 0) * H };
      const pts = stroke.current;
      if (pts) {
        const m = screenToMap(sx, sy);
        if (m) {
          const p = { x: m.u * W, y: m.v * H };
          const last = pts[pts.length - 1];
          // One point per half-cell keeps the serialized edit small enough to
          // store a hundred strokes.
          if (Math.hypot(p.x - last.x, p.y - last.y) > 0.5) {
            pts.push(p);
            const g = liveSculpt.current;
            if (g) patchLive(g.extend(p));
            else if (liveBiome.current) applyLiveBiome();
          }
        }
      }
      setHover(null);
      scheduleDraw();
      return;
    }
    if (brushAt.current) { brushAt.current = null; scheduleDraw(); }

    const drag = dragRef.current;
    if (drag) {
      const dx = sx - drag.x, dy = sy - drag.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      if (drag.moved) {
        view.ox = drag.ox + dx;
        view.oy = drag.oy + dy;
        clampView(view, rect.width, rect.height, PW, PH, wraps);
        scheduleDraw();
        setHover(null);
      }
      return;
    }
    // Hover inspector
    const m = screenToMap(sx, sy);
    if (!m) { setHover(null); return; }
    // The hamlets, farms, mills and named crags the deep tiles found. They are
    // drawn with a dot and a name; until this line the pointer knew nothing
    // about them and answered with the generic terrain reading instead.
    const hoveredPlace = deepPlaceAt(sx, sy);
    if (hoveredPlace) {
      setHover({
        x: Math.min(sx + 12, rect.width - 210),
        y: sy + 14,
        text: `${hoveredPlace.name} · ${PLACE_KIND_ES[hoveredPlace.kind] ?? hoveredPlace.kind}`,
      });
      return;
    }
    const hoveredLandmark = landmarkAt(sx, sy);
    if (hoveredLandmark) {
      const left = Math.min(sx + 12, rect.width - 210);
      setHover({
        x: left,
        y: sy + 14,
        text: `${hoveredLandmark.name} · ${hoveredLandmark.type}`,
      });
      return;
    }
    const cx = Math.min(W - 1, Math.floor(m.u * W));
    const cy = Math.min(H - 1, Math.floor(m.v * H));
    const i = cy * W + cx;
    const e2 = world.elevation[i];
    /**
     * What is growing here.
     *
     * `BIOME_KEYS` stops at 17 and `Biome` runs to 39 — mangrove, steppe, erg,
     * salt marsh and every other id the ecology overhaul added. The old
     * `?? 'ocean'` turned all of them into "Océano", which is a confident wrong
     * answer over a swamp. `biomeName` knows every id, so it is the fallback
     * until the catalogue carries them all.
     */
    const biomeId = world.biome[i];
    const biomeKey = BIOME_KEYS[biomeId];
    const biomeLabel = biomeKey ? t(`worldgen.biome.${biomeKey}`) : biomeName(biomeId);

    // Ask the canon, if the canon is what is on screen. One reading per cell of
    // ground, so a moving cursor asks a few times a second and not a few
    // hundred; the answer arrives for the NEXT frame of hovering, which at this
    // range is a few pixels away and reads as instant.
    const deep = tileLevel.current >= SAT_DEEP_Z && !!geography;
    const probeKey = deep
      ? `${Math.round(m.u * W * 128)}:${Math.round(m.v * H * 128)}`
      : '';
    if (deep && probe.current?.key !== probeKey) {
      window.clearTimeout(probeTimer.current);
      const wx = m.u * W, wy = m.v * H;
      probeTimer.current = window.setTimeout(() => {
        const q = tileProps.current;
        if (!q.geography) return;
        regionClient
          .requestProbe(q.canonWorld ?? q.world, q.geography, wx, wy)
          .then((data) => { probe.current = { key: probeKey, data }; })
          .catch(() => { probe.current = { key: probeKey, data: null }; });
      }, 70);
    }
    const canon = deep && probe.current?.key === probeKey ? probe.current.data : null;

    const parts = canon
      ? [
        canon.water === 1 ? 'mar' : canon.water === 2 ? 'lago'
          : (COVER_LABEL_ES[canon.cover] ?? biomeLabel),
        `${Math.round(canon.elevationM)} m`,
        `${Math.round(canon.slope * 100)} % pdte.`,
        canon.wet > 0.6 ? 'encharcado' : canon.wet > 0.35 ? 'húmedo' : 'seco',
        `${Math.round(canon.metresPerCell)} m/celda`,
      ]
      : [
        biomeLabel,
        e2 > 0
          ? `${Math.round(e2 * 1000)} m`
          : `−${Math.round(-e2 * 1000)} m`,
        `${Math.round(world.temperature[i])}°C`,
        `${Math.round(world.precipitation[i])} mm`,
      ];
    // Clamp here (event handler) so render never touches the container ref.
    const left = Math.min(sx + 12, rect.width - 210);
    setHover({ x: left, y: sy + 14, text: parts.join(' · ') });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.style.cursor = '';
    const rect = e.currentTarget.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;

    // A stroke becomes an edit on release, not per move: a terrain stroke costs
    // a few hundred milliseconds, which is fine once and unusable sixty times a
    // second.
    const pts = stroke.current;
    stroke.current = null;
    const press = pressAt.current;
    pressAt.current = null;
    if (pts) {
      const { tool: bt, onEdit: commit, geography: geo } = brushRef.current;
      // The Camino tool is not a brush and never was: it is two clicks on two
      // towns with an A* between them, and the routing lives in the parent.
      // A click made a one-point stroke, `commitPaintStroke` returns null for
      // one point, and the click therefore did NOTHING — while the status line
      // went on asking for a town it was impossible to pick. Let a click that
      // landed on a dot through to the picker; a drag still draws by hand.
      if (bt && bt.mode === 'road' && !negRef.current && onPickSettlement
        && (!press || Math.hypot(sx - press.x, sy - press.y) <= 4)) {
        const s = settlementAt(sx, sy);
        if (s) { onPickSettlement(s); scheduleDraw(); return; }
      }
      if (bt && isWaypointTool(bt)) {
        // A pin does not go into the edit list — see `isWaypointTool`.
        if (negRef.current) {
          const hit = waypointAt(sx, sy);
          if (hit) onRemoveWaypoint?.(hit.id);
        } else {
          const at = pts[pts.length - 1];
          onPlaceWaypoint?.(
            (((at.x / W) % 1) + 1) % 1,
            Math.min(1, Math.max(0, at.y / H)),
          );
        }
        scheduleDraw();
        return;
      }
      // A live biome stroke rolls back FIRST; the ordinary commit below then
      // replays it through the session — the stamp above guarantees the replay
      // lands on the same cells the reader just watched fill in.
      rollbackLiveBiome();
      const g = liveSculpt.current;
      if (g && commit) {
        // Roll the live deformation back and hand the stroke to the session,
        // exactly like the sculptor and the 3D brush: preview and replay agree
        // cell for cell, and rolling back anyway means the authoritative one
        // wins if they ever stop agreeing.
        liveSculpt.current = null;
        const total = g.dirty;
        g.rollback();
        patchLive(total);
        for (const ed of g.edits()) commit(ed as WorldEdit);
        scheduleDraw();
        return;
      }
      if (bt && commit) {
        const view = viewRef.current;
        const cellsPerPx = view ? W / Math.max(1, PW * view.scale) : 1;
        // Terrain and coast invert the OPERATION, everything else inverts at
        // commit time — one rule, resolved in the one place that knows both.
        const spec = negRef.current ? negativeOf(bt) : bt;
        const edit = commitPaintStroke(spec, pts, {
          negative: negRef.current,
          pickGenerated: (x, y) => pickGeneratedAt(world, geo, x, y, Math.max(2, 16 * cellsPerPx)),
        });
        if (edit) commit(edit);
      }
      scheduleDraw();
      return;
    }

    const drag = dragRef.current;
    dragRef.current = null;
    if (!drag) return;
    if (drag.moved) {
      reportViewport();
      return;
    }
    // Only the left button selects. Without this the right button opened a
    // town's plan UNDER the browser's own context menu — see `onContextMenu`.
    if (e.button !== 0) return;
    // It was a click.
    const wp = waypointAt(sx, sy);
    if (wp) { onSelectWaypoint(wp.id); return; }
    const landmark = landmarkAt(sx, sy);
    if (landmark) {
      onSelectWaypoint(null);
      onSelectSpatialEntity?.(landmark);
      return;
    }
    // A town under the pointer opens its plan — the same gesture as on the
    // carta and in 3D, because it is the same question being asked.
    if (onPickSettlement) {
      const s = settlementAt(sx, sy);
      if (s) { onPickSettlement(s); return; }
    }
    onSelectWaypoint(null);
    onSelectSpatialEntity?.(null);
  };

  const handleDoubleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (brushing || !onZoomTo) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const m = screenToMap(e.clientX - rect.left, e.clientY - rect.top);
    if (m) onZoomTo(m.u * W, m.v * H);
  };

  return (
    <div ref={containerRef} className="absolute inset-0">
      <canvas
        ref={canvasRef}
        className="block"
        style={{ cursor: brushing ? 'crosshair' : 'grab', touchAction: 'none' }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={() => {
          rollbackLiveBiome();
          const g = liveSculpt.current;
          if (g) {
            liveSculpt.current = null;
            const total = g.dirty;
            g.rollback();
            patchLive(total);
          }
          // `dragRef` too: without it a cancelled PAN left the map following
          // the pointer forever with no button held down.
          stroke.current = null; brushAt.current = null; pressAt.current = null;
          dragRef.current = null;
          scheduleDraw();
        }}
        onPointerLeave={() => {
          setHover(null);
          if (brushAt.current) { brushAt.current = null; scheduleDraw(); }
        }}
        onDoubleClick={handleDoubleClick}
        onContextMenu={(e) => e.preventDefault()}
      />
      {hover && !brushing && (
        <div
          className="absolute z-10 pointer-events-none px-2 py-1 rounded-md bg-surface/95 border border-border text-[11px] text-text-primary whitespace-nowrap shadow-lg"
          style={{ left: hover.x, top: hover.y }}
        >
          {hover.text}
        </div>
      )}
      <div className="absolute bottom-2 left-2 px-2 py-1 rounded-md border border-white/20 bg-[#0b0e14]/92 text-[11px] leading-snug text-white shadow-lg shadow-black/50 backdrop-blur-sm pointer-events-none">
        {brushing
          ? (tool?.mode === 'road'
            ? `${roadFrom ? `camino desde ${roadFrom.name} — pincha la otra punta` : 'pincha la población de partida'} · o arrastra para trazarlo a mano · Ctrl borra`
            : 'arrastra para pintar · Espacio para mover el mapa · Ctrl+Z deshace')
          : `${t('worldgen.mapHint')}${onPickSettlement ? ' · clic en una ciudad abre su plano · doble clic baja a la comarca' : ''}`}
      </div>
    </div>
  );
}

function clampView(view: ViewState, cw: number, ch: number, PW: number, PH: number, wraps: boolean): void {
  const mapW = PW * view.scale;
  const mapH = PH * view.scale;
  const marginY = Math.min(ch * 0.4, mapH * 0.6);
  if (mapH <= ch) {
    view.oy = Math.max(-mapH * 0.5, Math.min(ch - mapH * 0.5, view.oy));
  } else {
    view.oy = Math.max(ch - mapH - marginY, Math.min(marginY, view.oy));
  }
  if (!wraps) {
    const marginX = Math.min(cw * 0.4, mapW * 0.6);
    if (mapW <= cw) {
      view.ox = Math.max(-mapW * 0.5, Math.min(cw - mapW * 0.5, view.ox));
    } else {
      view.ox = Math.max(cw - mapW - marginX, Math.min(marginX, view.ox));
    }
  }
}

function makeRegionalTerrainCanvas(region: RegionData): HTMLCanvasElement {
  const visible = regionVisibleRect(region);
  const width = Math.max(1, Math.round(visible.width));
  const height = Math.max(1, Math.round(visible.height));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const rgba = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) {
    const sy = Math.min(region.height - 1, region.margin + y);
    for (let x = 0; x < width; x++) {
      const sx = Math.min(region.width - 1, region.margin + x);
      const source = sy * region.width + sx;
      const output = (y * width + x) * 4;
      let color = BIOME_COLORS[region.biome[source]] ?? [116, 120, 105];
      if (region.water[source] === 1) color = [48, 90, 126];
      else if (region.water[source] === 2) color = [67, 112, 142];
      const left = region.elevation[sy * region.width + Math.max(0, sx - 1)];
      const up = region.elevation[Math.max(0, sy - 1) * region.width + sx];
      const here = region.elevation[source];
      const shade = Math.min(1.24, Math.max(0.68, 0.98 + (left + up - here * 2) * 18));
      rgba[output] = Math.round(color[0] * shade);
      rgba[output + 1] = Math.round(color[1] * shade);
      rgba[output + 2] = Math.round(color[2] * shade);
      rgba[output + 3] = 255;
    }
  }
  canvas.getContext('2d')!.putImageData(new ImageData(rgba, width, height), 0, 0);
  return canvas;
}

function drawRegionalEntity(
  ctx: CanvasRenderingContext2D,
  entity: WorldSpatialEntity,
  x: number,
  y: number,
  selected: boolean,
): void {
  const natural = ['volcano', 'cave', 'waterfall', 'gorge', 'hotspring'].includes(entity.type);
  if (natural) {
    drawLandmark(ctx, entity, x, y, selected);
    return;
  }
  const size = Math.min(2, Math.max(0.7, entity.style.size ?? 1));
  const important = entity.type === 'town' || entity.type === 'village'
    || entity.type === 'abbey' || entity.type === 'tower';
  ctx.beginPath();
  if (important) {
    ctx.rect(x - 3 * size, y - 3 * size, 6 * size, 6 * size);
  } else {
    ctx.arc(x, y, 2.5 * size, 0, Math.PI * 2);
  }
  ctx.fillStyle = entity.style.color ?? (important ? '#f0dfbc' : '#c8b78e');
  ctx.fill();
  ctx.lineWidth = selected ? 2 : 1;
  ctx.strokeStyle = selected ? '#f5c66a' : 'rgba(6,8,13,0.9)';
  ctx.stroke();
}

function drawLandmark(
  ctx: CanvasRenderingContext2D,
  entity: WorldSpatialEntity,
  x: number,
  y: number,
  selected: boolean,
): void {
  const scale = Math.min(2.4, Math.max(0.65, entity.style.size ?? 1));
  const screenX = x;
  const screenY = y;
  const lm = {
    type: (entity.style.icon ?? entity.type) as LandmarkType,
  };
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  x = 0;
  y = 0;
  ctx.lineWidth = 1.2;
  switch (lm.type) {
    case 'volcano': {
      ctx.beginPath();
      ctx.moveTo(x, y - 5.5);
      ctx.lineTo(x + 5, y + 4);
      ctx.lineTo(x - 5, y + 4);
      ctx.closePath();
      ctx.fillStyle = '#8a3a30';
      ctx.fill();
      ctx.strokeStyle = 'rgba(7,7,13,0.8)';
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x, y - 5, 1.6, 0, Math.PI * 2);
      ctx.fillStyle = '#e4a853';
      ctx.fill();
      break;
    }
    case 'cave': {
      ctx.beginPath();
      ctx.arc(x, y + 2, 5, Math.PI, 0);
      ctx.closePath();
      ctx.fillStyle = '#2a2a3a';
      ctx.fill();
      ctx.strokeStyle = 'rgba(232,229,224,0.7)';
      ctx.stroke();
      break;
    }
    case 'waterfall': {
      ctx.strokeStyle = '#7fc0dd';
      ctx.lineWidth = 1.6;
      for (let k = -1; k <= 1; k++) {
        ctx.beginPath();
        ctx.moveTo(x + k * 2.4, y - 4);
        ctx.lineTo(x + k * 2.4, y + 3);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(x - 4.5, y + 4.5);
      ctx.quadraticCurveTo(x, y + 6.5, x + 4.5, y + 4.5);
      ctx.stroke();
      break;
    }
    case 'gorge': {
      ctx.strokeStyle = '#a06a3c';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(x - 5, y - 3.5);
      ctx.lineTo(x - 1.5, y + 3.5);
      ctx.moveTo(x + 5, y - 3.5);
      ctx.lineTo(x + 1.5, y + 3.5);
      ctx.stroke();
      break;
    }
    case 'hotspring': {
      ctx.beginPath();
      ctx.arc(x, y + 1.5, 3.4, 0, Math.PI * 2);
      ctx.fillStyle = '#d585a8';
      ctx.fill();
      ctx.strokeStyle = 'rgba(7,7,13,0.8)';
      ctx.stroke();
      ctx.strokeStyle = 'rgba(232,229,224,0.85)';
      ctx.lineWidth = 1.1;
      for (let k = -1; k <= 1; k++) {
        ctx.beginPath();
        ctx.moveTo(x + k * 2.2, y - 1.5);
        ctx.quadraticCurveTo(x + k * 2.2 + 1, y - 3.5, x + k * 2.2, y - 5.5);
        ctx.stroke();
      }
      break;
    }
  }
  ctx.restore();
  if (entity.style.color) {
    ctx.beginPath();
    ctx.arc(screenX, screenY, 7 * scale, 0, Math.PI * 2);
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = entity.style.color;
    ctx.stroke();
  }
  if (selected) {
    ctx.beginPath();
    ctx.arc(screenX, screenY, 9 * scale, 0, Math.PI * 2);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#f5c66a';
    ctx.stroke();
  }
}

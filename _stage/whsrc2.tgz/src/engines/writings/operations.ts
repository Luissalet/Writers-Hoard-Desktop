// ============================================
// Writings Engine — Database Operations
// ============================================

import { db } from '@/db';
import { deleteEntityAnnotations } from '@/engines/_shared/deleteEntityAnnotations';
import type { Writing } from '@/types';

export async function getWritings(projectId: string): Promise<Writing[]> {
  return db.writings.where('projectId').equals(projectId).toArray();
}

export async function getWriting(id: string): Promise<Writing | undefined> {
  return db.writings.get(id);
}

export async function createWriting(writing: Writing): Promise<string> {
  return db.writings.add(writing);
}

export async function updateWriting(id: string, changes: Partial<Writing>): Promise<void> {
  await db.writings.update(id, { ...changes, updatedAt: Date.now() });
}

/**
 * Delete a writing, its version history and its margin notes, and UNLINK the
 * outline beats that pointed at it.
 *
 * Same policy as `deleteScene`: what only exists inside the writing goes with
 * it — snapshots, and the annotations anchored on it with their reference
 * rows — while a beat is the author's own text and survives unassigned, ready
 * to be relinked.
 */
export async function deleteWriting(id: string): Promise<void> {
  const projectId = (await db.writings.get(id))?.projectId;

  await db.transaction(
    'rw',
    [db.writings, db.writingSnapshots, db.outlineBeats, db.annotations, db.annotationReferences],
    async () => {
      await db.writingSnapshots.where('writingId').equals(id).delete();

      const beatQuery = projectId
        ? db.outlineBeats.where('projectId').equals(projectId)
        : db.outlineBeats.toCollection();
      const linked = (await beatQuery.toArray()).filter(beat => beat.linkedWritingId === id);
      for (const beat of linked) {
        await db.outlineBeats.update(beat.id, { linkedWritingId: undefined });
      }

      await deleteEntityAnnotations('writings', id);

      await db.writings.delete(id);
    },
  );
}

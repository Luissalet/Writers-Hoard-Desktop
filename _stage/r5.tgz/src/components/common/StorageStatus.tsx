import { useCallback, useEffect, useState } from 'react';
import Dexie from 'dexie';
import { Database, ShieldCheck, ShieldAlert, X } from 'lucide-react';
import { getSetting, setSetting } from '@/db/operations';
import { ensurePersistentStorage } from '@/services/appInitialization';
import { useTranslation } from '@/i18n/useTranslation';
import { toast } from './toast';

interface StorageSnapshot {
  usage: number;
  quota: number;
  persisted: boolean;
}

/** Stamped when the writer dismisses the eviction warning, so it stays gone. */
const WARNING_DISMISSED_KEY = 'storage.evictionWarningDismissedAt';

// The chip and the warning line are two views of one fact. When the chip wins
// persistence, the warning has to go — without waiting for a remount.
type PersistenceListener = (persisted: boolean) => void;
const persistenceListeners = new Set<PersistenceListener>();

function formatBytes(value: number): string {
  if (value < 1024 * 1024) return `${Math.round(value / 1024)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  return `${(value / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

export default function StorageStatus() {
  const { t } = useTranslation();
  const [snapshot, setSnapshot] = useState<StorageSnapshot | null>(null);
  const refresh = useCallback(async () => {
    if (!navigator.storage?.estimate) return;
    const [estimate, persisted] = await Promise.all([
      navigator.storage.estimate(),
      navigator.storage.persisted?.() ?? false,
    ]);
    setSnapshot({
      usage: estimate.usage ?? 0,
      quota: estimate.quota ?? 0,
      persisted,
    });
  }, []);

  useEffect(() => {
    const initialRefresh = window.setTimeout(() => void refresh(), 0);
    const onMutation = () => void refresh();
    Dexie.on('storagemutated', onMutation);
    return () => {
      window.clearTimeout(initialRefresh);
      Dexie.on('storagemutated').unsubscribe(onMutation);
    };
  }, [refresh]);

  if (!snapshot) return null;
  const percentage = snapshot.quota ? Math.round((snapshot.usage / snapshot.quota) * 100) : 0;
  const requestPersistence = async () => {
    if (!navigator.storage.persist) return;
    const persisted = await navigator.storage.persist();
    await refresh();
    for (const listener of persistenceListeners) listener(persisted);
    if (persisted) toast.success(t('storage.persistEnabled'));
    else toast.info(t('storage.persistDenied'));
  };
  return (
    <button
      type="button"
      onClick={() => void requestPersistence()}
      className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs text-text-dim transition hover:bg-elevated hover:text-text-primary"
      title={t('storage.usageTooltip')
        .replace('{used}', formatBytes(snapshot.usage))
        .replace('{quota}', formatBytes(snapshot.quota))}
    >
      {snapshot.persisted ? <ShieldCheck size={14} className="text-green-400" /> : <Database size={14} />}
      <span>{percentage}%</span>
    </button>
  );
}

/**
 * The sentence the 14px chip was never going to say.
 *
 * An origin the browser has not marked persistent is evictable: the whole
 * library can be dropped under storage pressure, without a prompt and without a
 * trace. Startup already asked for persistence (`ensurePersistentStorage`); if
 * the answer was no, the writer deserves to be told in words, on the page they
 * land on, next to the button that makes a copy they own.
 *
 * Dismissible, and the dismissal is persisted — this warns once, it does not
 * nag forever.
 */
export function StoragePersistenceWarning() {
  const { t } = useTranslation();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let alive = true;
    void (async () => {
      const persisted = await ensurePersistentStorage();
      if (persisted || !alive) return;
      let dismissed: string | undefined;
      try {
        dismissed = await getSetting(WARNING_DISMISSED_KEY);
      } catch (error) {
        console.error('[storage] could not read the warning dismissal', error);
      }
      if (alive && !dismissed) setVisible(true);
    })();

    const onPersistence = (persisted: boolean) => {
      if (persisted) setVisible(false);
    };
    persistenceListeners.add(onPersistence);
    return () => {
      alive = false;
      persistenceListeners.delete(onPersistence);
    };
  }, []);

  if (!visible) return null;

  const dismiss = () => {
    setVisible(false);
    void setSetting(WARNING_DISMISSED_KEY, String(Date.now())).catch(error =>
      console.error('[storage] could not save the warning dismissal', error),
    );
  };

  return (
    <div
      role="status"
      className="mb-6 flex items-start gap-3 rounded-xl border border-warning/30 bg-warning/5 px-4 py-3"
    >
      <ShieldAlert size={16} className="mt-0.5 flex-shrink-0 text-warning" />
      <p className="flex-1 text-sm leading-relaxed text-text-primary">
        {t('storage.evictionWarning')}
      </p>
      <button
        type="button"
        onClick={dismiss}
        className="flex-shrink-0 text-text-dim transition hover:text-text-primary"
        aria-label={t('common.dismiss')}
        title={t('common.dismiss')}
      >
        <X size={14} />
      </button>
    </div>
  );
}

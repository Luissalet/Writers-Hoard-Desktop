// ============================================================================
// Copilot — backup strategy for the conversation tables
// ============================================================================
//
// Engineless tables, like the project-tools set: registered here and imported
// from engines/index.ts so the coverage guardrail sees them. Exports rows
// verbatim — messages are text and small tool cards, nothing binary — except
// for the trust fields, which never travel.

import type JSZip from 'jszip';
import {
  makeSimpleBackupStrategy,
  readBackupJson,
  registerBackupStrategy,
} from '@/engines/_shared';
import type { AiProjectSettings, AiThread } from './types';

export const AI_ASSISTANT_TABLES = ['aiThreads', 'aiMessages', 'aiProjectSettings'] as const;

const FOLDER = 'ai-assistant';

const simple = makeSimpleBackupStrategy({
  engineId: 'ai-assistant',
  tables: [...AI_ASSISTANT_TABLES],
});

/**
 * Consent to a remote model and the copilot's write permission belong to the
 * person sitting at this machine, never to whoever produced the archive. They
 * are cleared on the way out AND on the way in, so an archive written by an
 * older build — or by hand — still cannot raise them for the importer.
 */
async function clearTrustFields(zip: JSZip, projectDir: string): Promise<void> {
  const settingsPath = `${projectDir}/${FOLDER}/aiProjectSettings.json`;
  const settings = await readBackupJson<AiProjectSettings[]>(zip, settingsPath);
  if (settings?.length) {
    zip.file(settingsPath, JSON.stringify(
      settings.map((row): AiProjectSettings => ({
        ...row,
        defaultPolicy: 'ask',
        remoteConsent: false,
      })),
      null,
      2,
    ));
  }
  const threadsPath = `${projectDir}/${FOLDER}/aiThreads.json`;
  const threads = await readBackupJson<AiThread[]>(zip, threadsPath);
  if (threads?.length) {
    zip.file(threadsPath, JSON.stringify(
      threads.map((row): AiThread => ({ ...row, policy: 'ask' })),
      null,
      2,
    ));
  }
}

registerBackupStrategy({
  ...simple,
  async exportProject(context) {
    await simple.exportProject(context);
    await clearTrustFields(context.zip, context.projectDir);
  },
  async importProject(context) {
    await clearTrustFields(context.zip, context.projectDir);
    await simple.importProject(context);
  },
});

import { db } from '@/db';
import * as projectOps from '@/db/operations';
import { callAi } from '@/services/aiService';
import { searchProjectContent } from '@/services/projectSearchIndex';
import {
  canExportPdf,
  downloadBlobFile,
  downloadTextFile,
  exportHtmlPdf,
  renderPublishingHtml,
  renderPublishingMarkdown,
  sanitizeFilename,
} from '@/engines/writings/manuscriptExport';
import {
  composePublishingDocument,
  type PublishingDocument,
} from '@/engines/writings/publishingDocument';
import { generateId } from '@/utils/idGenerator';
import { stripHtml } from '@/utils/text';
import { t } from '@/i18n/useTranslation';
import { useLocaleStore } from '@/stores/localeStore';
import type { Project, ProjectMode, Writing } from '@/types';
import type {
  Citation,
  ConversionReceipt,
  EntityLink,
  PublishingFormat,
  PublishingProfile,
  PublishingSelectionMode,
} from '@/types/projectTools';

export interface ProjectRecipe {
  id: string;
  name: string;
  description: string;
  mode: ProjectMode;
  enabledEngines: string[];
  engineOrder: string[];
  custom?: boolean;
}

export interface GroundedAiPrivacy {
  enabled: boolean;
  allowRemoteRequests: boolean;
  includeDrafts: boolean;
  includeResearch: boolean;
  maxContextCharacters: number;
}

export interface GroundedAiResult {
  answer: string;
  sources: Array<{ id: string; engineId: string; title: string }>;
}

const TEMPLATE_SETTING = 'project-tools.templates';
const AI_PRIVACY_PREFIX = 'project-tools.ai-privacy.';

export const BUILT_IN_RECIPES: ProjectRecipe[] = [
  {
    id: 'recipe-novel',
    name: 'Novel production',
    description: 'Draft, structure, characters, continuity, and revision tools.',
    mode: 'novelist',
    enabledEngines: ['writings', 'outline', 'codex', 'timeline', 'character-arc', 'relationships', 'seeds', 'writing-stats', 'annotations', 'notes'],
    engineOrder: ['writings', 'outline', 'codex', 'timeline', 'character-arc', 'relationships', 'seeds', 'writing-stats', 'annotations', 'notes'],
  },
  {
    id: 'recipe-research',
    name: 'Research dossier',
    description: 'Capture sources, map facts, annotate evidence, and draft findings.',
    mode: 'reporter',
    enabledEngines: ['scrapper', 'notes', 'codex', 'timeline', 'biography', 'relationships', 'board', 'writings', 'annotations'],
    engineOrder: ['scrapper', 'notes', 'codex', 'timeline', 'biography', 'relationships', 'board', 'writings', 'annotations'],
  },
  {
    id: 'recipe-screen',
    name: 'Screen and stage',
    description: 'Scene-first planning with cast, storyboard, beats, and dialogue.',
    mode: 'playwright',
    enabledEngines: ['dialog-scene', 'outline', 'codex', 'storyboard', 'character-arc', 'relationships', 'seeds', 'gallery', 'annotations'],
    engineOrder: ['dialog-scene', 'outline', 'codex', 'storyboard', 'character-arc', 'relationships', 'seeds', 'gallery', 'annotations'],
  },
  {
    id: 'recipe-video',
    name: 'Video production',
    description: 'Research, script, visuals, shot planning, and teleprompter.',
    mode: 'content-creator',
    enabledEngines: ['scrapper', 'video-planner', 'storyboard', 'gallery', 'notes', 'writings', 'timeline'],
    engineOrder: ['scrapper', 'video-planner', 'storyboard', 'gallery', 'notes', 'writings', 'timeline'],
  },
];

function parseJson<T>(value: string | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export async function getProjectRecipes(): Promise<ProjectRecipe[]> {
  const custom = parseJson<ProjectRecipe[]>(
    await projectOps.getSetting(TEMPLATE_SETTING),
    [],
  );
  return [...BUILT_IN_RECIPES, ...custom.map(recipe => ({ ...recipe, custom: true }))];
}

export async function saveProjectAsRecipe(
  project: Project,
  name: string,
  description: string,
): Promise<ProjectRecipe> {
  const custom = parseJson<ProjectRecipe[]>(
    await projectOps.getSetting(TEMPLATE_SETTING),
    [],
  );
  const recipe: ProjectRecipe = {
    id: generateId('recipe'),
    name: name.trim() || project.title,
    description: description.trim(),
    mode: project.mode,
    enabledEngines: [...new Set(project.enabledEngines)],
    engineOrder: [...new Set(project.engineOrder)],
    custom: true,
  };
  await projectOps.setSetting(TEMPLATE_SETTING, JSON.stringify([...custom, recipe]));
  return recipe;
}

export async function deleteCustomRecipe(recipeId: string): Promise<void> {
  const custom = parseJson<ProjectRecipe[]>(
    await projectOps.getSetting(TEMPLATE_SETTING),
    [],
  );
  await projectOps.setSetting(
    TEMPLATE_SETTING,
    JSON.stringify(custom.filter(recipe => recipe.id !== recipeId)),
  );
}

export async function applyProjectRecipe(
  projectId: string,
  recipe: ProjectRecipe,
  mode: 'merge' | 'replace' = 'merge',
): Promise<void> {
  const project = await db.projects.get(projectId);
  if (!project) throw new Error('Project not found');
  const enabledEngines = mode === 'replace'
    ? [...recipe.enabledEngines]
    : [...new Set([...project.enabledEngines, ...recipe.enabledEngines])];
  const orderSource = mode === 'replace'
    ? recipe.engineOrder
    : [...project.engineOrder, ...recipe.engineOrder];
  const engineOrder = [...new Set(orderSource)].filter(id => enabledEngines.includes(id));
  await projectOps.updateProject(projectId, {
    mode: recipe.mode,
    enabledEngines,
    engineOrder: [...engineOrder, ...enabledEngines.filter(id => !engineOrder.includes(id))],
  });
}

export async function getCitations(projectId: string): Promise<Citation[]> {
  return db.citations.where('projectId').equals(projectId).reverse().sortBy('updatedAt');
}

export async function saveCitation(
  value: Omit<Citation, 'id' | 'createdAt' | 'updatedAt'> & { id?: string },
): Promise<Citation> {
  const now = Date.now();
  const existing = value.id ? await db.citations.get(value.id) : undefined;
  const citation: Citation = {
    ...value,
    id: value.id ?? generateId('cite'),
    authors: value.authors.filter(Boolean),
    tags: value.tags.filter(Boolean),
    writingIds: [...new Set(value.writingIds)],
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };
  await db.citations.put(citation);
  return citation;
}

export async function citationFromSnapshot(snapshotId: string): Promise<Citation> {
  const snapshot = await db.snapshots.get(snapshotId);
  if (!snapshot) throw new Error('Research snapshot not found');
  return saveCitation({
    projectId: snapshot.projectId,
    title: snapshot.title || snapshot.url,
    authors: snapshot.author ? [snapshot.author] : [],
    publishedAt: snapshot.publishDate,
    accessedAt: new Date(snapshot.preservedAt || snapshot.createdAt).toISOString().slice(0, 10),
    url: snapshot.url,
    notes: snapshot.notes,
    snapshotId: snapshot.id,
    writingIds: [],
    tags: snapshot.tags,
  });
}

export async function deleteCitation(id: string): Promise<void> {
  await db.citations.delete(id);
}

export interface CitationFormatLabels {
  locale: string;
  unknownAuthor: string;
  noDate: string;
  accessedLabel: string;
}

function currentCitationLabels(): CitationFormatLabels {
  return {
    locale: useLocaleStore.getState().locale,
    unknownAuthor: t('projectTools.research.unknownAuthor'),
    noDate: t('projectTools.research.noDate'),
    accessedLabel: t('projectTools.research.accessed'),
  };
}

export function formatCitation(
  citation: Citation,
  style: PublishingProfile['citationStyle'],
  labels: CitationFormatLabels = {
    locale: 'en-US',
    unknownAuthor: 'Unknown author',
    noDate: 'n.d.',
    accessedLabel: 'Accessed',
  },
): string {
  const authors = citation.authors.length ? citation.authors.join(', ') : labels.unknownAuthor;
  const year = citation.publishedAt?.slice(0, 4) || labels.noDate;
  const accessed = citation.accessedAt ? new Date(`${citation.accessedAt}T00:00:00`).toLocaleDateString(labels.locale) : '';
  if (style === 'mla') {
    return `${authors}. “${citation.title}.” ${citation.publisher ? `${citation.publisher}, ` : ''}${year}.${citation.url ? ` ${citation.url}.` : ''}${accessed ? ` ${labels.accessedLabel} ${accessed}.` : ''}`;
  }
  if (style === 'chicago') {
    return `${authors}. “${citation.title}.” ${citation.publisher ?? ''}${citation.publisher ? ', ' : ''}${year}.${citation.url ? ` ${citation.url}.` : ''}${accessed ? ` ${labels.accessedLabel} ${accessed}.` : ''}`;
  }
  return `${authors} (${year}). ${citation.title}.${citation.publisher ? ` ${citation.publisher}.` : ''}${citation.url ? ` ${citation.url}` : ''}`;
}

export async function exportBibliography(
  projectId: string,
  style: PublishingProfile['citationStyle'],
  projectTitle: string,
): Promise<void> {
  const citations = await getCitations(projectId);
  const text = citations
    .sort((a, b) => (a.authors[0] ?? '').localeCompare(b.authors[0] ?? ''))
    .map(citation => formatCitation(citation, style, currentCitationLabels()))
    .join('\n\n');
  downloadTextFile(
    `${projectTitle}\n${t('projectTools.research.bibliography')} (${style.toUpperCase()})\n\n${text}\n`,
    `${sanitizeFilename(projectTitle)}-bibliography-${style}.txt`,
    'text/plain',
  );
}

export async function getPublishingProfiles(projectId: string): Promise<PublishingProfile[]> {
  return db.publishingProfiles.where('projectId').equals(projectId).reverse().sortBy('updatedAt');
}

export interface NormalizedPublishingProfile extends PublishingProfile {
  selectionMode: PublishingSelectionMode;
  writingOrder: string[];
}

export interface PublishingResolution {
  profile: NormalizedPublishingProfile;
  writings: Writing[];
  missingWritingIds: string[];
  googleDocsWithoutContent: Writing[];
}

export interface PublishingArtifactLabels extends CitationFormatLabels {
  wordLabel: string;
  chapterLabel: string;
  bibliographyTitle: string;
}

export interface PublishingArtifacts {
  document: PublishingDocument;
  markdown: string;
  html: string;
  markdownFilename: string;
  htmlFilename: string;
  pdfFilename: string;
  docxFilename: string;
  epubFilename: string;
}

export type PublishingOutput = 'markdown' | 'html' | 'pdf' | 'docx' | 'epub';
export type PublishingExportReason =
  | 'no-writings'
  | 'google-docs-without-content'
  | 'pdf-unavailable'
  | 'export-failed';

export interface PublishingExportResult {
  ok: boolean;
  canceled?: boolean;
  reason?: PublishingExportReason;
  error?: string;
  missingWritingIds: string[];
  googleDocsWithoutContent: Array<{ id: string; title: string }>;
  omittedImageCount?: number;
}

function uniqueIds(ids: readonly string[] | undefined): string[] {
  return [...new Set(ids ?? [])].filter(Boolean);
}

export function normalizePublishingProfile(profile: PublishingProfile): NormalizedPublishingProfile {
  const selectedWritingIds = uniqueIds(profile.selectedWritingIds);
  return {
    ...profile,
    selectionMode: profile.selectionMode ?? (selectedWritingIds.length > 0 ? 'selected' : 'all'),
    selectedWritingIds,
    writingOrder: uniqueIds(profile.writingOrder),
  };
}

export function defaultPublishingOrder(writings: readonly Writing[]): Writing[] {
  return [...writings].sort((a, b) => {
    const chapter = (a.chapter ?? Number.MAX_SAFE_INTEGER) - (b.chapter ?? Number.MAX_SAFE_INTEGER);
    if (chapter !== 0) return chapter;
    if (a.createdAt !== b.createdAt) return a.createdAt - b.createdAt;
    return a.id.localeCompare(b.id);
  });
}

export function resolvePublishingWritings(
  allWritings: readonly Writing[],
  rawProfile: PublishingProfile,
): PublishingResolution {
  const profile = normalizePublishingProfile(rawProfile);
  const scoped = allWritings.filter(writing => writing.projectId === profile.projectId);
  const byId = new Map(scoped.map(writing => [writing.id, writing]));
  const fallbackOrder = defaultPublishingOrder(scoped);
  const seen = new Set<string>();
  const ordered: Writing[] = [];

  for (const id of profile.writingOrder) {
    const writing = byId.get(id);
    if (writing && !seen.has(id)) {
      seen.add(id);
      ordered.push(writing);
    }
  }
  for (const writing of fallbackOrder) {
    if (!seen.has(writing.id)) ordered.push(writing);
  }

  const selected = new Set(profile.selectedWritingIds);
  const writings = profile.selectionMode === 'all'
    ? ordered
    : ordered.filter(writing => selected.has(writing.id));
  const referencedIds = uniqueIds([...profile.selectedWritingIds, ...profile.writingOrder]);
  const missingWritingIds = referencedIds.filter(id => !byId.has(id));
  const googleDocsWithoutContent = writings.filter(
    writing => Boolean(writing.isGoogleDoc) && !stripHtml(writing.content).trim(),
  );

  return { profile, writings, missingWritingIds, googleDocsWithoutContent };
}

export async function savePublishingProfile(
  value: Omit<PublishingProfile, 'id' | 'createdAt' | 'updatedAt'> & { id?: string },
): Promise<PublishingProfile> {
  const now = Date.now();
  const existing = value.id ? await db.publishingProfiles.get(value.id) : undefined;
  const profile = normalizePublishingProfile({
    ...value,
    id: value.id ?? generateId('publish'),
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  });
  if (profile.selectionMode === 'selected' && profile.selectedWritingIds.length === 0) {
    throw new Error('A selected-only publishing profile must contain at least one writing.');
  }
  await db.publishingProfiles.put(profile);
  return profile;
}

export async function deletePublishingProfile(id: string): Promise<void> {
  await db.publishingProfiles.delete(id);
}

function currentPublishingLabels(format: PublishingFormat): PublishingArtifactLabels {
  return {
    ...currentCitationLabels(),
    wordLabel: t('writings.words'),
    chapterLabel: t(`projectTools.publishing.chapterLabel.${format}`),
    bibliographyTitle: t('projectTools.research.bibliography'),
  };
}

export function buildPublishingArtifacts(
  project: Pick<Project, 'id' | 'title'>,
  profile: PublishingProfile,
  writings: readonly Writing[],
  citations: readonly Citation[],
  artifactOptions: {
    labels?: PublishingArtifactLabels;
    titleOverride?: string;
    generatedAt?: number;
  } = {},
): PublishingArtifacts {
  const labels = artifactOptions.labels ?? currentPublishingLabels(profile.format);
  const documentTitle = artifactOptions.titleOverride ?? `${project.title} — ${profile.name}`;
  const compileOptions = {
    projectTitle: documentTitle,
    includeTitlePage: profile.includeTitlePage,
    includeSynopsis: profile.includeSynopsis,
    chapterLabel: labels.chapterLabel,
    wordLabel: labels.wordLabel,
    locale: labels.locale,
    generatedAt: artifactOptions.generatedAt,
  };
  const bibliography = profile.includeBibliography
    ? citations.map(citation => formatCitation(citation, profile.citationStyle, labels))
    : [];
  const document = composePublishingDocument(writings, {
    ...compileOptions,
    identifier: `urn:writers-hoard:${encodeURIComponent(project.id)}:${encodeURIComponent(profile.id || profile.name)}`,
    bibliographyTitle: bibliography.length ? labels.bibliographyTitle : undefined,
    bibliography,
  });
  const markdown = renderPublishingMarkdown(document);
  const html = renderPublishingHtml(document);
  const stem = sanitizeFilename(profile.name || project.title);
  return {
    document,
    markdown,
    html,
    markdownFilename: `${stem}.md`,
    htmlFilename: `${stem}.html`,
    pdfFilename: `${stem}.pdf`,
    docxFilename: `${stem}.docx`,
    epubFilename: `${stem}.epub`,
  };
}

export async function exportPublishingProfile(
  project: Pick<Project, 'id' | 'title'>,
  profile: PublishingProfile,
  output: PublishingOutput,
  artifactOptions: { titleOverride?: string; generatedAt?: number } = {},
): Promise<PublishingExportResult> {
  const allWritings = await db.writings.where('projectId').equals(project.id).toArray();
  const resolved = resolvePublishingWritings(allWritings, profile);
  const baseResult = {
    missingWritingIds: resolved.missingWritingIds,
    googleDocsWithoutContent: resolved.googleDocsWithoutContent.map(({ id, title }) => ({ id, title })),
  };
  if (resolved.writings.length === 0) {
    return { ok: false, reason: 'no-writings', ...baseResult };
  }
  if (resolved.googleDocsWithoutContent.length > 0) {
    return { ok: false, reason: 'google-docs-without-content', ...baseResult };
  }
  const citations = profile.includeBibliography ? await getCitations(project.id) : [];
  const artifacts = buildPublishingArtifacts(
    project,
    profile,
    resolved.writings,
    citations,
    artifactOptions,
  );

  if (output === 'markdown') {
    downloadTextFile(artifacts.markdown, artifacts.markdownFilename, 'text/markdown');
    return { ok: true, ...baseResult };
  }
  if (output === 'html') {
    downloadTextFile(artifacts.html, artifacts.htmlFilename, 'text/html');
    return { ok: true, ...baseResult };
  }
  if (output === 'pdf' && !canExportPdf()) {
    return { ok: false, reason: 'pdf-unavailable', ...baseResult };
  }
  try {
    if (output === 'docx') {
      const { buildPublishingDocx } = await import('@/engines/writings/publishingDocx');
      const blob = await buildPublishingDocx(artifacts.document);
      downloadBlobFile(blob, artifacts.docxFilename);
      return {
        ok: true,
        omittedImageCount: artifacts.document.omittedPortableImageCount,
        ...baseResult,
      };
    }
    if (output === 'epub') {
      const { buildPublishingEpub } = await import('@/engines/writings/publishingEpub');
      const blob = await buildPublishingEpub(artifacts.document);
      downloadBlobFile(blob, artifacts.epubFilename);
      return {
        ok: true,
        omittedImageCount: artifacts.document.omittedPortableImageCount,
        ...baseResult,
      };
    }
    const result = await exportHtmlPdf(artifacts.html, artifacts.pdfFilename);
    return result.ok
      ? { ok: true, ...baseResult }
      : { ok: false, canceled: result.canceled, reason: 'export-failed', error: result.error, ...baseResult };
  } catch (error) {
    return {
      ok: false,
      reason: 'export-failed',
      error: error instanceof Error ? error.message : String(error),
      ...baseResult,
    };
  }
}

async function createConversion(
  projectId: string,
  source: { engineId: string; entityType: string; id: string; title: string },
  writing: Writing,
): Promise<ConversionReceipt> {
  const now = Date.now();
  const receipt: ConversionReceipt = {
    id: generateId('conversion'),
    projectId,
    sourceEngineId: source.engineId,
    sourceEntityId: source.id,
    targetEngineId: 'writings',
    targetEntityId: writing.id,
    targetTable: 'writings',
    preview: `${source.title} → ${writing.title}`,
    undoPayload: { targetId: writing.id, targetTable: 'writings' },
    createdAt: now,
  };
  const link: EntityLink = {
    id: generateId('link'),
    projectId,
    sourceEngineId: source.engineId,
    sourceEntityType: source.entityType,
    sourceEntityId: source.id,
    sourceTitle: source.title,
    targetEngineId: 'writings',
    targetEntityType: 'writing',
    targetEntityId: writing.id,
    targetTitle: writing.title,
    relation: 'promoted-to',
    provenance: 'conversion',
    createdAt: now,
    updatedAt: now,
  };
  await db.transaction('rw', [db.writings, db.conversionReceipts, db.entityLinks], async () => {
    await db.writings.add(writing);
    await db.conversionReceipts.add(receipt);
    await db.entityLinks.add(link);
  });
  return receipt;
}

export async function promoteNoteToWriting(noteId: string): Promise<ConversionReceipt> {
  const note = await db.notes.get(noteId);
  if (!note) throw new Error('Note not found');
  const title = note.text.split('\n').find(line => line.trim())?.trim().slice(0, 80) || 'Promoted note';
  const writing: Writing = {
    id: generateId('wrt'),
    projectId: note.projectId,
    title,
    status: 'idea',
    content: `<p>${note.text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\n/g, '</p><p>')}</p>`,
    wordCount: note.text.trim().split(/\s+/).filter(Boolean).length,
    tags: [...note.tags],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  return createConversion(note.projectId, { engineId: 'notes', entityType: 'note', id: note.id, title }, writing);
}

export async function promoteDiaryToWriting(entryId: string): Promise<ConversionReceipt> {
  const entry = await db.diaryEntries.get(entryId);
  if (!entry) throw new Error('Diary entry not found');
  const writing: Writing = {
    id: generateId('wrt'),
    projectId: entry.projectId,
    title: entry.title || `Diary — ${entry.entryDate}`,
    status: 'idea',
    content: entry.content,
    wordCount: stripHtml(entry.content).trim().split(/\s+/).filter(Boolean).length,
    tags: [...entry.tags],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  return createConversion(entry.projectId, { engineId: 'diary', entityType: 'diary-entry', id: entry.id, title: writing.title }, writing);
}

export async function promoteSnapshotToWriting(snapshotId: string): Promise<ConversionReceipt> {
  const snapshot = await db.snapshots.get(snapshotId);
  if (!snapshot) throw new Error('Research snapshot not found');
  const sourceText = snapshot.extractedText || snapshot.notes || snapshot.description || snapshot.url;
  const writing: Writing = {
    id: generateId('wrt'),
    projectId: snapshot.projectId,
    title: snapshot.title || 'Research draft',
    status: 'idea',
    content: `<p>${sourceText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\n/g, '</p><p>')}</p><p><a href="${snapshot.url}">${snapshot.url}</a></p>`,
    wordCount: sourceText.trim().split(/\s+/).filter(Boolean).length,
    tags: [...snapshot.tags],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  return createConversion(snapshot.projectId, { engineId: 'scrapper', entityType: 'snapshot', id: snapshot.id, title: writing.title }, writing);
}

export async function undoConversion(receiptId: string): Promise<void> {
  const receipt = await db.conversionReceipts.get(receiptId);
  if (!receipt || receipt.undoneAt) return;
  if (receipt.targetTable !== 'writings') throw new Error('Unsupported conversion target');
  await db.transaction('rw', [db.writings, db.writingSnapshots, db.entityLinks, db.conversionReceipts], async () => {
    await db.writingSnapshots.where('writingId').equals(receipt.targetEntityId).delete();
    await db.writings.delete(receipt.targetEntityId);
    await db.entityLinks.where('targetEntityId').equals(receipt.targetEntityId).delete();
    await db.conversionReceipts.update(receipt.id, { undoneAt: Date.now() });
  });
}

export async function getGroundedAiPrivacy(projectId: string): Promise<GroundedAiPrivacy> {
  return {
    enabled: false,
    allowRemoteRequests: false,
    includeDrafts: true,
    includeResearch: true,
    maxContextCharacters: 24_000,
    ...parseJson<Partial<GroundedAiPrivacy>>(
      await projectOps.getSetting(`${AI_PRIVACY_PREFIX}${projectId}`),
      {},
    ),
  };
}

export async function saveGroundedAiPrivacy(
  projectId: string,
  privacy: GroundedAiPrivacy,
): Promise<void> {
  await projectOps.setSetting(`${AI_PRIVACY_PREFIX}${projectId}`, JSON.stringify(privacy));
}

export async function runGroundedProjectAnalysis(
  projectId: string,
  question: string,
  config: Parameters<typeof callAi>[2],
): Promise<GroundedAiResult> {
  const privacy = await getGroundedAiPrivacy(projectId);
  if (!privacy.enabled || !privacy.allowRemoteRequests) {
    throw new Error('Project-grounded AI is disabled by this project’s privacy controls.');
  }
  const hits = await searchProjectContent(question, projectId, 12);
  const allowed = hits.filter(hit =>
    (privacy.includeDrafts || hit.engineId !== 'writings') &&
    (privacy.includeResearch || hit.engineId !== 'scrapper'),
  );
  let used = 0;
  const context: string[] = [];
  const sources: GroundedAiResult['sources'] = [];
  for (const [index, hit] of allowed.entries()) {
    const sourceId = `S${index + 1}`;
    const block = `[${sourceId}] ${hit.engineId}: ${hit.title}\n${hit.snippet}`;
    if (used + block.length > privacy.maxContextCharacters) break;
    used += block.length;
    context.push(block);
    sources.push({ id: sourceId, engineId: hit.engineId, title: hit.title });
  }
  const answer = await callAi(
    'Answer only from the supplied project excerpts. Cite supporting excerpts with their [S#] identifiers. If the context is insufficient, say so explicitly. Never claim access to files that are not in the context.',
    `Question: ${question}\n\nProject excerpts:\n${context.join('\n\n')}`,
    config,
  );
  return { answer, sources };
}

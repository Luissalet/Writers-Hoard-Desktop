// ============================================
// Saving the book — one diff, one pass over the rows
// ============================================
//
// The book editor autosaves the whole document, and this is the whole of
// what that means: cut the document into sections (`bookDocument.ts`), diff
// them against the rows this session last saw, and write only what moved.
// Pure-async on purpose — it takes sections and a baseline and returns the
// next baseline — so the policy can be tested against a real Dexie without
// mounting an editor, and so `BookEditor.tsx` is left with only what a view
// can do: run it on a timer, stamp new ids on headings, and say what happened.
//
// The rules, in the order they are applied:
//
//   • An UPDATE is a guarded write (`updateWritingAtVersion` against the
//     baseline's version). A row that moved underneath the book is refused
//     and reported, never overwritten; the session marks it contested and
//     asks the writer.
//   • A CREATE is a new row for a heading that has none: the writer pressed
//     "Chapter" (or typed `# `), or wrote prose above the first heading.
//   • A MISSING row — in the baseline, no heading in the document — is deleted
//     ONLY when the writer confirmed the merge that removed its heading. Any
//     other missing row is refused back to the caller, which puts the heading
//     back. Nothing is ever deleted on the strength of a diff alone, and no
//     deletion happens in a pass that also had a conflict: the prose the
//     merge moved has to be confirmed on disk before the row that held it goes.
//   • After anything structural — a row created or deleted, a chapter moved —
//     the range is renumbered along the document's order, `firstChapter`
//     onwards, with the same guarded write. Numbers already outside the
//     range that the new numbering lands on are reported as collisions.

import type { Writing } from '@/types';
import { countWords } from '@/utils/text';
import { generateId } from '@/utils/idGenerator';
import { diffBookSections, type BookSection } from './bookDocument';
import {
  createWriting,
  deleteWritingRestorable,
  updateWritingAtVersion,
  WritingConflictError,
  WritingGoneError,
  type DeletedWritingBundle,
} from './operations';

/** A row as this book session last saw it confirmed on disk. */
export interface BookBaselineEntry {
  title: string;
  /** Canonical prose (see `canonicalHtml`), without the heading. */
  html: string;
  /** The row's version token — what every write is made against. */
  version: number;
  chapter: number;
  wordCount: number;
}

/** Keyed by writing id, in book order. */
export type BookBaseline = Map<string, BookBaselineEntry>;

export type BookConflict =
  /** The row moved under the book; `current` is the text that won. */
  | { writingId: string; kind: 'moved'; current: Writing }
  /** The row is gone — deleted somewhere else while the book was open. */
  | { writingId: string; kind: 'gone' };

export interface SaveBookOptions {
  projectId: string;
  baseline: BookBaseline;
  sections: readonly BookSection[];
  /** Rows the writer agreed to delete by merging their chapter into the one before. */
  confirmedDeletes: ReadonlySet<string>;
  /** Rows waiting on the conflict banner: not written, not renumbered. */
  contested?: ReadonlySet<string>;
  /** Number the first section takes: 1 for the whole book, else the range's first. */
  firstChapter: number;
  /** Numbers held by chapters outside the range, to report a clash. */
  outsideChapters?: ReadonlySet<number>;
  /** Title for a row created from a heading with no text. */
  untitledTitle: string;
}

export interface SaveBookResult {
  baseline: BookBaseline;
  /** Rows created this pass, with the section (and heading) each belongs to. */
  created: { index: number; clientId: string | null; writingId: string; chapter: number }[];
  /** Rows deleted this pass, each restorable. */
  deleted: DeletedWritingBundle[];
  /** Rows that lost their heading without a confirmed merge. Still on disk. */
  refusedMissing: string[];
  /**
   * Confirmed merges held back because this pass had a conflict: the prose
   * they moved is not confirmed on disk yet. The confirmation stands, and the
   * next clean pass deletes them.
   */
  deferredDeletes: string[];
  conflicts: BookConflict[];
  /** Chapter numbers the range now shares with chapters outside it. */
  collisions: number[];
  /** Whether anything reached the database. */
  wrote: boolean;
}

/** Hand a refused write to the caller as a conflict; let anything else throw. */
function toConflict(err: unknown, writingId: string): BookConflict {
  if (err instanceof WritingConflictError) return { writingId, kind: 'moved', current: err.current };
  if (err instanceof WritingGoneError) return { writingId, kind: 'gone' };
  throw err;
}

export async function saveBook(options: SaveBookOptions): Promise<SaveBookResult> {
  const { projectId, baseline, sections, confirmedDeletes, firstChapter, untitledTitle } = options;
  const contested = options.contested ?? new Set<string>();
  const outsideChapters = options.outsideChapters ?? new Set<number>();
  const diff = diffBookSections(baseline, sections);

  const next: BookBaseline = new Map(baseline);
  const result: SaveBookResult = {
    baseline: next,
    created: [],
    deleted: [],
    refusedMissing: [],
    deferredDeletes: [],
    conflicts: [],
    collisions: [],
    wrote: false,
  };

  // ---- updates ----
  for (const update of diff.updates) {
    const entry = next.get(update.writingId);
    if (!entry || contested.has(update.writingId)) continue;
    const wordCount = countWords(update.html);
    const title = update.title.trim() || untitledTitle;
    try {
      const version = await updateWritingAtVersion(
        update.writingId,
        { title, content: update.html, wordCount },
        entry.version,
      );
      // The baseline keeps the heading's own text, not the title the row was
      // given: a heading left empty must not read as a title change on every
      // pass.
      next.set(update.writingId, {
        ...entry,
        title: update.title.trim(),
        html: update.html,
        wordCount,
        version,
      });
      result.wrote = true;
    } catch (err) {
      result.conflicts.push(toConflict(err, update.writingId));
    }
  }

  // ---- creates ----
  // The section order after this pass, with the new ids in place.
  const order: (string | null)[] = [...diff.order];
  for (const create of diff.creates) {
    const now = Date.now();
    const id = generateId('wrt');
    const title = create.title.trim() || untitledTitle;
    const wordCount = countWords(create.html);
    // A provisional number: the renumbering below settles it against the
    // rest of the range in the same pass.
    const chapter = firstChapter + create.index;
    await createWriting({
      id,
      projectId,
      title,
      status: 'draft',
      content: create.html,
      wordCount,
      chapter,
      tags: [],
      createdAt: now,
      updatedAt: now,
    });
    next.set(id, { title: create.title.trim(), html: create.html, version: now, chapter, wordCount });
    order[create.index] = id;
    result.created.push({ index: create.index, clientId: create.clientId, writingId: id, chapter });
    result.wrote = true;
  }

  // ---- missing ----
  const deletedIds: string[] = [];
  for (const id of diff.missing) {
    if (!confirmedDeletes.has(id)) {
      result.refusedMissing.push(id);
      continue;
    }
    if (result.conflicts.length > 0) {
      result.deferredDeletes.push(id);
      continue;
    }
    const bundle = await deleteWritingRestorable(id);
    next.delete(id);
    deletedIds.push(id);
    if (bundle) result.deleted.push(bundle);
    result.wrote = true;
  }

  // ---- numbering ----
  const docIds = order.filter((id): id is string => id !== null);
  const docIdSet = new Set(docIds);
  const previousOrder = [...baseline.keys()].filter((id) => docIdSet.has(id));
  const orderChanged =
    previousOrder.length !== docIds.length || previousOrder.some((id, index) => id !== docIds[index]);
  if (result.created.length > 0 || deletedIds.length > 0 || orderChanged) {
    for (let index = 0; index < docIds.length; index++) {
      const id = docIds[index];
      const chapter = firstChapter + index;
      if (outsideChapters.has(chapter)) result.collisions.push(chapter);
      const entry = next.get(id);
      if (!entry || entry.chapter === chapter || contested.has(id)) continue;
      try {
        const version = await updateWritingAtVersion(id, { chapter }, entry.version);
        next.set(id, { ...entry, chapter, version });
        result.wrote = true;
      } catch (err) {
        result.conflicts.push(toConflict(err, id));
      }
    }
  }

  // ---- the next baseline, in document order ----
  // Refused rows keep their old place, so the caller's reinsertion and the
  // next diff agree about where they belong.
  const ordered: BookBaseline = new Map();
  const remaining = new Set(next.keys());
  for (const id of docIds) {
    const entry = next.get(id);
    if (entry) ordered.set(id, entry);
    remaining.delete(id);
  }
  if (remaining.size > 0) {
    const baselineOrder = [...baseline.keys()];
    const merged = [...ordered.keys()];
    for (const id of baselineOrder) {
      if (!remaining.has(id)) continue;
      const at = Math.min(baselineOrder.indexOf(id), merged.length);
      merged.splice(at, 0, id);
    }
    const rebuilt: BookBaseline = new Map();
    for (const id of merged) {
      const entry = next.get(id);
      if (entry) rebuilt.set(id, entry);
    }
    result.baseline = rebuilt;
  } else {
    result.baseline = ordered;
  }
  return result;
}

import { useEffect, useState } from 'react';
import type { Editor } from '@tiptap/react';
import { collectFootnotes, sameFootnotes, type FootnoteRef } from './footnoteModel';

/**
 * The document's footnotes, in order, refreshed on every edit and handed
 * back by the same reference for as long as no id or text has changed — so a
 * panel built on it does not re-render while the writer types prose.
 */
export function useFootnotes(editor: Editor | null): FootnoteRef[] {
  const [notes, setNotes] = useState<FootnoteRef[]>(() =>
    editor ? collectFootnotes(editor.state.doc) : [],
  );
  // A new editor (or none) resets the list during render — the sanctioned
  // shape for state derived from a prop, and the reason there is no setState
  // in the effect below.
  const [source, setSource] = useState(editor);
  if (source !== editor) {
    setSource(editor);
    setNotes(editor ? collectFootnotes(editor.state.doc) : []);
  }

  useEffect(() => {
    if (!editor) return;
    const refresh = () => {
      const next = collectFootnotes(editor.state.doc);
      setNotes((current) => (sameFootnotes(current, next) ? current : next));
    };
    editor.on('update', refresh);
    return () => {
      editor.off('update', refresh);
    };
  }, [editor]);

  return notes;
}

import type { Node as ProseMirrorNode } from '@tiptap/pm/model';
import type { FootnoteMarkerStyle } from '@/types';

/**
 * Footnotes, as data.
 *
 * A footnote lives in the document as one inline atom node, serialised to
 * `<sup data-footnote-id="…" data-footnote="…" class="wh-footnote-ref"></sup>`.
 * The body travels in the attribute on purpose: it is not prose, so it must
 * not be counted, searched, spell-checked or wrapped as prose, and the
 * sanitizer keeps `data-*` while dropping anything more inventive. The number
 * is nowhere in the markup — a CSS counter prints it in the editor and the
 * reader, so notes renumber themselves when one is added, moved or deleted.
 *
 * Nothing here imports Tiptap. The exporters and the reading view work from
 * persisted HTML and need the same numbering the editor shows, so the order
 * of the notes is defined once, here, as document order.
 */

export const FOOTNOTE_NODE_NAME = 'footnote';
export const FOOTNOTE_REF_CLASS = 'wh-footnote-ref';
export const FOOTNOTE_ID_ATTR = 'data-footnote-id';
export const FOOTNOTE_TEXT_ATTR = 'data-footnote';
export const FOOTNOTE_REF_SELECTOR = `sup[${FOOTNOTE_ID_ATTR}]`;

export const FOOTNOTE_MARKER_STYLES: readonly FootnoteMarkerStyle[] = ['numbers', 'symbols', 'roman', 'letters'];
export const DEFAULT_FOOTNOTE_STYLE: FootnoteMarkerStyle = 'numbers';

/** The classic printer's sequence; past the sixth note the symbols double, as in print. */
const MARKER_SYMBOLS = ['*', '†', '‡', '§', '‖', '¶'];

/** A style name from anywhere (a row, a setting) that may be stale or garbage. */
export function normalizeFootnoteStyle(value: unknown): FootnoteMarkerStyle {
  return FOOTNOTE_MARKER_STYLES.includes(value as FootnoteMarkerStyle)
    ? (value as FootnoteMarkerStyle)
    : DEFAULT_FOOTNOTE_STYLE;
}

function toRoman(n: number): string {
  const table: [number, string][] = [
    [1000, 'm'], [900, 'cm'], [500, 'd'], [400, 'cd'], [100, 'c'], [90, 'xc'],
    [50, 'l'], [40, 'xl'], [10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i'],
  ];
  let rest = n;
  let out = '';
  for (const [value, glyph] of table) {
    while (rest >= value) {
      out += glyph;
      rest -= value;
    }
  }
  return out;
}

function toLetters(n: number): string {
  // a..z, then aa..az, ba.. — the spreadsheet column scheme (bijective base 26).
  let rest = n;
  let out = '';
  while (rest > 0) {
    const digit = (rest - 1) % 26;
    out = String.fromCharCode(97 + digit) + out;
    rest = Math.floor((rest - 1) / 26);
  }
  return out;
}

/**
 * The marker printed for the n-th note (1-based) in a style. This is the
 * one place that decides it; the CSS counter styles in `index.css` mirror it
 * for the editor and the reader, and the exporters that print markers
 * themselves (HTML, PDF, EPUB) call this.
 */
export function formatFootnoteMarker(index: number, style: FootnoteMarkerStyle): string {
  const n = Math.max(1, Math.floor(index));
  switch (style) {
    case 'symbols': {
      const symbol = MARKER_SYMBOLS[(n - 1) % MARKER_SYMBOLS.length];
      return symbol.repeat(Math.floor((n - 1) / MARKER_SYMBOLS.length) + 1);
    }
    case 'roman':
      return toRoman(n);
    case 'letters':
      return toLetters(n);
    default:
      return String(n);
  }
}

/** A note found in a live ProseMirror document. */
export interface FootnoteRef {
  id: string;
  text: string;
  /** Position of the node when it was collected; an edit above it moves it. */
  pos: number;
  /** 1-based, in document order. */
  index: number;
}

/** A note read out of persisted HTML. */
export interface ExtractedFootnote {
  id: string;
  text: string;
  /** 1-based, in the order the references appear. */
  index: number;
}

/** Every footnote in the document, numbered in reading order. */
export function collectFootnotes(doc: ProseMirrorNode): FootnoteRef[] {
  const notes: FootnoteRef[] = [];
  doc.descendants((node, pos) => {
    if (node.type.name !== FOOTNOTE_NODE_NAME) return true;
    notes.push({
      id: String(node.attrs.id ?? ''),
      text: String(node.attrs.text ?? ''),
      pos,
      index: notes.length + 1,
    });
    return false;
  });
  return notes;
}

/** Where one note is right now, or `null` when the document no longer holds it. */
export function findFootnote(
  doc: ProseMirrorNode,
  id: string,
): { node: ProseMirrorNode; pos: number } | null {
  let found: { node: ProseMirrorNode; pos: number } | null = null;
  doc.descendants((node, pos) => {
    if (found) return false;
    if (node.type.name === FOOTNOTE_NODE_NAME && node.attrs.id === id) {
      found = { node, pos };
      return false;
    }
    return true;
  });
  return found;
}

/** Same ids, same texts, same order: the list a panel shows has not changed. */
export function sameFootnotes(
  left: readonly Pick<FootnoteRef, 'id' | 'text'>[],
  right: readonly Pick<FootnoteRef, 'id' | 'text'>[],
): boolean {
  if (left.length !== right.length) return false;
  for (let at = 0; at < left.length; at += 1) {
    if (left[at].id !== right[at].id || left[at].text !== right[at].text) return false;
  }
  return true;
}

function parseFragment(html: string): HTMLElement {
  return new DOMParser().parseFromString(html, 'text/html').body;
}

function readRef(element: Element, index: number): ExtractedFootnote {
  return {
    id: element.getAttribute(FOOTNOTE_ID_ATTR) ?? '',
    text: element.getAttribute(FOOTNOTE_TEXT_ATTR) ?? '',
    index,
  };
}

/**
 * The notes of a persisted body, numbered as the editor numbers them.
 *
 * `DOMParser`, not a regex: the serialiser leaves `<` and `>` unescaped inside
 * attribute values, so a note reading "a > b" would cut a pattern short.
 */
export function extractFootnotesFromHtml(html: string): ExtractedFootnote[] {
  if (!html.includes(FOOTNOTE_ID_ATTR)) return [];
  return [...parseFragment(html).querySelectorAll(FOOTNOTE_REF_SELECTOR)].map((element, at) =>
    readRef(element, at + 1),
  );
}

/**
 * The body with every reference replaced by whatever an exporter prints in
 * its place — a numbered link, a Markdown marker — and the notes it found.
 *
 * `start` lets a format that numbers the whole book continuously (DOCX) pick
 * up where the previous chapter stopped; the others restart at 1. A body with
 * no references is returned untouched, byte for byte, so this pass costs a
 * chapter without notes nothing and cannot re-serialise it.
 */
export function renderFootnoteRefs(
  html: string,
  render: (note: ExtractedFootnote) => string,
  start = 1,
): { html: string; notes: ExtractedFootnote[] } {
  if (!html.includes(FOOTNOTE_ID_ATTR)) return { html, notes: [] };
  const body = parseFragment(html);
  const notes: ExtractedFootnote[] = [];
  for (const element of [...body.querySelectorAll(FOOTNOTE_REF_SELECTOR)]) {
    const note = readRef(element, start + notes.length);
    notes.push(note);
    const holder = body.ownerDocument.createElement('span');
    holder.innerHTML = render(note);
    element.replaceWith(...holder.childNodes);
  }
  return { html: body.innerHTML, notes };
}

export function escapeFootnoteHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** A note's body as inline HTML: escaped, with its line breaks kept. */
export function footnoteTextHtml(text: string): string {
  return text.split(/\r?\n/).map(escapeFootnoteHtml).join('<br>');
}

export interface EndnotesOptions {
  heading: string;
  /** Marker style; the `<ol>` then prints the marker itself rather than a decimal. */
  style?: FootnoteMarkerStyle;
  /**
   * Link each note back to `#fnref-<id>`. On by default for the exporters,
   * whose references carry that id; off for the reading view, whose
   * references do not (and whose sanitizer renames ids anyway).
   */
  backlinks?: boolean;
}

/**
 * The notes of one chapter as a section to print after its prose.
 *
 * Numbers come from the `<ol>`, not from the note's `index`: the list is
 * built in order, so the two agree, and a renderer that has no CSS (a mail
 * client, a plain reader) still shows them.
 */
export function renderEndnotesHtml(
  notes: readonly ExtractedFootnote[],
  options: EndnotesOptions,
): string {
  if (notes.length === 0) return '';
  const backlinks = options.backlinks ?? true;
  const items = notes
    .map((note) => {
      const id = escapeFootnoteHtml(note.id);
      const back = backlinks
        ? ` <a href="#fnref-${id}" class="wh-endnote-back" aria-label="${escapeFootnoteHtml(options.heading)} ${note.index}">↩</a>`
        : '';
      const marker = options.style && options.style !== 'numbers'
        ? `<span class="wh-endnote-marker">${escapeFootnoteHtml(formatFootnoteMarker(note.index, options.style))}</span> `
        : '';
      return `<li id="fn-${id}">${marker}${footnoteTextHtml(note.text)}${back}</li>`;
    })
    .join('');
  const listClass = options.style && options.style !== 'numbers' ? ' class="wh-endnotes-marked"' : '';
  return `<section class="wh-endnotes"><h2>${escapeFootnoteHtml(options.heading)}</h2><ol${listClass}>${items}</ol></section>`;
}

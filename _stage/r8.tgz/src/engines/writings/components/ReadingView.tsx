import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ListTree, PenLine, X } from 'lucide-react';
import type { Writing } from '@/types';
import { useTranslation } from '@/i18n/useTranslation';
import { useAppStore } from '@/stores/appStore';
import { sanitizedHtml } from '@/utils/sanitizeRichHtml';
import {
  estimatePieceHeight,
  manuscriptProgress,
  measureWords,
  positionAt,
  sameWindow,
  sumHeights,
  windowAround,
  wordPrefixes,
  type PieceWindow,
} from '../readingWindow';

/** One arrow press of prose. */
const LINE_STEP_PX = 96;
/** Space / PageDown leave a couple of lines of overlap, the way a book does. */
const PAGE_FRACTION = 0.9;

interface ReadingPieceProps {
  piece: Writing;
  words: number;
  onOpenInEditor: (writing: Writing) => void;
}

/**
 * One piece of the manuscript, read-only.
 *
 * Memoised, and every prop it takes is stable: the reader scrolls sixty times
 * a second and the view above re-renders whenever the reading position moves,
 * but the prose is set once per mount. Without this, `sanitizedHtml` would
 * hand React a new `__html` string on every one of those renders and the
 * browser would re-parse four chapters of HTML per scroll.
 *
 * The class names are the app's prose stylesheet (`index.css` keys the
 * manuscript's face, size and measure off `.tiptap-editor .ProseMirror`), so a
 * chapter reads here exactly as it reads in the editor. There is no editor
 * behind it: no `contentEditable`, no TipTap instance, nothing that writes.
 */
const ReadingPiece = memo(function ReadingPiece({ piece, words, onOpenInEditor }: ReadingPieceProps) {
  const { t, locale } = useTranslation();
  const column = { maxWidth: 'var(--wh-reading-measure)' };

  return (
    <article data-piece-id={piece.id} className="px-6 pt-8 pb-2">
      <header className="mx-auto flex items-start gap-3" style={column}>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-text-dim font-medium">
            {piece.chapter !== undefined && <span>{t('writings.chapter')} {piece.chapter}</span>}
            <span>{words.toLocaleString(locale)} {t('writings.words')}</span>
          </p>
          <h2 className="font-serif text-2xl font-bold text-text-primary">
            {piece.title || t('writings.untitled')}
          </h2>
          {piece.synopsis && (
            <p className="mt-1 text-xs italic text-text-muted">{piece.synopsis}</p>
          )}
        </div>
        <button
          type="button"
          onClick={() => onOpenInEditor(piece)}
          title={t('writings.reading.openInEditor')}
          className="flex flex-shrink-0 items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border text-xs text-text-muted transition hover:text-accent-gold hover:border-accent-gold/40"
        >
          <PenLine size={13} />
          {t('writings.reading.openInEditor')}
        </button>
      </header>

      {piece.content.trim() ? (
        <div className="tiptap-editor mt-2">
          <div className="ProseMirror" dangerouslySetInnerHTML={sanitizedHtml(piece.content)} />
        </div>
      ) : (
        <p className="mx-auto mt-4 text-sm italic text-text-dim" style={column}>
          {t('writings.reading.emptyPiece')}
        </p>
      )}

      <div className="mx-auto mt-6 h-px bg-border/70" style={column} />
    </article>
  );
});

interface ReadingViewProps {
  /** The pieces to read, already in manuscript order. */
  pieces: Writing[];
  /** Where to open — the chapter the writer had in the editor, when there was one. */
  startId?: string | null;
  onClose: () => void;
  onOpenInEditor: (writing: Writing) => void;
}

/**
 * The manuscript as one continuous scroll, set with the writer's own reading
 * preferences and holding at most four chapters of DOM (see `readingWindow.ts`
 * for the bound). Read-only by construction: this file imports nothing that
 * writes, and the single action it offers per piece hands the writing back to
 * the host to open in the editor.
 */
export default function ReadingView({ pieces, startId, onClose, onOpenInEditor }: ReadingViewProps) {
  const { t, locale } = useTranslation();
  const reading = useAppStore((s) => s.reading);
  const loadReading = useAppStore((s) => s.loadReading);

  useEffect(() => {
    void loadReading();
  }, [loadReading]);

  const startIndex = useMemo(() => {
    const found = startId ? pieces.findIndex((piece) => piece.id === startId) : -1;
    return found >= 0 ? found : 0;
  }, [pieces, startId]);

  const [activeIndex, setActiveIndex] = useState(startIndex);
  const [pieceWindow, setPieceWindow] = useState<PieceWindow>(() =>
    windowAround(startIndex, pieces.length),
  );
  const [railOpen, setRailOpen] = useState(true);

  const scrollerRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLElement>(null);
  const leadRef = useRef<HTMLDivElement>(null);
  const tailRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const percentRef = useRef<HTMLSpanElement>(null);
  /** Measured heights by piece id — what a piece cost the last time it was mounted. */
  const heightsRef = useRef(new Map<string, number>());
  /** The paragraph under the top of the viewport, so a mount above it can be undone. */
  const anchorRef = useRef<{ id: string; offset: number } | null>(null);
  /** A jump waiting for its piece to mount. */
  const jumpRef = useRef<string | null>(null);
  /** The opening jump is made once, not again every time the list refreshes. */
  const startedRef = useRef(false);

  const words = useMemo(() => measureWords(pieces), [pieces]);
  const prefixes = useMemo(() => wordPrefixes(words), [words]);
  const totalWords = prefixes[prefixes.length - 1] ?? 0;

  const heightOf = useCallback(
    (index: number): number => {
      const piece = pieces[index];
      if (!piece) return 0;
      return heightsRef.current.get(piece.id) ?? estimatePieceHeight(words[index] ?? 0);
    },
    [pieces, words],
  );

  const paintProgress = useCallback(
    (scrollTop: number) => {
      const position = positionAt(scrollTop, pieces.length, heightOf);
      const fraction = manuscriptProgress(position, prefixes, totalWords);
      if (barRef.current) barRef.current.style.width = `${(fraction * 100).toFixed(1)}%`;
      if (percentRef.current) {
        percentRef.current.textContent = fraction.toLocaleString(locale, {
          style: 'percent',
          maximumFractionDigits: 0,
        });
      }
      return position;
    },
    [heightOf, locale, pieces.length, prefixes, totalWords],
  );

  const pieceElement = useCallback((scroller: HTMLElement, id: string) => {
    return scroller.querySelector<HTMLElement>(`[data-piece-id="${CSS.escape(id)}"]`);
  }, []);

  /**
   * Re-lay the two spacers over everything that is not mounted, then put the
   * reading position back. Both halves matter: the spacers keep the scrollbar
   * honest about a book the DOM does not hold, and the anchor keeps the
   * paragraph on screen from sliding when a piece mounts above it at its real
   * height instead of its estimate.
   */
  const settleLayout = useCallback(
    (view: PieceWindow) => {
      const scroller = scrollerRef.current;
      if (!scroller) return;

      scroller.querySelectorAll<HTMLElement>('[data-piece-id]').forEach((element) => {
        const id = element.dataset.pieceId;
        if (id) heightsRef.current.set(id, element.offsetHeight);
      });

      if (leadRef.current) {
        leadRef.current.style.height = `${sumHeights(0, view.first, heightOf)}px`;
      }
      if (tailRef.current) {
        tailRef.current.style.height = `${sumHeights(view.last + 1, pieces.length, heightOf)}px`;
      }

      const jumpId = jumpRef.current;
      if (jumpId) {
        const target = pieceElement(scroller, jumpId);
        if (target) {
          jumpRef.current = null;
          scroller.scrollTop = target.offsetTop;
          anchorRef.current = { id: jumpId, offset: 0 };
        }
      } else {
        const anchor = anchorRef.current;
        const element = anchor ? pieceElement(scroller, anchor.id) : null;
        if (anchor && element) scroller.scrollTop = element.offsetTop + anchor.offset;
      }

      paintProgress(scroller.scrollTop);
    },
    [heightOf, paintProgress, pieceElement, pieces.length],
  );

  // Spacers, anchor and progress, after every window change — and again
  // whenever a mounted piece changes size under the reader (an image decoding,
  // the reading face swapping), which moves everything below it.
  useLayoutEffect(() => {
    const scroller = scrollerRef.current;
    if (!scroller) return;

    if (!startedRef.current) {
      startedRef.current = true;
      const start = pieces[startIndex];
      if (start) jumpRef.current = start.id;
    }

    const settle = () => settleLayout(pieceWindow);
    settle();

    const observer = new ResizeObserver(settle);
    scroller.querySelectorAll<HTMLElement>('[data-piece-id]').forEach((element) => {
      observer.observe(element);
    });
    return () => observer.disconnect();
  }, [pieceWindow, pieces, settleLayout, startIndex]);

  // The reading position, recomputed once per animation frame while scrolling.
  useEffect(() => {
    const scroller = scrollerRef.current;
    if (!scroller) return;
    let frame = 0;

    const sync = () => {
      frame = 0;
      const position = paintProgress(scroller.scrollTop);
      setActiveIndex(position.index);
      setPieceWindow((current) => {
        const next = windowAround(position.index, pieces.length);
        return sameWindow(current, next) ? current : next;
      });
      const mounted = scroller.querySelectorAll<HTMLElement>('[data-piece-id]');
      for (let index = 0; index < mounted.length; index += 1) {
        const element = mounted[index];
        if (element.offsetTop + element.offsetHeight > scroller.scrollTop) {
          const id = element.dataset.pieceId;
          if (id) anchorRef.current = { id, offset: scroller.scrollTop - element.offsetTop };
          break;
        }
      }
    };

    const onScroll = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(sync);
    };

    scroller.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      scroller.removeEventListener('scroll', onScroll);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [paintProgress, pieces.length]);

  const jumpTo = useCallback(
    (index: number) => {
      if (pieces.length === 0) return;
      const clamped = Math.min(Math.max(index, 0), pieces.length - 1);
      const target = pieces[clamped];
      if (!target) return;

      jumpRef.current = target.id;
      setActiveIndex(clamped);
      setPieceWindow((current) => {
        const next = windowAround(clamped, pieces.length);
        return sameWindow(current, next) ? current : next;
      });

      // A jump inside the mounted window moves neither the window nor the
      // active index, so no render — and therefore no layout effect — follows.
      // Scroll to it here instead of waiting for one that never comes.
      const scroller = scrollerRef.current;
      const element = scroller ? pieceElement(scroller, target.id) : null;
      if (scroller && element) {
        jumpRef.current = null;
        scroller.scrollTop = element.offsetTop;
        anchorRef.current = { id: target.id, offset: 0 };
        paintProgress(scroller.scrollTop);
      }
    },
    [paintProgress, pieceElement, pieces],
  );

  // Keyboard: space and the arrows read, Esc leaves. Everything is prevented
  // rather than passed through — this is a page, not a form.
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.ctrlKey || event.metaKey || event.altKey) return;
      const scroller = scrollerRef.current;
      const step = (delta: number) => {
        if (scroller) scroller.scrollTop += delta;
      };
      const page = scroller ? Math.max(LINE_STEP_PX, scroller.clientHeight * PAGE_FRACTION) : 400;

      switch (event.key) {
        case 'Escape':
          event.preventDefault();
          onClose();
          return;
        case ' ':
        case 'PageDown':
          event.preventDefault();
          step(event.shiftKey ? -page : page);
          return;
        case 'PageUp':
          event.preventDefault();
          step(-page);
          return;
        case 'ArrowDown':
          event.preventDefault();
          step(LINE_STEP_PX);
          return;
        case 'ArrowUp':
          event.preventDefault();
          step(-LINE_STEP_PX);
          return;
        case 'ArrowRight':
          event.preventDefault();
          jumpTo(activeIndex + 1);
          return;
        case 'ArrowLeft':
          event.preventDefault();
          jumpTo(activeIndex - 1);
          return;
        case 'Home':
          event.preventDefault();
          jumpTo(0);
          return;
        case 'End':
          event.preventDefault();
          jumpTo(pieces.length - 1);
          return;
        default:
          return;
      }
    };

    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [activeIndex, jumpTo, onClose, pieces.length]);

  // Keep the rail showing the piece being read.
  useEffect(() => {
    if (!railOpen) return;
    const item = railRef.current?.querySelector<HTMLElement>(`[data-rail-index="${activeIndex}"]`);
    item?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex, railOpen]);

  // The page takes the keys as soon as it opens, without moving the scroll.
  useEffect(() => {
    scrollerRef.current?.focus({ preventScroll: true });
  }, []);

  /**
   * A link in the prose must not navigate the app out of itself. Desktop hands
   * `window.open` to the OS browser (`setWindowOpenHandler` in electron/main),
   * which is where a manuscript's links belong.
   */
  const handleProseClick = useCallback((event: React.MouseEvent<HTMLDivElement>) => {
    const anchor = (event.target as HTMLElement).closest('a');
    if (!anchor) return;
    event.preventDefault();
    const href = anchor.getAttribute('href') ?? '';
    if (/^https?:\/\//i.test(href)) window.open(href, '_blank', 'noopener,noreferrer');
  }, []);

  const activePiece = pieces[Math.min(activeIndex, pieces.length - 1)];
  const mounted = pieces.slice(pieceWindow.first, pieceWindow.last + 1);

  return (
    <div
      // The same three attributes the editor writes, resolved by index.css into
      // the custom properties the prose is set with. Reading mode and the
      // editor therefore cannot disagree about face, size or measure.
      data-reading-face={reading.face}
      data-reading-size={reading.size}
      data-reading-measure={reading.measure}
      role="dialog"
      aria-modal="true"
      aria-label={t('writings.reading.title')}
      className="fixed inset-0 z-40 flex flex-col bg-deep"
    >
      <header className="flex flex-shrink-0 items-center gap-3 border-b border-border px-4 py-2.5">
        <button
          type="button"
          onClick={onClose}
          className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-text-muted hover:text-text-primary transition rounded-lg hover:bg-elevated"
        >
          <X size={16} />
          {t('writings.reading.exit')}
        </button>

        <button
          type="button"
          onClick={() => setRailOpen((open) => !open)}
          title={railOpen ? t('writings.reading.hideRail') : t('writings.reading.showRail')}
          aria-pressed={railOpen}
          className={`p-1.5 rounded-lg transition border ${
            railOpen
              ? 'text-accent-gold border-accent-gold/40 bg-accent-gold/10'
              : 'text-text-muted border-border hover:text-text-primary hover:bg-elevated'
          }`}
        >
          <ListTree size={15} />
        </button>

        {/* The piece being read, always on screen while it is being read. */}
        <div className="min-w-0 flex-1 text-center">
          <p className="truncate font-serif text-sm font-bold text-text-primary">
            {activePiece?.title || t('writings.untitled')}
          </p>
          {activePiece?.chapter !== undefined && (
            <p className="text-[10px] uppercase tracking-widest text-text-dim">
              {t('writings.chapter')} {activePiece.chapter}
            </p>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => jumpTo(activeIndex - 1)}
            disabled={activeIndex <= 0}
            title={t('common.previous')}
            aria-label={t('common.previous')}
            className="p-1.5 rounded-lg transition border text-text-muted border-border hover:text-text-primary hover:bg-elevated disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-text-muted"
          >
            <ChevronLeft size={15} />
          </button>
          <button
            type="button"
            onClick={() => jumpTo(activeIndex + 1)}
            disabled={activeIndex >= pieces.length - 1}
            title={t('common.next')}
            aria-label={t('common.next')}
            className="p-1.5 rounded-lg transition border text-text-muted border-border hover:text-text-primary hover:bg-elevated disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-text-muted"
          >
            <ChevronRight size={15} />
          </button>
        </div>

        {/* Progress through the whole manuscript, counted in words rather than
            in viewport-fuls: a 400-word idea and a 4 000-word chapter do not
            move the bar by the same amount. */}
        <div className="flex flex-shrink-0 items-center gap-2" title={t('writings.reading.progressHint')}>
          <div className="h-1.5 w-28 overflow-hidden rounded-full bg-elevated">
            <div ref={barRef} className="h-full rounded-full bg-accent-gold" style={{ width: '0%' }} />
          </div>
          <span ref={percentRef} className="w-9 text-right text-[11px] tabular-nums text-text-muted">
            0%
          </span>
          <span className="text-[11px] text-text-dim">
            {t('writings.reading.pieceOf')
              .replace('{index}', (activeIndex + 1).toLocaleString(locale))
              .replace('{count}', pieces.length.toLocaleString(locale))}
          </span>
        </div>

        <span className="hidden text-[10px] text-text-dim xl:inline">{t('writings.reading.keys')}</span>
      </header>

      <div className="flex min-h-0 flex-1">
        {railOpen && (
          <nav
            ref={railRef}
            aria-label={t('writings.reading.rail')}
            className="w-60 flex-shrink-0 overflow-y-auto border-r border-border bg-surface/40 py-2"
          >
            {pieces.map((piece, index) => (
              <button
                key={piece.id}
                type="button"
                data-rail-index={index}
                onClick={() => jumpTo(index)}
                aria-current={index === activeIndex ? 'true' : undefined}
                className={`flex w-full items-center gap-2 px-3 py-2 text-left text-xs transition ${
                  index === activeIndex
                    ? 'bg-accent-gold/10 text-accent-gold font-semibold'
                    : 'text-text-muted hover:bg-elevated hover:text-text-primary'
                }`}
              >
                <span className="w-6 flex-shrink-0 text-right text-[10px] tabular-nums text-text-dim">
                  {piece.chapter ?? index + 1}
                </span>
                <span className="truncate">{piece.title || t('writings.untitled')}</span>
              </button>
            ))}
          </nav>
        )}

        {/* `relative`, so every `offsetTop` read below is measured against this
            scroller and the anchor arithmetic stays self-consistent. */}
        <div
          ref={scrollerRef}
          tabIndex={-1}
          onClick={handleProseClick}
          className="relative flex-1 overflow-y-auto outline-none"
        >
          <div ref={leadRef} aria-hidden="true" />
          {mounted.map((piece, offset) => (
            <ReadingPiece
              key={piece.id}
              piece={piece}
              words={words[pieceWindow.first + offset] ?? 0}
              onOpenInEditor={onOpenInEditor}
            />
          ))}
          <div ref={tailRef} aria-hidden="true" />
          <p className="px-6 py-10 text-center text-xs text-text-dim">{t('writings.reading.end')}</p>
        </div>
      </div>
    </div>
  );
}

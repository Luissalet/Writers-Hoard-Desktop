import {
  useEffect, useRef, useState,
  type KeyboardEvent as ReactKeyboardEvent, type MouseEvent as ReactMouseEvent, type PointerEvent as ReactPointerEvent,
} from 'react';
import { useTranslation } from '@/i18n/useTranslation';
import { toast } from '@/components/common/toast';
import { EngineSpinner } from '@/engines/_shared';
import type { AtlasDivergence, AtlasPlace } from '../types';
import { hasCoordinates, tileRange, worldSize, type LonLat, type Point } from '../geo';
import {
  fitBounds, fromScreen, panBy, toScreen, viewOrigin, WORLD_EXTENT, zoomAt, zoomBy, type MapView, type Size,
} from '../mapState';
import { basemapPaths, largestRing, loadBasemap, type Basemap } from '../basemap';
import { DEFAULT_ATLAS_MAP_PREFS, loadAtlasMapPrefs, saveAtlasMapPrefs, type AtlasMapPrefs } from '../mapPrefs';
import { MapToolbar, MeasurePanel, Pin, PlaceCard, UndoBar, type MeasurePoint } from './AtlasMapChrome';

// ============================================================================
// The atlas map
// ============================================================================
//
// No mapping library: a container with a ResizeObserver, a view (centre +
// fractional zoom) and four layers stacked in it —
//
//   1. OSM raster tiles, only when the writer switches "detailed map" on:
//      the one thing here that touches the network, so it is opt-in per
//      project and off by default;
//   2. the offline vector basemap (country outlines) as one SVG path per
//      country, recomputed on every pan and zoom — hidden under the tiles;
//   3. an SVG overlay for parent→child lines and the measuring line;
//   4. HTML pins, one per place with coordinates, draggable.
//
// Pointer handling is the usual pointer-capture dance: a press on the map
// pans, a press on a pin drags it, and a press that never moved more than
// three pixels is a click for whatever mode is active.

/** A request from the engine, applied once per `seq` (render-adjust, not an effect). */
export interface MapRequest {
  placeId: string;
  seq: number;
}

export interface AtlasMapProps {
  projectId: string;
  places: AtlasPlace[];
  divergences: AtlasDivergence[];
  selectedPlaceId: string | null;
  onSelect: (id: string | null) => void;
  /** "Edit" on the card: the engine switches to the list with the place open. */
  onEdit: (id: string) => void;
  /** A click in "add place" mode: the engine creates the row and opens its editor. */
  onCreateAt: (coords: LonLat) => void;
  /** New coordinates for a place (null clears them); a drag, "place on the map" and undo all go through here. */
  onMove: (id: string, coords: LonLat | null) => Promise<void>;
  /** The editor's "pick on the map": the next click is reported through onPick instead of being written. */
  pickRequest: MapRequest | null;
  onPick: (placeId: string, coords: LonLat) => void;
  /** Centre on a place and select it (a deep link while the map is the active tab). */
  focusRequest: MapRequest | null;
}

type Mode =
  | { kind: 'browse' }
  | { kind: 'add' }
  | { kind: 'place'; placeId: string; source: 'editor' | 'map' }
  | { kind: 'measure'; from?: MeasurePoint; to?: MeasurePoint };

interface PanDrag {
  pointerId: number;
  startX: number;
  startY: number;
  lastX: number;
  lastY: number;
  moved: boolean;
}

interface PinDrag {
  id: string;
  pointerId: number;
  startX: number;
  startY: number;
  moved: boolean;
  at: LonLat;
}

interface UndoState {
  placeId: string;
  name: string;
  /** What the place had before; null when it had no coordinates. */
  previous: LonLat | null;
  messageKey: 'realAtlas.map.moved' | 'realAtlas.map.placed';
}

/** Pixels a pointer may wander before a press stops being a click. */
const CLICK_SLOP = 3;
/** Wheel pixels per zoom level. */
const WHEEL_PIXELS_PER_LEVEL = 250;
/** Zoom from which pins carry their name. */
const LABEL_ZOOM = 5;
/** Zoom from which the vector base shows country names, subject to their size on screen. */
const COUNTRY_LABEL_ZOOM = 2.5;
const COUNTRY_LABEL_MIN_PX = 48;
/** How long the undo bar for a moved pin stays. */
const UNDO_MS = 15_000;
/** OSM has nothing past 19. */
const MAX_TILE_ZOOM = 19;
/** Pins are laid out this far outside the viewport so a drag near an edge does not pop. */
const PIN_MARGIN = 40;
/** Zoom used when centring on one place from a request or the search. */
const FOCUS_ZOOM = 8;
/** "Fit all" with one place must still show its country, not its street: the 110m basemap has nothing to draw at 12. */
const FIT_MAX_ZOOM = 7;

/** A layer fills the container; see the container's own comment on inline geometry. */
const LAYER = { position: 'absolute', inset: 0 } as const;

function focusView(view: MapView, place: LonLat): MapView {
  return { center: { lon: place.lon, lat: place.lat }, zoom: Math.max(view.zoom, FOCUS_ZOOM) };
}

export default function AtlasMap({
  projectId, places, divergences, selectedPlaceId, onSelect, onEdit, onCreateAt, onMove, pickRequest, onPick, focusRequest,
}: AtlasMapProps) {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const panRef = useRef<PanDrag | null>(null);

  const [prefs, setPrefs] = useState<AtlasMapPrefs | null>(null);
  const [view, setView] = useState<MapView | null>(null);
  const [size, setSize] = useState<Size>({ width: 0, height: 0 });
  const [basemap, setBasemap] = useState<Basemap | null>(null);
  const [mode, setMode] = useState<Mode>({ kind: 'browse' });
  const [cursor, setCursor] = useState<LonLat | null>(null);
  const [pinDrag, setPinDrag] = useState<PinDrag | null>(null);
  const [panning, setPanning] = useState(false);
  const [undo, setUndo] = useState<UndoState | null>(null);
  const [cardOpen, setCardOpen] = useState(false);
  const [focusPlaceId, setFocusPlaceId] = useState<string | null>(null);
  const [seenPick, setSeenPick] = useState(0);
  const [seenFocus, setSeenFocus] = useState(0);

  // --- loading: preferences, basemap, container size --------------------

  useEffect(() => {
    let cancelled = false;
    loadAtlasMapPrefs(projectId).then((loaded) => { if (!cancelled) setPrefs(loaded); });
    return () => { cancelled = true; };
  }, [projectId]);

  useEffect(() => {
    let cancelled = false;
    loadBasemap().then((loaded) => { if (!cancelled) setBasemap(loaded); }).catch((error: unknown) => {
      // The map still works — tiles, pins, measuring — just over a blank ocean.
      console.error('[real-atlas] basemap failed to load', error);
    });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (rect) setSize({ width: Math.round(rect.width), height: Math.round(rect.height) });
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // React registers wheel listeners as passive, so preventDefault there is a
  // no-op and the page would scroll under the map: a native listener it is.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const pixels = e.deltaMode === WheelEvent.DOM_DELTA_LINE ? e.deltaY * 16 : e.deltaY;
      setView((current) => current && zoomAt(
        current,
        { width: rect.width, height: rect.height },
        { x: e.clientX - rect.left, y: e.clientY - rect.top },
        -pixels / WHEEL_PIXELS_PER_LEVEL,
      ));
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  // Persist where the map is, debounced: a pan is a hundred moves.
  useEffect(() => {
    if (!prefs || !view) return;
    const timer = window.setTimeout(() => { void saveAtlasMapPrefs(projectId, { ...prefs, view }); }, 600);
    return () => window.clearTimeout(timer);
  }, [projectId, prefs, view]);

  useEffect(() => {
    if (!undo) return;
    const timer = window.setTimeout(() => setUndo(null), UNDO_MS);
    return () => window.clearTimeout(timer);
  }, [undo]);

  // --- derived --------------------------------------------------------------

  const located = places.filter(hasCoordinates);
  const unplaced = places.filter((p) => !hasCoordinates(p));
  const byId = new Map(places.map((p) => [p.id, p]));
  const divergenceCount = new Map<string, number>();
  for (const row of divergences) {
    if (row.placeId) divergenceCount.set(row.placeId, (divergenceCount.get(row.placeId) ?? 0) + 1);
  }
  const placeName = (id?: string) => (id ? byId.get(id)?.name : undefined);
  const ready = size.width > 0 && size.height > 0;

  // --- render-adjust: first view, and requests from the engine -------------

  // The route keeps this component mounted across a change of project, so
  // the other project's view must not be shown over this one's places.
  const [prefsFor, setPrefsFor] = useState(projectId);
  if (prefsFor !== projectId) {
    setPrefsFor(projectId);
    setPrefs(null);
    setView(null);
    setMode({ kind: 'browse' });
    setCardOpen(false);
  }
  if (!view && prefs && ready) {
    setView(prefs.view ?? fitBounds(located.length ? located : WORLD_EXTENT, size, 48, FIT_MAX_ZOOM));
  }
  if (pickRequest && pickRequest.seq !== seenPick) {
    setSeenPick(pickRequest.seq);
    setMode({ kind: 'place', placeId: pickRequest.placeId, source: 'editor' });
    setFocusPlaceId(pickRequest.placeId);
    setCardOpen(false);
  }
  if (focusRequest && focusRequest.seq !== seenFocus) {
    setSeenFocus(focusRequest.seq);
    setFocusPlaceId(focusRequest.placeId);
    setCardOpen(true);
  }
  if (view && focusPlaceId) {
    setFocusPlaceId(null);
    const target = byId.get(focusPlaceId);
    if (target && hasCoordinates(target)) setView(focusView(view, target));
  }

  const selectedPlace = selectedPlaceId ? byId.get(selectedPlaceId) ?? null : null;
  // A place that lost its coordinates (or was deleted) has no card to show.
  if (cardOpen && !(selectedPlace && hasCoordinates(selectedPlace))) setCardOpen(false);

  // --- helpers ----------------------------------------------------------------

  const containerPoint = (clientX: number, clientY: number): Point => {
    const rect = containerRef.current?.getBoundingClientRect();
    return rect ? { x: clientX - rect.left, y: clientY - rect.top } : { x: 0, y: 0 };
  };
  const lonLatAt = (clientX: number, clientY: number): LonLat | null =>
    view ? fromScreen(view, size, containerPoint(clientX, clientY)) : null;

  const exitMode = () => {
    setMode({ kind: 'browse' });
    setCursor(null);
  };

  const updatePrefs = (patch: Partial<AtlasMapPrefs>) =>
    setPrefs((current) => ({ ...(current ?? DEFAULT_ATLAS_MAP_PREFS), ...patch }));

  const moveWithUndo = async (place: AtlasPlace, coords: LonLat, messageKey: 'realAtlas.map.moved' | 'realAtlas.map.placed') => {
    const previous = hasCoordinates(place) ? { lon: place.lon, lat: place.lat } : null;
    await onMove(place.id, coords);
    setUndo({ placeId: place.id, name: place.name, previous, messageKey });
  };

  const undoMove = async () => {
    if (!undo) return;
    setUndo(null);
    await onMove(undo.placeId, undo.previous);
    toast.info(t('realAtlas.map.undone'));
  };

  /** A press that did not move: what it means depends on the mode. */
  const clickAt = (coords: LonLat, placeId?: string) => {
    switch (mode.kind) {
      case 'browse':
        onSelect(null);
        setCardOpen(false);
        return;
      case 'add':
        exitMode();
        onCreateAt(coords);
        return;
      case 'place': {
        const target = byId.get(mode.placeId);
        exitMode();
        if (!target) return;
        if (mode.source === 'editor') onPick(target.id, coords);
        else {
          onSelect(target.id);
          void moveWithUndo(target, coords, 'realAtlas.map.placed');
        }
        return;
      }
      case 'measure': {
        const point: MeasurePoint = placeId ? { ...coords, placeId } : coords;
        if (!mode.from || mode.to) setMode({ kind: 'measure', from: point });
        else setMode({ kind: 'measure', from: mode.from, to: point });
        setCursor(null);
        return;
      }
    }
  };

  // --- pointer: the map itself ---------------------------------------------------

  const onMapPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (e.button !== 0 || !view) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    panRef.current = { pointerId: e.pointerId, startX: e.clientX, startY: e.clientY, lastX: e.clientX, lastY: e.clientY, moved: false };
  };

  const onMapPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    const drag = panRef.current;
    if (drag && drag.pointerId === e.pointerId) {
      const dx = e.clientX - drag.lastX;
      const dy = e.clientY - drag.lastY;
      drag.lastX = e.clientX;
      drag.lastY = e.clientY;
      if (!drag.moved && Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) >= CLICK_SLOP) {
        drag.moved = true;
        setPanning(true);
      }
      if (drag.moved) setView((current) => current && panBy(current, dx, dy));
      return;
    }
    // Live end of the measuring line while the second point is being chosen.
    if (mode.kind === 'measure' && mode.from && !mode.to) setCursor(lonLatAt(e.clientX, e.clientY));
  };

  const onMapPointerUp = (e: ReactPointerEvent<HTMLDivElement>) => {
    const drag = panRef.current;
    if (!drag || drag.pointerId !== e.pointerId) return;
    panRef.current = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
    setPanning(false);
    if (drag.moved || e.type === 'pointercancel') return;
    const coords = lonLatAt(e.clientX, e.clientY);
    if (coords) clickAt(coords);
  };

  const onMapDoubleClick = (e: ReactMouseEvent<HTMLDivElement>) => {
    if (!view) return;
    setView(zoomAt(view, size, containerPoint(e.clientX, e.clientY), 1));
  };

  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    if (e.target instanceof HTMLInputElement) return;
    if (e.key === 'Escape') {
      exitMode();
      setCardOpen(false);
    } else if (e.key === '+' || e.key === '=') setView((v) => v && zoomBy(v, 1));
    else if (e.key === '-') setView((v) => v && zoomBy(v, -1));
    else if (e.key.startsWith('Arrow')) {
      const step = 80;
      const dx = e.key === 'ArrowLeft' ? step : e.key === 'ArrowRight' ? -step : 0;
      const dy = e.key === 'ArrowUp' ? step : e.key === 'ArrowDown' ? -step : 0;
      setView((v) => v && panBy(v, dx, dy));
    } else return;
    e.preventDefault();
  };

  // --- pointer: pins --------------------------------------------------------------

  const onPinPointerDown = (place: AtlasPlace & { lat: number; lon: number }) => (e: ReactPointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (e.button !== 0) return;
    // In measure mode a pin is a target, never a drag.
    if (mode.kind === 'measure') {
      clickAt({ lon: place.lon, lat: place.lat }, place.id);
      return;
    }
    e.currentTarget.setPointerCapture(e.pointerId);
    setPinDrag({ id: place.id, pointerId: e.pointerId, startX: e.clientX, startY: e.clientY, moved: false, at: { lon: place.lon, lat: place.lat } });
  };

  const onPinPointerMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (!pinDrag || pinDrag.pointerId !== e.pointerId) return;
    e.stopPropagation();
    const at = lonLatAt(e.clientX, e.clientY);
    if (!at) return;
    const moved = pinDrag.moved || Math.hypot(e.clientX - pinDrag.startX, e.clientY - pinDrag.startY) >= CLICK_SLOP;
    setPinDrag({ ...pinDrag, moved, at });
  };

  const onPinPointerUp = (place: AtlasPlace) => (e: ReactPointerEvent<HTMLButtonElement>) => {
    if (!pinDrag || pinDrag.pointerId !== e.pointerId) return;
    e.stopPropagation();
    if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
    const drag = pinDrag;
    setPinDrag(null);
    if (e.type === 'pointercancel') return;
    if (drag.moved) {
      void moveWithUndo(place, drag.at, 'realAtlas.map.moved');
      return;
    }
    onSelect(place.id);
    setCardOpen(true);
  };

  // --- toolbar actions ------------------------------------------------------------

  const choosePlace = (place: AtlasPlace) => {
    onSelect(place.id);
    if (hasCoordinates(place)) {
      setView((v) => v && focusView(v, place));
      setCardOpen(true);
    } else {
      setMode({ kind: 'place', placeId: place.id, source: 'map' });
    }
  };

  const toggleMode = (kind: 'add' | 'measure') => {
    if (mode.kind === kind) exitMode();
    else {
      setMode(kind === 'add' ? { kind } : { kind, from: undefined });
      setCardOpen(false);
    }
  };

  const measureFrom = (place: AtlasPlace & { lat: number; lon: number }) => {
    setMode({ kind: 'measure', from: { lon: place.lon, lat: place.lat, placeId: place.id } });
    setCardOpen(false);
  };

  // --- layout -----------------------------------------------------------------------

  const tiles = prefs?.tiles ?? false;
  const hierarchy = prefs?.hierarchy ?? false;
  const origin = view ? viewOrigin(view, size) : { x: 0, y: 0 };

  // Screen position of every located place (the one being dragged follows the
  // pointer); only those near the viewport become pins, but the lines need all
  // of them — a parent off the edge still anchors its children's lines.
  const onScreen = view
    ? located.map((place) => {
      const at = pinDrag?.id === place.id ? pinDrag.at : place;
      return { place, ...toScreen(view, size, at) };
    })
    : [];
  const screenOf = new Map(onScreen.map((p) => [p.place.id, { x: p.x, y: p.y }]));
  const positioned = onScreen.filter((p) =>
    p.x >= -PIN_MARGIN && p.x <= size.width + PIN_MARGIN && p.y >= -PIN_MARGIN && p.y <= size.height + PIN_MARGIN);

  const tileLayer = view && tiles ? tileElements(view, size, origin) : null;
  const paths = view && !tiles && basemap ? basemapPaths(basemap, view, size) : [];
  const countryLabels = view && !tiles && basemap && view.zoom >= COUNTRY_LABEL_ZOOM
    ? countryLabelElements(basemap, view, size)
    : null;

  const measure = mode.kind === 'measure' ? mode : null;
  const measureEnd = measure?.to ?? (measure?.from ? cursor : null);
  const measureLine = view && measure?.from && measureEnd
    ? { a: toScreen(view, size, measure.from), b: toScreen(view, size, measureEnd) }
    : null;

  const banner = mode.kind === 'add'
    ? t('realAtlas.map.banner.add')
    : mode.kind === 'place'
      ? t('realAtlas.map.banner.place').replace('{name}', placeName(mode.placeId) ?? '')
      : mode.kind === 'measure'
        ? (mode.from && !mode.to
            ? t('realAtlas.map.banner.measureTo')
            : mode.from && mode.to
              ? t('realAtlas.map.banner.measureAgain')
              : t('realAtlas.map.banner.measureFrom'))
        : null;

  const cursorClass = mode.kind === 'browse'
    ? (panning ? 'cursor-grabbing' : 'cursor-grab')
    : 'cursor-crosshair';
  // Pins are scenery while the writer is aiming at the map itself.
  const pinsInert = mode.kind === 'add' || mode.kind === 'place';
  const selectedId = selectedPlace?.id ?? null;
  const selectedScreen = selectedId ? screenOf.get(selectedId) : undefined;

  return (
    <div
      ref={containerRef}
      role="application"
      aria-label={t('realAtlas.tabs.map')}
      tabIndex={0}
      onPointerDown={onMapPointerDown}
      onPointerMove={onMapPointerMove}
      onPointerUp={onMapPointerUp}
      onPointerCancel={onMapPointerUp}
      onDoubleClick={onMapDoubleClick}
      onKeyDown={onKeyDown}
      // Geometry inline, look in classes: the layers must stack and the pins
      // must land on their coordinates with no stylesheet at all (the test
      // harness has none), so nothing that positions is left to Tailwind.
      style={{ position: 'relative', overflow: 'hidden', width: '100%', height: '100%' }}
      className={`touch-none select-none rounded-xl border border-border bg-deep outline-none focus-visible:ring-1 focus-visible:ring-accent-gold ${cursorClass}`}
    >
      {!view && ready && <EngineSpinner />}

      {/* 1. Raster tiles (opt-in). */}
      {tileLayer && <div style={LAYER} className="pointer-events-none">{tileLayer}</div>}

      {/* 2. Vector basemap. */}
      {view && !tiles && (
        <svg style={LAYER} className="pointer-events-none" width={size.width} height={size.height} aria-hidden="true">
          <g data-layer="basemap" fill="var(--color-elevated)" stroke="var(--color-border)" strokeWidth={1} strokeLinejoin="round" fillRule="evenodd">
            {paths.map((country) => <path key={country.name} d={country.d} />)}
          </g>
          {countryLabels}
        </svg>
      )}

      {/* 3. Lines: hierarchy and the measuring rule. */}
      {view && (
        <svg style={LAYER} className="pointer-events-none" width={size.width} height={size.height} aria-hidden="true">
          {hierarchy && positioned.map(({ place, x, y }) => {
            const parent = place.parentId ? screenOf.get(place.parentId) : undefined;
            return parent ? (
              <line key={place.id} x1={parent.x} y1={parent.y} x2={x} y2={y} stroke="var(--color-text-dim)" strokeWidth={1} strokeDasharray="4 3" opacity={0.8} />
            ) : null;
          })}
          {measureLine && (
            <g stroke="var(--color-accent-gold)" fill="var(--color-accent-gold)">
              <line x1={measureLine.a.x} y1={measureLine.a.y} x2={measureLine.b.x} y2={measureLine.b.y} strokeWidth={2} strokeDasharray="6 4" />
              <circle cx={measureLine.a.x} cy={measureLine.a.y} r={4} />
              <circle cx={measureLine.b.x} cy={measureLine.b.y} r={4} />
            </g>
          )}
        </svg>
      )}

      {/* 4. Pins. */}
      {view && positioned.map(({ place, x, y }) => (
        <Pin
          key={place.id}
          place={place}
          x={x}
          y={y}
          selected={place.id === selectedId}
          divergences={divergenceCount.get(place.id) ?? 0}
          showLabel={view.zoom >= LABEL_ZOOM || place.id === selectedId}
          inert={pinsInert}
          dragging={pinDrag?.id === place.id}
          onPointerDown={onPinPointerDown(place)}
          onPointerMove={onPinPointerMove}
          onPointerUp={onPinPointerUp(place)}
        />
      ))}

      {/* Chrome. The toolbar stops pointer events so a click on it never pans. */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-col gap-1.5 p-2">
        <div onPointerDown={(e) => e.stopPropagation()} onDoubleClick={(e) => e.stopPropagation()}>
          <MapToolbar
            places={places}
            unplaced={unplaced}
            tiles={tiles}
            hierarchy={hierarchy}
            adding={mode.kind === 'add'}
            measuring={mode.kind === 'measure'}
            onChoose={choosePlace}
            onFitAll={() => setView(fitBounds(located.length ? located : WORLD_EXTENT, size, 48, FIT_MAX_ZOOM))}
            onToggleTiles={() => updatePrefs({ tiles: !tiles })}
            onToggleHierarchy={() => updatePrefs({ hierarchy: !hierarchy })}
            onToggleAdd={() => toggleMode('add')}
            onToggleMeasure={() => toggleMode('measure')}
            onZoom={(delta) => setView((v) => v && zoomBy(v, delta))}
            onPlace={(place) => { setMode({ kind: 'place', placeId: place.id, source: 'map' }); setCardOpen(false); }}
          />
        </div>
        {banner && (
          <p className="pointer-events-none self-start rounded-md border border-accent-gold/40 bg-elevated/90 px-2.5 py-1 text-xs text-accent-gold shadow">
            {banner}
          </p>
        )}
        {view && located.length === 0 && mode.kind === 'browse' && (
          <p className="pointer-events-none self-start rounded-md bg-elevated/80 px-2.5 py-1 text-xs text-text-dim">{t('realAtlas.map.emptyHint')}</p>
        )}
      </div>

      {cardOpen && selectedPlace && hasCoordinates(selectedPlace) && selectedScreen && (
        <PlaceCard
          place={selectedPlace}
          divergences={divergenceCount.get(selectedPlace.id) ?? 0}
          x={selectedScreen.x}
          y={selectedScreen.y}
          width={size.width}
          height={size.height}
          onEdit={() => onEdit(selectedPlace.id)}
          onMeasureFrom={() => measureFrom(selectedPlace)}
          onClose={() => setCardOpen(false)}
        />
      )}

      {measure?.from && measure.to && (
        <MeasurePanel from={measure.from} to={measure.to} placeName={placeName} onClose={exitMode} />
      )}

      {undo && (
        <UndoBar
          message={t(undo.messageKey).replace('{name}', undo.name)}
          onUndo={() => void undoMove()}
          onDismiss={() => setUndo(null)}
        />
      )}

      {tiles && (
        <p className="pointer-events-none absolute bottom-1 right-2 z-10 rounded bg-deep/70 px-1.5 text-[10px] text-text-muted">
          © OpenStreetMap contributors
        </p>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Layers
// ---------------------------------------------------------------------------

/**
 * The OSM tiles covering the view. Tiles exist at integer zooms; the nearest
 * one is scaled by 2^(zoom − z) so a fractional zoom still lines up with the
 * vector layers above it. Keys are z/x/y so a pan re-positions the same
 * <img> elements rather than re-requesting them.
 */
function tileElements(view: MapView, size: Size, origin: Point) {
  const z = Math.max(0, Math.min(MAX_TILE_ZOOM, Math.round(view.zoom)));
  const scale = worldSize(view.zoom) / worldSize(z);
  const tilePx = 256 * scale;
  const range = tileRange(
    { x0: origin.x / scale, y0: origin.y / scale, x1: (origin.x + size.width) / scale, y1: (origin.y + size.height) / scale },
    z,
  );
  const elements = [];
  for (let ty = range.yMin; ty <= range.yMax; ty += 1) {
    for (let tx = range.xMin; tx <= range.xMax; tx += 1) {
      elements.push(
        <img
          key={`${z}/${tx}/${ty}`}
          src={`https://tile.openstreetmap.org/${z}/${tx}/${ty}.png`}
          alt=""
          loading="lazy"
          draggable={false}
          style={{ left: tx * tilePx - origin.x, top: ty * tilePx - origin.y, width: tilePx, height: tilePx }}
          className="absolute max-w-none"
        />,
      );
    }
  }
  return elements;
}

/** Country names over the vector base, only for countries big enough on screen to carry one. */
function countryLabelElements(basemap: Basemap, view: MapView, size: Size) {
  const pxPerDegree = worldSize(view.zoom) / 360;
  const labels = [];
  for (const country of basemap.countries) {
    const ring = largestRing(country);
    if (!ring) continue;
    const widthPx = (ring.maxLon - ring.minLon) * pxPerDegree;
    if (widthPx < COUNTRY_LABEL_MIN_PX) continue;
    const p = toScreen(view, size, { lon: (ring.minLon + ring.maxLon) / 2, lat: (ring.minLat + ring.maxLat) / 2 });
    if (p.x < 0 || p.x > size.width || p.y < 0 || p.y > size.height) continue;
    labels.push(
      <text key={country.name} x={p.x} y={p.y} textAnchor="middle" fontSize={10} fill="var(--color-text-dim)" style={{ letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        {country.name}
      </text>,
    );
  }
  return labels;
}

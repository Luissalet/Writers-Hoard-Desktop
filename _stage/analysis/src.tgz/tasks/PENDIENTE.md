# World Generator — lo que queda

Consolidado a 2026-08-11 (séptima pasada), deduplicado contra las anteriores.
Lo que ya se hizo no aparece; `tasks/todo-2d-cohesion.md` conserva el histórico
completo, incluida la lista de lo que ESTA pasada cerró.

Todo lo de aquí está **medido o confirmado**, con el número o la línea que lo
demuestra. Nada es una sospecha.

---

## 1 · Defectos confirmados, sin arreglar

### 1.1 (RESUELTO EN ESTA MISMA PASADA — se deja el rastro)
El remontaje de la carta y el primer montaje de map2d morían al final de la
tanda entera del banco: era presión de memoria del proceso GPU acumulada por
los contextos WebGL del 3D, que `dispose()` no libera. Con
`renderer.forceContextLoss()` al desmontar `World3D` (y el reintento armado de
la guarda de contexto nulo en Map2D), la corrida completa dio **17/17 EN
VERDE** — la primera de la historia del banco (la línea base de esta sesión
fue 15/17).

### 1.1b El último caso de la tanda entera del banco es INTERMITENTE
Tras el `forceContextLoss` la corrida completa dio 17/17 una vez; en la
siguiente, `worldview-carta` (el caso 17 de 17, tras ~25 min de SwiftShader)
volvió a morir sin raíz — y EN SOLITARIO pasa SIEMPRE (tres corridas
comprobadas). Sin quejas de página. Es presión del proceso GPU del contenedor
del banco, no de la aplicación; en una máquina real no hay 17 montajes WebGL
seguidos del mismo proceso. Se vigila, no se persigue.

### 1.2 (RESUELTO EN LA RONDA 4 — se deja el rastro)
La escalera de calidad tardaba 24 fotogramas en actuar (12 minutos a 30
s/fotograma). Ahora tiene vía rápida: con `frameGapAvg > 2000` bastan 3
muestras — y como el intervalo real sólo se muestrea entre dibujos
ENCADENADOS, tres muestras lentas no pueden ser una pausa del usuario.
Verificada de rebote por el propio banco: el globo bajo SwiftShader llega a
la captura ya rebajado a 0,85. (Eso destapó que el control «búfer = css×dpr»
del banco era incompatible con la escalera automática DESDE SIEMPRE — sólo
que las 24 muestras nunca se juntaban dentro del banco; ahora comprueba
escala uniforme y cuerda en vez de ratio 1 exacto.)

---

## 2 · El 3D: maquinaria escrita y APAGADA (sigue) — Y AHORA CON REGLA NUEVA

**Decisión de Luis (2026-08-11, ronda 3): el zoom de cerca es LISO.** «Puedes
hacer zoom sin necesidad de hacer esa teselación exagerada — el terreno es
bastante llano»; los «picos y poros» del intento del parche de 150 m quedan
descartados como dirección. En consecuencia:
- `MIN_3D_SPAN_KM` 150 → **25** (la rueda baja seis veces más cerca; la regla
  antigua «el suelo sólo baja cuando el relieve tenga algo debajo» queda
  revocada — el suelo de cerca es la interpolación lisa del campo del mundo).
- `ADOPT_MIN_SPAN_KM` 1200 → **150** (venir del 2D abre en tu comarca).
- «Detalle de cerca» (`uDetail`, el ruido fbm por píxel) por defecto **0** —
  era exactamente los poros; queda como mando opcional.
- El near de la cámara escala con la distancia (tope 25 % de la distancia):
  el 0,05 fijo recortaba el terreno a encuadres de 25 km.
- La nitidez de cerca la trae la PIEL, no la malla: a 25 km el plan pide
  z13-z14 y, con el canon caliente del 2D, eso son 10-19 m/px con mancha
  urbana y tejados — ciudades VISIBLES en el suelo del 3D sin relieve
  inventado. El parche de 150 m deja de ser prerequisito del zoom; si algún
  día se enciende, será para RELIEVE de cerca opcional, no para poder acercarse.

La decisión 5.2 está tomada (Luis, 2026-08-11: **el 3D consume, no genera**) y
el techo de teselas ya está subido con el contrato `consumeOnly` medido
(declinar = 0,3 ms; generar habría sido 31,9 s). Lo que sigue apagado:

- `setSubCellRelief` — relieve inventado por debajo de la celda. `uAmpDetail`
  nace en 0 y ahí se queda.
- `setDetailPatch` / `setDetailAlbedo` — el parche canónico de 150 m. Se llaman
  **una vez, con `null`**, y nunca más.
- `setAlbedoWindow` — sin llamante en el repositorio.
- `KIND_WIND` — el balanceo de la vegetación decidido y sin cablear (pide un
  atributo más por instancia).
- Sin nubes, sin sombras proyectadas por las plantas, sin estaciones.

Entre las tres primeras, ~un tercio de los dos shaders del terreno está
compilado e inalcanzable. Encenderlas es un proyecto CON PASADA VISUAL PROPIA
(bancos que miren PNGs), no un cableado a ciegas: el intento barato ya se
rechazó una vez («piel de naranja», ver worldgen-3d-cerca).

---

## 2b · El «detalle regional»: 49 s por supertesela, MEDIDO por fases

La queja de Luis («80 años cargando y luego borroso») es coste real de
generación canónica, en serie por diseño (el pool espera al worker que ya
tiene el mundo para no duplicar canon). Una supertesela de 2176² a ~305
m/celda, en el contenedor:

    cauces 12,6 s · agua 7,9 s · cercas 7,1 s · poblamiento 7,1 s ·
    vegetación 6,1 s · hitos 3,7 s · listo 2,5 s · caminos 1,4 s = 49 s

Y lo «borroso» a z9–z10 es el ráster amplificado de RESERVA mientras el canon
no llega (a esos niveles el canon da 0,5–1 px por celda: nítido relativo, no
absoluto). El ataque, para una tanda propia:
1. **Persistir el canon** (Dexie/OPFS): pagarlo UNA vez por mundo, no una por
   sesión. La palanca más grande y sin riesgo algorítmico.
2. Perfilar los bucles de `cauces` y `agua` (20,5 s entre los dos).
3. Quizá canon a medio refinamiento primero, refinar en sitio.

## 3 · Deuda funcional que esta pasada NO tocó

- **Los caminos no siguen a un pueblo movido hasta el pase completo** — y el
  pase completo vía caché (`getGeography`) construye la base SIN correcciones,
  así que la carretera apunta al solar antiguo hasta regenerar. Decisión
  documentada en `patchGeography` («ROADS are left exactly as they were»);
  si molesta, el sitio es `buildHumanGeography`: aplicar `moves` al listado
  ANTES de `buildRoads` cuando `corrections=true`, y decidir qué hace la caché.
- **El agua del plano y la del ráster satélite siguen sin ser la misma línea**
  (~100 m medidos en `sat-compare` a z17). Paliado: `townPlan` ya recibe la
  geografía y `cityParamsFor` entrega el litoral real como semejanza; el plano
  manda casas, el terreno manda agua (decisión en `townPlan.ts`). Cerrar el
  hueco del todo pediría que el plano consumiera la isolínea del canon.
- **Localizador y tecla Inicio** (todo-2d-cohesion): sin hacer.
- **Las comarcas guardadas sin dibujar** en el mapa (sólo marco).
- **El anillo del pincel miente media celda** (todo-2d-cohesion, fila vieja).

---

## 4 · Sin explorar

- La **hoja de comarca** (`RegionSheetView`) — sólo la hemos visto arrancar.
- El **atlas y el gazetteer** — nombres, etimologías, la lengua del mundo.
- El **planificador de viajes** — rutas, estaciones, modos de transporte.
- Los **enlaces al manuscrito** — el mapa de calor de dónde ocurre el libro.
- La vista **paleo** — el mundo en otras eras.
- El resto de la aplicación: 21 motores y sólo hemos tocado uno.

---

## 5 · Salud del proceso

- **El banco de arranque** (`harness/views-smoke-run.mjs`) cubre 17 vistas con
  doble montaje. Correrlo antes de dar nada por bueno.
- `harness/city-quality.ts`: **32/32 EN VERDE** desde esta pasada — es la
  primera vez. Si un cambio de ciudad lo pone rojo, el cambio se explica o se
  revierte.
- Bancos nuevos de esta pasada: `harness/road-affine-bench.ts` (tinta idéntica
  byte a byte entre vías + geometría medida), `harness/consume-only-probe.ts`
  (el contrato consume del 3D, con números), `harness/gate-blind-probe.ts` y
  `harness/gate-pinch-probe.ts` (sondas de dominio de la ciudad; censo de
  bolsas incluido).
- `SculptView` sigue sin cubrir: es el repuesto de `World3D` cuando el
  renderizador revienta, y llegar ahí exige un navegador sin WebGL.

---

## 6 · Cerrado en esta pasada (2026-08-11), para el histórico

**Ronda 4 («coloca las ciudades y mejora todo»):** ciudades y caminos EN FRÍO
en el suelo del 3D — a 25 km una casa mide <1 px, así que la ciudad es su
MANCHA por textura: `cartography/townStains.ts` (módulo puro: halo de labranza
+ lóbulos α0,34 + corazón α0,42 + motas de manzana desde 12 px; radios por
rango capital 820 m / city 680 / town 480 / village 260; hash estable por
celda; envuelve la costura) y la capa de caminos de siempre (`roadOverlay`,
vía afín) cableadas en `composeZoomSkin` ENCIMA de las teselas (el respaldo
somero z8 tapa el relleno al llegar; debajo se las llevaría) — la mancha se
retira sólo cuando TODAS las teselas del plan son exactas y ≤160 m/px (la
puerta de `drawBuildings`), y los caminos se funden con `roadOverlayAlpha`
sólo con el plan entero (bajo consumo, un canon frío declina las hondas y sin
la condición el fundido borraría los caminos justo cuando nadie más los trae).
La mancha de las teselas (`satelliteInk`) sube al MISMO α0,34/0,42 para que el
relevo relleno→tesela sea un cambio de pincel, no un atenuado. Verificado
MIRANDO PNGs (`harness/fill-probe.ts`: tres distancias + costura byte a byte;
`stain-probe` re-mirado con el α nuevo) · escalera de calidad con vía rápida
(§1.2, arriba) · control de búfer del banco corregido a escala uniforme.

**Ronda 2 (mismo día, tras las capturas de Luis):** ríos del 3D en un solo
idioma (albedo satélite sin tampón por celda + `drawWorldRivers` a anchura de
suelo en la textura Y en el relleno del bloque — la cinta gorda era el río
cocido a resolución de mundo ampliado ×8) · suelo de nitidez z8 garantizado
bajo consumo (el respaldo somero se pide SIEMPRE; `lastAsk` del store por
nivel) · escalera de importancia de los sitios del canon (punto un escalón
antes que el nombre; suelo por nivel 0,32/0,19/0,13/0,09/0 — se acabaron los
mil rótulos a zoom comarcal) · la ciudad recupera el cuerpo en z9–z14: punto
del mundo hasta z11 (rótulo cedido al canon desde z9 para no duplicar) y
MANCHA URBANA en las teselas (lóbulos + corazón, hash estable, se retira
cuando el tejado mide 1,4 px; `drawBuildings` pasa de abrirse a 2,2 m/px a
160 m/px) — verificada MIRANDO un mosaico 2×2 a z10/z12/z13.

**Ronda 1:**

1.1 reloj del 3D (intervalo real entre fotogramas: HUD honesto, vigilante con
plazo adaptativo y canario que resucita el reloj, escalera y amortiguado
alimentados del número verdadero) · 1.2 guardas de contexto nulo en Map2D ·
1.3 encaje del globo por geometría de casquete (adopción = posado por defecto
en β=90°) · 1.4 profundidad en `HumanGeography` y barra de estado sin ceros
falsos · 1.5 singular de camino · `moves` honrado por `patchGeography` y
`buildHumanGeography` (pueblos, ruinas, accidentes; exentos de ahogarse) ·
rótulos pintados con identidad (`label:x,y`) y arrastrables, mudanza dibujada
en 2D y carta · borrar/renombrar/mover pueblos pintados surte efecto en la vía
barata · `pickGeneratedAt` con puntería (extent ya no es radio; eraseMarkers
alcanzable) · `eraseRivers` con alcance de puntería (~235 km → ~puntería+ancho/2)
· `cityParamsFor` con geografía en las teselas (un solo plano por pueblo) ·
vía afín + caché de desenrollado en la capa de caminos (geometría 1,53→1,17
ms/copia; tinta idéntica) · ciudad 32/32: puertas con margen de agua y de río,
sin puertas sobre esquina cóncava (suelo urbano detrás), sin castillo sobre la
puerta de la villa, patio de armas con puerta al mercado, toda parcela en la
red de calles, poda de cuñas aisladas por el mar, calles proyectadas a tierra,
muelles con medidas de muelle · fachada 90,4 % → 92,4 % (VERDE) · cohesión 5.1
(decidida por Luis): el plano de ciudad con tema es un grabado de la MISMA
plancha que la carta (tejados, fábrica, sombras y lavados por el tema; la
canónica a color queda para el satélite) · 5.2 (decidida por Luis): techo de
piel de cerca subido con `consumeOnly` de punta a punta (protocolo, worker,
cliente, tienda del 3D) · i18n: cero tablas `_ES` en el motor (travel, atlas,
ruins por claves; el gazetteer conserva su prosa castellana POR DISEÑO junto a
sus tablas propias), catálogo de biomas completo (44/44, tabla única en
`core/biomeKeys.ts`), `describeDuration` por claves con frase entera —
catálogo 1.735 → 1.821 claves, es/en sin divergencia.

import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

/**
 * Reads a one-shot deep-link query parameter, then strips it from the URL.
 *
 * Anchor adapters have always composed URLs like
 * `/project/:id/codex?entry=<id>` — global search, Cmd+K results and
 * annotation backlinks all navigate through them. Nothing on the receiving end
 * ever read those parameters, so following a search hit or a backlink opened
 * the right engine tab and then just sat there on the dashboard, leaving the
 * author to find the record by hand. This hook is the missing half.
 *
 * Two details matter:
 *
 *  • **It reads the hash too.** The app can run under a hash route, where the
 *    query string lives after the `#` and `location.search` is empty.
 *
 *  • **It consumes the parameter.** Once delivered, the param is removed with a
 *    `replace` navigation, so the URL stays clean, a refresh doesn't re-jump,
 *    and — because the consumed marker resets as soon as the param is gone —
 *    navigating to the *same* entity a second time fires again.
 *
 * @param name query parameter to watch, e.g. `'entry'`, `'writing'`, `'pin'`.
 * @returns the most recent value seen, or `null` if there has never been one.
 */
export function useDeepLinkParam(name: string): string | null {
  const location = useLocation();
  const navigate = useNavigate();
  const [value, setValue] = useState<string | null>(null);
  const consumed = useRef<string | null>(null);

  useEffect(() => {
    const search =
      location.search ||
      (location.hash.includes('?') ? `?${location.hash.split('?').slice(1).join('?')}` : '');
    const params = new URLSearchParams(search);
    const raw = params.get(name);

    if (!raw) {
      // Nothing pending — re-arm so the same target can be linked to again.
      consumed.current = null;
      return;
    }

    const token = `${location.pathname}?${name}=${raw}`;
    if (consumed.current === token) return;
    consumed.current = token;

    setValue(raw);

    params.delete(name);
    const rest = params.toString();
    navigate(
      { pathname: location.pathname, search: rest ? `?${rest}` : '' },
      { replace: true },
    );
  }, [location.pathname, location.search, location.hash, name, navigate]);

  return value;
}

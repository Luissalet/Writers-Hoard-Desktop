import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Feather, Upload, Download, Database, Clock, ShieldAlert } from 'lucide-react';
import { useProjects } from '@/hooks/useProjects';
import ProjectCard from '@/components/bubbles/ProjectCard';
import EmptyState from '@/components/common/EmptyState';
import { StoragePersistenceWarning } from '@/components/common/StorageStatus';
import TopBar from '@/components/layout/TopBar';
import CreateProjectModal from '@/components/dashboard/CreateProjectModal';
import ImportCollisionDialog from '@/components/dashboard/ImportCollisionDialog';
import { importProjectData, importFullDatabase } from '@/db/operations';
import {
  describeBackupError,
  exportFullZip,
  importFullZip,
  importProjectZip,
  previewProjectZipImport,
  type ProjectZipImportPreview,
} from '@/services/zipBackup';
import { cleanupProjectMedia } from '@/services/scrapperMedia';
import {
  recordBackupCompleted,
  subscribeBackupReminder,
  type BackupReminder,
} from '@/services/autoBackup';
import {
  forgetProjectRoute,
  loadAllProjectProgress,
  localDaysSince,
  readProjectRoute,
  rememberProjectRoute,
  type ProjectProgress,
  type ProjectResume,
} from '@/services/projectIntelligence';
import { toast } from '@/components/common/toast';
import { useTranslation } from '@/i18n/useTranslation';
import { ConfirmDialog } from '@/engines/_shared';
import { getAnchorAdapter } from '@/engines/_shared/anchoring';
import type { Project } from '@/types';

/** The chapter a card's "Continue" would open, and what to call the button. */
interface ResumeTarget {
  writingId: string;
  title: string;
}

export default function Dashboard() {
  const { t } = useTranslation();
  const { projects, loading, addProject, editProject, removeProject, refresh } = useProjects();
  const navigate = useNavigate();
  const [showCreate, setShowCreate] = useState(false);
  const [importing, setImporting] = useState(false);
  const importRef = useRef<HTMLInputElement>(null);
  const fullImportRef = useRef<HTMLInputElement>(null);
  const [exporting, setExporting] = useState(false);
  // Stash the picked file until the user explicitly confirms the destructive
  // full-database restore. We deliberately do NOT use native `window.confirm()`
  // here — it can auto-resolve to `true` after tab suspend/resume on some
  // browser/OS combos, which has caused real data loss. See tasks/lessons.md.
  const [pendingFullImportFile, setPendingFullImportFile] = useState<File | null>(null);
  // Same React-owned confirmation for project deletion — a single hover-click
  // must never wipe a whole project.
  const [pendingDeleteProject, setPendingDeleteProject] = useState<Project | null>(null);
  const [pendingProjectImport, setPendingProjectImport] = useState<{
    file: File;
    preview: ProjectZipImportPreview;
  } | null>(null);
  // How old the last full backup is. Nothing in the app writes archives on its
  // own (see src/services/autoBackup.ts for why), so this line is the reminder
  // that replaces the automatic one — and the one click that acts on it.
  const [backup, setBackup] = useState<BackupReminder | null>(null);

  useEffect(() => subscribeBackupReminder(setBackup), []);

  // Word totals, last-edited stamps and whatever each project was last left on.
  // ONE query for the whole grid — reading it per card meant twenty round trips
  // to draw twenty numbers — refreshed whenever the project list itself is.
  const [progress, setProgress] = useState<Map<string, ProjectProgress>>(() => new Map());
  const [resumeRoutes, setResumeRoutes] = useState<Map<string, ProjectResume>>(() => new Map());

  useEffect(() => {
    let cancelled = false;
    const remembered = new Map<string, ProjectResume>();
    for (const project of projects) {
      const route = readProjectRoute(project.id);
      if (route) remembered.set(project.id, route);
    }
    setResumeRoutes(remembered);
    loadAllProjectProgress()
      .then((rows) => {
        if (!cancelled) setProgress(rows);
      })
      .catch((err) => console.error('[dashboard] project progress failed', err));
    return () => {
      cancelled = true;
    };
  }, [projects]);

  /**
   * The chapter "Continue" opens for a project.
   *
   * The remembered chapter wins — it is where the writer actually was — but
   * only while it still exists: one deleted since has no title to show and
   * falls through to the most recently edited chapter, which is also the best
   * answer available before anything has been remembered at all. Titles come
   * from the row and never from the stored route, so renaming a chapter renames
   * the button with it.
   */
  const resumeTargetFor = (project: Project): ResumeTarget | null => {
    const stats = progress.get(project.id);
    const remembered = resumeRoutes.get(project.id);
    const rememberedId = remembered?.engineId === 'writings' ? remembered.entityId : undefined;
    const rememberedTitle = rememberedId ? stats?.writingTitles.get(rememberedId) : undefined;
    if (rememberedId && rememberedTitle) {
      return { writingId: rememberedId, title: rememberedTitle };
    }
    const newestId = stats?.lastWritingId ?? undefined;
    const newestTitle = newestId ? stats?.writingTitles.get(newestId) : undefined;
    if (newestId && newestTitle) return { writingId: newestId, title: newestTitle };
    return null;
  };

  const openResume = (project: Project, target: ResumeTarget) => {
    rememberProjectRoute(project.id, { engineId: 'writings', entityId: target.writingId });
    // The same jump global search and annotation backlinks make.
    const adapter = getAnchorAdapter('writings');
    if (adapter) adapter.navigateToEntity(target.writingId, project.id);
    else {
      navigate(
        `/project/${encodeURIComponent(project.id)}/writings?writing=${encodeURIComponent(target.writingId)}`,
      );
    }
  };

  const backupAgeLabel = (state: BackupReminder): string => {
    if (state.unavailable) return t('dashboard.backupAge.unavailable');
    if (state.lastBackupAt === null) return t('dashboard.backupAge.never');
    if (state.daysSince === 0) return t('dashboard.backupAge.today');
    if (state.daysSince === 1) return t('dashboard.backupAge.yesterday');
    return t('dashboard.backupAge.days').replace('{days}', String(state.daysSince));
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      if (file.name.endsWith('.zip')) {
        // New format: single-project ZIP (merge/restore — no DB wipe)
        const preview = await previewProjectZipImport(file);
        if (preview.collisions.length > 0) {
          setPendingProjectImport({ file, preview });
          return;
        }
        const ids = await importProjectZip(file);
        await refresh();
        toast.success(t('dashboard.import.success'));
        if (ids.length === 1) navigate(`/project/${ids[0]}`);
      } else {
        // Legacy format: 13-table project JSON
        const text = await file.text();
        const data = JSON.parse(text);
        const newId = await importProjectData(data);
        await refresh();
        toast.success(t('dashboard.import.success'));
        navigate(`/project/${newId}`);
      }
    } catch (err) {
      console.error('Import failed:', err);
      toast.error(describeBackupError(err, t('dashboard.import.error')), 10000);
    } finally {
      setImporting(false);
      if (importRef.current) importRef.current.value = '';
    }
  };

  const cancelProjectImport = () => {
    if (importing) return;
    setPendingProjectImport(null);
  };

  const runProjectImportReplace = async () => {
    const pending = pendingProjectImport;
    if (!pending) return;
    setImporting(true);
    try {
      const ids = await importProjectZip(pending.file, {
        replaceProjectIds: pending.preview.collisions.map(
          (collision) => collision.projectId,
        ),
      });
      await refresh();
      setPendingProjectImport(null);
      toast.success(t('dashboard.import.success'));
      if (ids.length === 1) navigate(`/project/${ids[0]}`);
    } catch (err) {
      console.error('Project replacement import failed:', err);
      toast.error(describeBackupError(err, t('dashboard.import.error')), 10000);
    } finally {
      setImporting(false);
    }
  };

  const handleFullExport = async () => {
    setExporting(true);
    try {
      await exportFullZip();
      // Stamped only here, after the archive really exists — the reminder is
      // worthless if it can say "backed up" about a backup that failed.
      await recordBackupCompleted();
      toast.success(t('dashboard.fullExport.success'));
    } catch (err) {
      console.error('Full export failed:', err);
      toast.error(describeBackupError(err, t('dashboard.export.error')), 10000);
    } finally {
      setExporting(false);
    }
  };

  const handleFullImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Stash the file and open the React-owned confirmation dialog. The actual
    // restore runs in `runFullImport` only after the user clicks the confirm
    // button explicitly.
    setPendingFullImportFile(file);
  };

  const cancelFullImport = () => {
    setPendingFullImportFile(null);
    if (fullImportRef.current) fullImportRef.current.value = '';
  };

  const runFullImport = async () => {
    const file = pendingFullImportFile;
    setPendingFullImportFile(null);
    if (!file) {
      if (fullImportRef.current) fullImportRef.current.value = '';
      return;
    }
    setImporting(true);
    try {
      if (file.name.endsWith('.zip')) {
        // Structured ZIP backup
        await importFullZip(file);
        await refresh();
        window.location.reload();
      } else if (file.name.endsWith('.json')) {
        // Legacy JSON backup
        const text = await file.text();
        const data = JSON.parse(text);
        if (data.fullExport) {
          await importFullDatabase(data);
          await refresh();
          window.location.reload();
        } else {
          const newId = await importProjectData(data);
          await refresh();
          navigate(`/project/${newId}`);
        }
      } else {
        toast.error(t('dashboard.unsupportedFormat'));
      }
    } catch (err) {
      console.error('Full import failed:', err);
      toast.error(describeBackupError(err, t('dashboard.import.fullError')), 10000);
    } finally {
      setImporting(false);
      if (fullImportRef.current) fullImportRef.current.value = '';
    }
  };

  const runDeleteProject = async () => {
    const project = pendingDeleteProject;
    setPendingDeleteProject(null);
    if (!project) return;
    try {
      // Best-effort: wipe the project's downloaded media library (desktop).
      await cleanupProjectMedia(project.id);
      await removeProject(project.id);
      forgetProjectRoute(project.id);
      toast.success(t('dashboard.deleteProject.done').replace('{name}', project.title));
    } catch (err) {
      console.error('Project delete failed:', err);
      toast.error(t('dashboard.deleteProject.error'));
    }
  };

  const handleCreate = async (project: Project) => {
    await addProject(project);
    // Essentials mode goes straight into the writings engine — the whole
    // point of the preset is "start writing immediately, no extra clicks".
    // Other modes land on the project detail page so users can browse tabs.
    if (project.mode === 'essentials') {
      navigate(`/project/${project.id}/writings`);
    } else {
      navigate(`/project/${project.id}`);
    }
  };

  return (
    <>
      <TopBar title={t('dashboard.title')} subtitle={t('dashboard.subtitle')} />
      <div className="flex-1 overflow-y-auto p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-serif font-bold text-accent-gold">{t('dashboard.projects')}</h1>
            <p className="text-text-muted mt-1">
              {projects.length} {projects.length === 1 ? t('dashboard.worldCount.singular') : t('dashboard.worldCount.plural')}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <input ref={importRef} type="file" accept=".json,.zip" className="hidden" onChange={handleImport} />
            <input ref={fullImportRef} type="file" accept=".zip,.json" className="hidden" onChange={handleFullImport} />

            {/* How long since the last full backup — amber once it is due. */}
            {backup && projects.length > 0 && (
              <button
                type="button"
                onClick={handleFullExport}
                disabled={exporting}
                className={`flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs transition ${
                  backup.overdue
                    ? 'text-warning hover:bg-warning/10'
                    : 'text-text-dim hover:bg-elevated hover:text-text-primary'
                }`}
                title={t('dashboard.backupAge.action')}
              >
                {backup.overdue ? <ShieldAlert size={13} /> : <Clock size={13} />}
                {backupAgeLabel(backup)}
              </button>
            )}

            {/* Full backup controls */}
            <button
              onClick={handleFullExport}
              disabled={exporting}
              className="flex items-center gap-2 px-3 py-2.5 border border-accent-plum/30 text-accent-plum-light rounded-xl hover:bg-accent-plum/10 transition text-sm"
              title={t('dashboard.fullExport.title')}
            >
              <Database size={14} />
              <Download size={14} />
              {exporting ? t('dashboard.fullExport.exporting') : t('dashboard.fullExport.button')}
            </button>
            <button
              onClick={() => fullImportRef.current?.click()}
              disabled={importing}
              className="flex items-center gap-2 px-3 py-2.5 border border-accent-plum/30 text-accent-plum-light rounded-xl hover:bg-accent-plum/10 transition text-sm"
              title={t('dashboard.fullImport.title')}
            >
              <Database size={14} />
              <Upload size={14} />
              {importing ? t('dashboard.fullImport.restoring') : t('dashboard.fullImport.button')}
            </button>

            <div className="w-px h-8 bg-border" />

            <button
              onClick={() => importRef.current?.click()}
              disabled={importing}
              className="flex items-center gap-2 px-4 py-2.5 border border-border text-text-muted rounded-xl hover:text-text-primary hover:bg-elevated transition"
            >
              <Upload size={16} />
              {importing ? t('dashboard.import.importing') : t('dashboard.import.button')}
            </button>
            <button
              onClick={() => setShowCreate(true)}
              className="flex items-center gap-2 px-5 py-2.5 bg-accent-gold text-deep font-semibold rounded-xl hover:bg-accent-amber transition shadow-lg shadow-accent-gold/20"
            >
              <Plus size={18} />
              {t('dashboard.newProject')}
            </button>
          </div>
        </div>

        {/* The browser has not promised to keep any of this. */}
        <StoragePersistenceWarning />

        {/* Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-accent-gold border-t-transparent rounded-full animate-spin" />
          </div>
        ) : projects.length === 0 ? (
          <EmptyState
            icon={<Feather size={48} />}
            title={t('dashboard.empty.title')}
            message={t('dashboard.empty.message')}
            action={{ label: t('dashboard.empty.action'), onClick: () => setShowCreate(true) }}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {projects.map((project, i) => {
              const stats = progress.get(project.id);
              const resume = resumeTargetFor(project);
              return (
                <ProjectCard
                  key={project.id}
                  project={project}
                  index={i}
                  onClick={() => navigate(`/project/${project.id}`)}
                  onDelete={() => setPendingDeleteProject(project)}
                  onColorChange={(color) => editProject(project.id, { color })}
                  onIconChange={(icon) => editProject(project.id, { icon: icon || undefined })}
                  totalWords={stats?.totalWords ?? 0}
                  daysSinceEdit={
                    stats?.lastWrittenAt != null ? localDaysSince(stats.lastWrittenAt) : null
                  }
                  resumeLabel={resume?.title}
                  onResume={resume ? () => openResume(project, resume) : undefined}
                />
              );
            })}
          </div>
        )}
      </div>

      {/* Create Modal */}
      <CreateProjectModal
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreate={handleCreate}
      />

      <ConfirmDialog
        open={pendingFullImportFile !== null}
        destructive
        message={t('dashboard.fullImport.confirm')}
        onConfirm={runFullImport}
        onCancel={cancelFullImport}
      />

      <ConfirmDialog
        open={pendingDeleteProject !== null}
        destructive
        message={t('dashboard.deleteProject.confirm').replace('{name}', pendingDeleteProject?.title ?? '')}
        onConfirm={runDeleteProject}
        onCancel={() => setPendingDeleteProject(null)}
      />

      <ImportCollisionDialog
        open={pendingProjectImport !== null}
        collisions={pendingProjectImport?.preview.collisions ?? []}
        busy={importing}
        onReplace={runProjectImportReplace}
        onCancel={cancelProjectImport}
      />
    </>
  );
}

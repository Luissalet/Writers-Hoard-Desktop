// ============================================
// Writings Engine — Database Operations
// ============================================

import { db } from '@/db';
import { touchProject } from '@/db/operations';
import { deleteEntityAnnotations } from '@/engines/_shared/deleteEntityAnnotations';
import { notifyDataChanged } from '@/engines/_shared/dataChanged';
import type { Annotation, AnnotationReference } from '@/engines/annotations/types';
import type { Writing } from '@/types';
import type { WritingSnapshot } from './snapshotTypes';

export async function getWritings(projectId: string): Promise<Writing[]> {
  return db.writings.where('projectId').equals(projectId).toArray();
}

export async function getWriting(id: string): Promise<Writing | undefined> {
  return db.writings.get(id);
}

export async function createWriting(writing: Writing): Promise<string> {
  const id = await db.writings.add(writing);
  // The dashboard sorts projects by their own updatedAt, which writing a
  // chapter would otherwise never move.
  void touchProject(writing.projectId);
  return id;
}

export async function updateWriting(id: string, changes: Partial<Writing>): Promise<void> {
  await db.writings.update(id, { ...changes, updatedAt: Date.now() });
}

/**
 * Everything one `deleteWriting` took away, in the shape `restoreDeletedWriting`
 * puts back. The version history is the part that matters: the app never prunes
 * `writingSnapshots`, so a chapter's whole past used to end with the row.
 */
export interface DeletedWritingBundle {
  writing: Writing;
  /** The chapter's entire version history, oldest to newest as stored. */
  snapshots: WritingSnapshot[];
  /** Margin notes anchored on the writing. */
  annotations: Annotation[];
  /** Reference rows hanging off those annotations. */
  annotationReferences: AnnotationReference[];
  /** Beats whose `linkedWritingId` pointed here and was cleared, not deleted. */
  unlinkedBeatIds: string[];
  deletedAt: number;
}

/**
 * The most recent deletion, waiting to be taken back.
 *
 * The UI cannot read `deleteWritingRestorable`'s return value: the writings
 * list deletes through `makeEntityHook`, whose `deleteFn` is typed
 * `(id) => Promise<void>` and drops whatever the operation returns. So the
 * bundle is parked here too, and the delete handler takes it the moment its
 * own delete resolves. One slot: only the last deletion is offered back.
 */
let lastDeleted: DeletedWritingBundle | null = null;

/**
 * Hand over the last deletion's bundle and forget it, so a second caller (or a
 * second render) cannot resurrect a writing the user already restored.
 */
export function takeLastDeletedWriting(): DeletedWritingBundle | null {
  const bundle = lastDeleted;
  lastDeleted = null;
  return bundle;
}

/**
 * Delete a writing, its version history and its margin notes, and UNLINK the
 * outline beats that pointed at it — then hand back every row that went, so the
 * act can be taken back.
 *
 * Same policy as `deleteScene`: what only exists inside the writing goes with
 * it — snapshots, and the annotations anchored on it with their reference
 * rows — while a beat is the author's own text and survives unassigned, ready
 * to be relinked.
 *
 * Everything is READ inside the same transaction that deletes it, so the bundle
 * is exactly what was removed, not what was there a moment earlier. Returns
 * `null` when there was no such writing — nothing was deleted, so there is
 * nothing to offer back.
 */
export async function deleteWritingRestorable(id: string): Promise<DeletedWritingBundle | null> {
  const bundle = await db.transaction(
    'rw',
    [db.writings, db.writingSnapshots, db.outlineBeats, db.annotations, db.annotationReferences],
    async (): Promise<DeletedWritingBundle | null> => {
      const writing = await db.writings.get(id);
      if (!writing) return null;

      const snapshots = await db.writingSnapshots.where('writingId').equals(id).toArray();
      const annotations = await db.annotations
        .where('[sourceEngineId+sourceEntityId]')
        .equals(['writings', id])
        .toArray();
      const annotationReferences = annotations.length
        ? await db.annotationReferences
            .where('annotationId')
            .anyOf(annotations.map(annotation => annotation.id))
            .toArray()
        : [];

      const beatQuery = writing.projectId
        ? db.outlineBeats.where('projectId').equals(writing.projectId)
        : db.outlineBeats.toCollection();
      const linked = (await beatQuery.toArray()).filter(beat => beat.linkedWritingId === id);

      await db.writingSnapshots.where('writingId').equals(id).delete();

      for (const beat of linked) {
        await db.outlineBeats.update(beat.id, { linkedWritingId: undefined });
      }

      await deleteEntityAnnotations('writings', id);

      await db.writings.delete(id);

      return {
        writing,
        snapshots,
        annotations,
        annotationReferences,
        unlinkedBeatIds: linked.map(beat => beat.id),
        deletedAt: Date.now(),
      };
    },
  );

  lastDeleted = bundle;
  if (bundle?.writing.projectId) void touchProject(bundle.writing.projectId);
  return bundle;
}

/**
 * `Promise<void>` face of `deleteWritingRestorable`, kept because both of its
 * callers demand that exact signature and neither is this engine's to retype:
 * `makeEntityHook`'s `deleteFn` and the AI bridge's `DELETABLE` registry. The
 * bundle still reaches the UI through `takeLastDeletedWriting()`.
 */
export async function deleteWriting(id: string): Promise<void> {
  await deleteWritingRestorable(id);
}

/**
 * Put a deleted writing back — row, version history, margin notes, reference
 * rows, and the outline beats that pointed at it.
 *
 * Idempotent by construction: every row goes back with `put`/`bulkPut`, so
 * restoring twice writes the same rows twice and changes nothing. A beat is
 * relinked only while it is still unassigned, so an undo can never steal a beat
 * the writer has since pointed at another chapter.
 */
export async function restoreDeletedWriting(bundle: DeletedWritingBundle): Promise<void> {
  await db.transaction(
    'rw',
    [db.writings, db.writingSnapshots, db.outlineBeats, db.annotations, db.annotationReferences],
    async () => {
      await db.writings.put(bundle.writing);
      if (bundle.snapshots.length) await db.writingSnapshots.bulkPut(bundle.snapshots);
      if (bundle.annotations.length) await db.annotations.bulkPut(bundle.annotations);
      if (bundle.annotationReferences.length) {
        await db.annotationReferences.bulkPut(bundle.annotationReferences);
      }
      for (const beatId of bundle.unlinkedBeatIds) {
        const beat = await db.outlineBeats.get(beatId);
        if (beat && !beat.linkedWritingId) {
          await db.outlineBeats.update(beatId, { linkedWritingId: bundle.writing.id });
        }
      }
    },
  );

  // The restore happened outside every list hook's own write path, so tell the
  // mounted lists (writings, outline, annotations) that their tables moved.
  notifyDataChanged({
    source: 'undo',
    table: 'writings',
    entityId: bundle.writing.id,
    projectId: bundle.writing.projectId,
  });
}

// ============================================================================
// Automatic backup — what the desktop shell can actually promise
// ============================================================================
//
// The plan was an unattended archive: on start, if the last backup is older
// than a week, build a ZIP of every project with `createProjectZipArchive`
// (which returns a blob instead of downloading it — that is what would make it
// possible) and drop it into the app's data folder, keeping the last three.
//
// It cannot be done from here today, and the honest fallback is a reminder.
// The renderer can only touch the disk through what `electron/preload.ts`
// exposes, and every one of those doors is the wrong shape:
//
//   • `media.saveTeleprompterMp4` / `exporter.scriptToPdf` — both end in
//     `saveBytesViaDialog`: a native save dialog, and both transform the bytes
//     (ffmpeg transcode, PDF render) before writing them. Not a silent write,
//     and not our bytes.
//   • `media.downloadToLibrary` — takes an http(s) URL for yt-dlp to fetch in
//     the main process. A renderer `blob:` URL means nothing over there.
//   • `media.deleteLibraryFile` / `readLibraryFile` / `listLibraryFiles` —
//     delete and read managed media. There is no write counterpart.
//
// Inventing `backup:write` would mean editing `electron/preload.ts` and
// `electron/main.ts`, which this change does not own, and stashing the archive
// in IndexedDB or OPFS would be worse than useless: the archive would die with
// exactly the storage it exists to survive. So:
//
//   • `lastBackupAt` is persisted in the existing `settings` store, stamped
//     whenever a full backup actually completes;
//   • the Dashboard shows how old it is, in amber past a week, and the line is
//     itself the one click that runs the backup now;
//   • ROTATION IS SKIPPED. Keeping the newest three archives needs a file API
//     that can delete, and there is none. The user's own downloads folder holds
//     whatever `exportFullZip` saved.
//
// When a `userData` write lands in the preload bridge, `runAutomaticBackup`
// below is the only function that has to change: it already knows when a backup
// is due, and `createProjectZipArchive` already returns the blob.

import { getSetting, setSetting } from '@/db/operations';

/** A backup older than this is overdue; the Dashboard turns amber. */
const BACKUP_INTERVAL_DAYS = 7;

const LAST_BACKUP_KEY = 'backup.lastCompletedAt';
const DAY_MS = 24 * 60 * 60 * 1000;

export interface BackupReminder {
  /** Epoch ms of the last completed full backup, or null if there never was one. */
  lastBackupAt: number | null;
  /** Whole days since that backup; null when there has never been one. */
  daysSince: number | null;
  /** True when a backup is due — never backed up counts as due. */
  overdue: boolean;
  /**
   * The check itself failed (settings unreadable). Set instead of throwing so a
   * broken read can never take the Dashboard down with it; the Dashboard shows
   * the state rather than a stale "you are fine".
   */
  unavailable: boolean;
}

const UNAVAILABLE: BackupReminder = {
  lastBackupAt: null,
  daysSince: null,
  overdue: false,
  unavailable: true,
};

type Listener = (reminder: BackupReminder) => void;

const listeners = new Set<Listener>();
let cached: BackupReminder | null = null;
let checkScheduled = false;

function describe(lastBackupAt: number | null): BackupReminder {
  if (lastBackupAt === null) {
    return { lastBackupAt: null, daysSince: null, overdue: true, unavailable: false };
  }
  const daysSince = Math.max(0, Math.floor((Date.now() - lastBackupAt) / DAY_MS));
  return {
    lastBackupAt,
    daysSince,
    overdue: daysSince >= BACKUP_INTERVAL_DAYS,
    unavailable: false,
  };
}

function publish(reminder: BackupReminder): BackupReminder {
  cached = reminder;
  for (const listener of listeners) listener(reminder);
  return reminder;
}

/** Read the stored stamp and describe it. Never throws. */
export async function readBackupReminder(): Promise<BackupReminder> {
  try {
    const raw = await getSetting(LAST_BACKUP_KEY);
    const stamp = raw ? Number(raw) : Number.NaN;
    return describe(Number.isFinite(stamp) && stamp > 0 ? stamp : null);
  } catch (error) {
    console.error('[autoBackup] could not read the last backup date', error);
    return UNAVAILABLE;
  }
}

/**
 * Stamp a completed full backup. Call it only after the archive really exists —
 * a wrong stamp here is a writer who thinks they are covered and is not.
 */
export async function recordBackupCompleted(at: number = Date.now()): Promise<BackupReminder> {
  try {
    await setSetting(LAST_BACKUP_KEY, String(at));
    return publish(describe(at));
  } catch (error) {
    console.error('[autoBackup] could not record the backup date', error);
    return publish(UNAVAILABLE);
  }
}

/**
 * Watch the reminder. The listener is called immediately with what is already
 * known, and again whenever a backup completes or the startup check lands.
 * Returns the unsubscribe.
 */
export function subscribeBackupReminder(listener: Listener): () => void {
  listeners.add(listener);
  if (cached) listener(cached);
  else void readBackupReminder().then(publish);
  return () => {
    listeners.delete(listener);
  };
}

/**
 * Decide whether a backup is due and make sure somebody hears about it.
 *
 * With no way to write the archive, "run the backup" means "raise the flag the
 * Dashboard shows". Kept as its own function so that the day a `userData` write
 * exists, the archive loop has an obvious home.
 */
async function runAutomaticBackup(): Promise<void> {
  const reminder = publish(await readBackupReminder());
  if (reminder.unavailable) return;
  if (!reminder.overdue) return;
  console.info(
    reminder.lastBackupAt === null
      ? '[autoBackup] no full backup has ever been made'
      : `[autoBackup] last full backup was ${reminder.daysSince} days ago`,
  );
}

/**
 * Kick the check off once, after the app is interactive — never in the path of
 * first paint, and never able to reject into a caller.
 */
export function scheduleStartupBackupCheck(): void {
  if (checkScheduled || typeof window === 'undefined') return;
  checkScheduled = true;
  const run = () => {
    void runAutomaticBackup().catch(error => {
      console.error('[autoBackup] startup check failed', error);
      publish(UNAVAILABLE);
    });
  };
  if (typeof window.requestIdleCallback === 'function') {
    window.requestIdleCallback(run, { timeout: 5000 });
  } else {
    window.setTimeout(run, 2000);
  }
}

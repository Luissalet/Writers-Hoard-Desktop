# Modo 2D — cohesión y funcionalidad

Auditoría completa (76 hallazgos, 12 graves verificados a mano) entregada
en el chat el 2026-08-04. Aquí queda el estado de ejecución.
---

# ESTADO — 2026-08-04, fin de sesión

## Entregado y verificado (tsc + eslint + conformance + dos bancos)

**Tanda 1**
- A1 el 2D pide la geografía completa, en DOS pasadas (0,4 s los puntos, +3,3 s
  calzadas/mares/ruinas en un hueco ocioso). Medido: `places` → 0 caminos,
  `full` → 91 caminos, 163 accidentes, 29 ruinas, y la caché no degrada.
- A2 los rótulos pintados se dibujan donde los pintas · A3 los puntos naturales
  (volcán, cueva, cascada, garganta, fuente) los lee `resolveWorldLandmarks`
- A4 el trazo en vivo del 2D lleva cabeza, caída, afilado, sesgo y espejo
- A5 mares, cordilleras, llanuras y ruinas en el 2D · A6 fronteras
  (`cartography/realmOverlay.ts`, 9 939 segmentos extraídos una vez, 5 ms a
  escala planetaria, 0 dentro de un mismo reino)
- B1-B5 un solo registro `painted` de lo dibujado; los tres tests de impacto
  leen de ahí · botón derecho ya no abre planos bajo el menú del navegador
- C1 `MIN_SPAN_KM` 3 → 0,25 km · C2 el doble clic no aleja (4 001 spans probados)
- Guardia en `conformance` para que A1 no pueda volver en silencio

**Tanda 2**
- C3 el 2D adopta el viewport compartido · C4 vuelve a acotar al bajar el techo
- D1 `journeyPick` se limpia al salir de Viaje · D2 el pincel sobrevive a mirar
  otra pestaña · D3 las pestañas devuelven a la vista de la que veníais
- D4 regenerar limpia viaje, ruta, paleo, índice, ciudad y comarca
- D6 el contador del Pincel cuenta ediciones · el botón de chincheta ya puede
  cancelar (`pinning` era demostrablemente siempre falso)
- E1 la pirámide ya no desaparece al apretar el pincel
- E2 histéresis de zoom semántico (`nextSemanticTier` no la llamaba nadie)
- E3 las ciudades ya no se dibujan dos veces en hondo · E5 el compuesto regional
  sólo en modo atlas + equirect · E6 retícula por tier + escala gráfica
- E7 el sobrevuelo ya no dice «Océano» a un manglar · E8 las chinchetas pasan
  por el desatascador y `textBaseline` se fija una vez por fotograma

**Tanda 3**
- F1 la sonda reserva la sesión del worker y sólo recupera su propio manejador
  (era lo que podía dejar la pirámide sin cargar para el resto de la sesión)
- F2 un trazo en vivo pertenece a un objeto-mundo: se deshace al desmontar y no
  puede escribirse sobre otro mundo
- F3 las claves de caché identifican el OBJETO mundo, no la semilla · F4 la
  identidad de la geografía entra en la clave de teselas
- F5 la rama envuelta se mide contra el CENTRO de la vista
- F6 Ctrl+Z no toca el mundo dentro de un campo de texto, y 2D y 3D comparten
  keymap · Espacio se suelta al perder el foco
- F7 `pointercancel` limpia el arrastre · F8 el lienzo ya no se repinta entero
  al mover el ratón · E4 los nombres profundos son LRU y con guarda de generación

**Tanda 4 (parcial)**
- G2 las tres pistas ya no prometen «ver en 3D» ni «bajar a la comarca»
- G1a `COVER_LABEL_ES` ya no cambia el idioma del sobrevuelo con el zoom
  (20 claves `worldgen.cover.*` nuevas en los dos catálogos)

## Pendiente

- **G1b el barrido de idioma grande**: ~230 cadenas en duro en PaintPanel (~146),
  World3D (~40), WorldView (~41), CartoMap y los seis paneles sin
  `useTranslation`. Mecánico, mucho fichero, ningún riesgo de comportamiento.
- F9 `want()` en cada fotograma y el `cancel` de `requestTile` que se tira
- F10 fugas menores del `tileStore` · F11 el ancla del pincel sin `spec.inverse`
- F12 el radio oculto de los borradores de Punto y Camino
- B6 el anillo del pincel media celda al sur-este · D5 el chip para quitar el
  nivel paleo · E9/E10 los interruptores que no llegan a las teselas profundas
- D3b el Índice y Viaje siguen forzando la Carta porque `annotations` sólo se
  le pasa a ella (dibujar la ruta en el 2D quitaría el forzado)

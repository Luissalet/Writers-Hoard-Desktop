import Dexie, { type Table } from 'dexie';
import { db } from '@/db';
import { stripHtml } from '@/utils/text';

export interface ContentSearchHit {
  id: string;
  engineId: string;
  projectId: string;
  title: string;
  subtitle: string;
  snippet: string;
}

interface SearchDocument extends Omit<ContentSearchHit, 'snippet'> {
  body: string;
}

/** One table (or tight group of tables) worth of indexable prose. */
interface IndexSlice {
  /** Dexie tables whose mutation makes this slice stale. */
  tables: readonly string[];
  build: (projectId?: string) => Promise<SearchDocument[]>;
}

const GLOBAL_KEY = '*';

/** projectId (or `*`) → slice key → documents. */
const caches = new Map<string, Map<string, SearchDocument[]>>();
const pending = new Map<string, Promise<SearchDocument[]>>();
/** Bumped whenever a slice is invalidated, so an in-flight build is discarded. */
const stamps = new Map<string, number>();

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function excerpt(plain: string, index: number, length: number): string {
  const start = Math.max(0, index - 40);
  const end = Math.min(plain.length, index + length + 40);
  return `${start > 0 ? '…' : ''}${plain.slice(start, end).trim()}${end < plain.length ? '…' : ''}`;
}

/**
 * Stream one table and keep only the projected fields. The rows themselves are
 * never retained, so the base64 columns some of these tables carry (`avatar`,
 * `avatarOriginal`, `thumbnail`, `screenshotBase64`, `htmlContent`) never reach
 * the cache — only the text that is actually matched does.
 */
async function projectRows<T, D>(
  table: Table<T>,
  projectId: string | undefined,
  select: (row: T) => D,
): Promise<D[]> {
  const projected: D[] = [];
  const collection = projectId
    ? table.where('projectId').equals(projectId)
    : table.toCollection();
  await collection.each((row) => {
    projected.push(select(row));
  });
  return projected;
}

/**
 * The body index, one slice per source table.
 *
 * Deliberately absent: `boardNodes`, `inspirationImages`, `storyboardPanels`
 * and `videoSegments`. All four store base64 images inline, and loading them
 * here would deserialise every picture in the project on the first keystroke —
 * the exact regression `engines/board/index.ts` records having already been
 * fixed once. Their titles remain searchable through the entity resolvers.
 */
const SLICES: Record<string, IndexSlice> = {
  writings: {
    tables: ['writings'],
    build: projectId => projectRows(db.writings, projectId, writing => ({
      id: writing.id,
      engineId: 'writings',
      projectId: writing.projectId,
      title: writing.title,
      subtitle: writing.status,
      body: stripHtml(writing.content ?? ''),
    })),
  },
  codexEntries: {
    tables: ['codexEntries'],
    build: projectId => projectRows(db.codexEntries, projectId, entry => ({
      id: entry.id,
      engineId: 'codex',
      projectId: entry.projectId,
      title: entry.title,
      subtitle: entry.type,
      body: stripHtml(entry.content ?? ''),
    })),
  },
  diaryEntries: {
    tables: ['diaryEntries'],
    build: projectId => projectRows(db.diaryEntries, projectId, entry => ({
      id: entry.id,
      engineId: 'diary',
      projectId: entry.projectId,
      title: entry.title || entry.entryDate,
      subtitle: 'diary',
      body: stripHtml(entry.content ?? ''),
    })),
  },
  dialogBlocks: {
    tables: ['dialogBlocks', 'scenes'],
    async build(projectId) {
      const scenes = await projectRows(db.scenes, projectId, scene => ({
        id: scene.id,
        projectId: scene.projectId,
        title: scene.title,
      }));
      const sceneById = new Map(scenes.map(scene => [scene.id, scene]));
      const blocks = await projectRows(db.dialogBlocks, projectId, block => ({
        sceneId: block.sceneId,
        subtitle: block.characterName || block.type,
        body: stripHtml(block.content ?? ''),
      }));
      return blocks.flatMap((block) => {
        const scene = sceneById.get(block.sceneId);
        if (!scene) return [];
        return [{
          id: scene.id,
          engineId: 'dialog-scene',
          projectId: scene.projectId,
          title: scene.title,
          subtitle: block.subtitle,
          body: block.body,
        }];
      });
    },
  },
  snapshots: {
    tables: ['snapshots'],
    build: projectId => projectRows(db.snapshots, projectId, snapshot => ({
      id: snapshot.id,
      engineId: 'scrapper',
      projectId: snapshot.projectId,
      title: snapshot.title || snapshot.url,
      subtitle: snapshot.source,
      body: stripHtml([
        snapshot.description,
        snapshot.notes,
        snapshot.extractedText,
        snapshot.author,
        snapshot.tags.join(' '),
      ].filter(Boolean).join('\n')),
    })),
  },
  notes: {
    tables: ['notes'],
    build: projectId => projectRows(db.notes, projectId, note => ({
      id: note.id,
      engineId: 'notes',
      projectId: note.projectId,
      title: note.text.split('\n')[0]?.slice(0, 80) ?? '',
      subtitle: note.kind,
      body: [note.text, note.source, note.tags.join(' ')].filter(Boolean).join('\n'),
    })),
  },
  outlineBeats: {
    tables: ['outlineBeats'],
    build: projectId => projectRows(db.outlineBeats, projectId, beat => ({
      id: beat.id,
      engineId: 'outline',
      projectId: beat.projectId,
      title: beat.title,
      subtitle: beat.level,
      body: [beat.title, beat.description].filter(Boolean).join('\n'),
    })),
  },
  seeds: {
    tables: ['seeds'],
    build: projectId => projectRows(db.seeds, projectId, seed => ({
      id: seed.id,
      engineId: 'seeds',
      projectId: seed.projectId,
      title: seed.title,
      subtitle: seed.kind,
      body: [seed.title, seed.description, seed.locationLabel, seed.tags.join(' ')]
        .filter(Boolean).join('\n'),
    })),
  },
  payoffs: {
    tables: ['payoffs'],
    build: projectId => projectRows(db.payoffs, projectId, payoff => ({
      id: payoff.seedId,
      engineId: 'seeds',
      projectId: payoff.projectId,
      title: payoff.title,
      subtitle: 'payoff',
      body: [payoff.title, payoff.description, payoff.locationLabel].filter(Boolean).join('\n'),
    })),
  },
  characterArcs: {
    tables: ['characterArcs'],
    build: projectId => projectRows(db.characterArcs, projectId, arc => ({
      id: arc.id,
      engineId: 'character-arc',
      projectId: arc.projectId,
      title: arc.title,
      subtitle: arc.characterName ?? arc.status,
      // The five spine fields are the arc: without them it is just a title.
      body: [arc.title, arc.summary, arc.ghost, arc.lie, arc.truth, arc.want, arc.need]
        .filter(Boolean).join('\n'),
    })),
  },
  arcBeats: {
    tables: ['arcBeats'],
    build: projectId => projectRows(db.arcBeats, projectId, beat => ({
      id: beat.arcId,
      engineId: 'character-arc',
      projectId: beat.projectId,
      title: beat.title,
      subtitle: beat.stage,
      body: [beat.title, beat.description, beat.emotion].filter(Boolean).join('\n'),
    })),
  },
  relationships: {
    tables: ['relationships'],
    build: projectId => projectRows(db.relationships, projectId, relationship => ({
      id: relationship.id,
      engineId: 'relationships',
      projectId: relationship.projectId,
      title: `${relationship.entityAName} – ${relationship.entityBName}`,
      subtitle: relationship.kind,
      body: [relationship.label, relationship.notes, relationship.entityAName, relationship.entityBName]
        .filter(Boolean).join('\n'),
    })),
  },
  biographyFacts: {
    tables: ['biographyFacts'],
    build: projectId => projectRows(db.biographyFacts, projectId, fact => ({
      id: fact.biographyId,
      engineId: 'biography',
      projectId: fact.projectId,
      title: fact.title,
      subtitle: fact.category,
      body: [fact.title, stripHtml(fact.content ?? ''), fact.date, fact.tags.join(' ')]
        .filter(Boolean).join('\n'),
    })),
  },
  timelineEvents: {
    tables: ['timelineEvents'],
    build: projectId => projectRows(db.timelineEvents, projectId, event => ({
      id: event.id,
      engineId: 'timeline',
      projectId: event.projectId,
      title: event.title,
      subtitle: event.date || event.eventType,
      body: [event.title, event.description, event.date, event.lane].filter(Boolean).join('\n'),
    })),
  },
  mapPins: {
    tables: ['mapPins'],
    build: projectId => projectRows(db.mapPins, projectId, pin => ({
      id: pin.id,
      engineId: 'maps',
      projectId: pin.projectId,
      title: pin.name,
      subtitle: pin.icon,
      body: [pin.name, pin.description].filter(Boolean).join('\n'),
    })),
  },
  atlasPlaces: {
    tables: ['atlasPlaces'],
    build: projectId => projectRows(db.atlasPlaces, projectId, place => ({
      id: place.id,
      engineId: 'real-atlas',
      projectId: place.projectId,
      title: place.name,
      subtitle: place.kind,
      body: [place.name, ...place.aliases, place.address, place.era, place.description, place.realNotes, ...place.tags]
        .filter(Boolean)
        .join('\n'),
    })),
  },
  atlasDivergences: {
    tables: ['atlasDivergences'],
    build: projectId => projectRows(db.atlasDivergences, projectId, divergence => ({
      id: divergence.id,
      engineId: 'real-atlas',
      projectId: divergence.projectId,
      title: divergence.title,
      subtitle: divergence.category,
      body: [divergence.title, divergence.reality, divergence.fiction, divergence.reason, ...divergence.tags]
        .filter(Boolean)
        .join('\n'),
    })),
  },
  annotations: {
    tables: ['annotations'],
    build: projectId => projectRows(db.annotations, projectId, annotation => ({
      id: annotation.id,
      engineId: 'annotations',
      projectId: annotation.projectId,
      title: annotation.anchor.selectedText || annotation.sourceEngineId,
      subtitle: annotation.sourceEngineId,
      // noteImageUrl may be a data URL — never indexed.
      body: [annotation.noteBody, annotation.anchor.selectedText].filter(Boolean).join('\n'),
    })),
  },
};

async function sliceDocuments(
  projectKey: string,
  sliceKey: string,
  slice: IndexSlice,
  projectId: string | undefined,
): Promise<SearchDocument[]> {
  let cache = caches.get(projectKey);
  if (!cache) {
    cache = new Map();
    caches.set(projectKey, cache);
  }
  const cached = cache.get(sliceKey);
  if (cached) return cached;

  const pendingKey = `${projectKey}/${sliceKey}`;
  const inFlight = pending.get(pendingKey);
  if (inFlight) return inFlight;

  const stamp = stamps.get(sliceKey) ?? 0;
  const build = slice.build(projectId).then(
    (documents) => {
      const kept = documents.filter(document => /\S/.test(document.body));
      pending.delete(pendingKey);
      // Discard the result if the slice was invalidated while it was building.
      if ((stamps.get(sliceKey) ?? 0) === stamp) {
        (caches.get(projectKey) ?? cache).set(sliceKey, kept);
      }
      return kept;
    },
    (error: unknown) => {
      pending.delete(pendingKey);
      throw error;
    },
  );
  pending.set(pendingKey, build);
  return build;
}

/** Search prose from an invalidation-aware index instead of rescanning tables per keypress. */
export async function searchProjectContent(
  query: string,
  projectId?: string,
  limit = 8,
): Promise<ContentSearchHit[]> {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  if (normalizedQuery.length < 3) return [];
  const projectKey = projectId ?? GLOBAL_KEY;
  const matcher = new RegExp(escapeRegExp(normalizedQuery), 'i');
  const seen = new Set<string>();
  const hits: ContentSearchHit[] = [];

  for (const [sliceKey, slice] of Object.entries(SLICES)) {
    const documents = await sliceDocuments(projectKey, sliceKey, slice, projectId);
    for (const document of documents) {
      if (projectId && document.projectId !== projectId) continue;
      const match = matcher.exec(document.body);
      if (!match) continue;
      const key = `${document.engineId}:${document.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      hits.push({
        id: document.id,
        engineId: document.engineId,
        projectId: document.projectId,
        title: document.title,
        subtitle: document.subtitle,
        snippet: excerpt(document.body, match.index, normalizedQuery.length),
      });
      if (hits.length >= limit) break;
    }
    if (hits.length >= limit) break;
  }
  return hits;
}

function invalidateSlices(sliceKeys: Iterable<string>): void {
  for (const sliceKey of sliceKeys) {
    stamps.set(sliceKey, (stamps.get(sliceKey) ?? 0) + 1);
    for (const cache of caches.values()) cache.delete(sliceKey);
  }
}

export function invalidateProjectSearchIndex(): void {
  invalidateSlices(Object.keys(SLICES));
  caches.clear();
  pending.clear();
}

/**
 * `storagemutated` names the parts that changed as `idb://<db>/<table>/<index>`.
 * Only the slices fed by those tables are dropped, so an autosave in Writings
 * no longer forces every other engine to be read again on the next keystroke.
 * Anything we cannot parse falls back to dropping the whole index.
 */
function mutatedTables(parts?: Record<string, unknown>): Set<string> | null {
  if (!parts) return null;
  const tables = new Set<string>();
  for (const part of Object.keys(parts)) {
    const table = /^idb:\/\/[^/]+\/([^/]+)/.exec(part)?.[1];
    if (!table || table === '*') return null;
    tables.add(table);
  }
  return tables.size > 0 ? tables : null;
}

function onStorageMutated(parts?: Record<string, unknown>): void {
  const tables = mutatedTables(parts);
  if (!tables) {
    invalidateProjectSearchIndex();
    return;
  }
  invalidateSlices(
    Object.keys(SLICES).filter(key => SLICES[key].tables.some(table => tables.has(table))),
  );
}

// Cross-window writes (including quick capture) invalidate the same cache.
Dexie.on('storagemutated', onStorageMutated);

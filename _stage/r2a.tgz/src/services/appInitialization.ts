import { db } from '@/db';

let initialization: Promise<void> | null = null;

/**
 * A job is only ever left mid-flight by a crash or a kill — a clean shutdown
 * leaves none — so this pass finds nothing on almost every launch. It used to
 * pay for that certainty with `toCollection().modify()`: a cursor over every
 * snapshot row, base64 archives and all, held under a readwrite lock while the
 * rest of the app was trying to start. The scan is now read-only and collects
 * keys, and the write is aimed at exactly those keys — so the usual "nothing to
 * repair" launch opens no write transaction at all.
 */
async function reconcileInterruptedNativeJobs(): Promise<void> {
  const interrupted: string[] = [];
  await db.snapshots.each(snapshot => {
    if (snapshot.downloadState === 'downloading' || snapshot.captureState === 'capturing') {
      interrupted.push(snapshot.id);
    }
  });
  if (interrupted.length === 0) return;
  await db.snapshots.where('id').anyOf(interrupted).modify(snapshot => {
    if (snapshot.downloadState === 'downloading') {
      snapshot.downloadState = 'error';
      snapshot.downloadError = 'The app closed before this download finished. Retry it.';
    }
    if (snapshot.captureState === 'capturing') {
      snapshot.captureState = 'error';
      snapshot.captureError = 'The app closed before this capture finished. Retry it.';
    }
  });
}

/**
 * Idempotent process initialization. React StrictMode may call this twice;
 * every caller receives the same promise and the reconciliation runs once.
 */
export function initializeAppServices(): Promise<void> {
  initialization ??= reconcileInterruptedNativeJobs().catch(error => {
    initialization = null;
    throw error;
  });
  return initialization;
}

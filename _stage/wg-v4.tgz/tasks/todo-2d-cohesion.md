# Modo 2D — cohesión y funcionalidad

Auditoría completa (76 hallazgos, 12 graves verificados a mano) entregada
en el chat el 2026-08-04. Aquí queda el estado de ejecución.
---

# ESTADO — 2026-08-04, fin de sesión

## Entregado y verificado (tsc + eslint + conformance + dos bancos)

**Tanda 1**
- A1 el 2D pide la geografía completa, en DOS pasadas (0,4 s los puntos, +3,3 s
  calzadas/mares/ruinas en un hueco ocioso). Medido: `places` → 0 caminos,
  `full` → 91 caminos, 163 accidentes, 29 ruinas, y la caché no degrada.
- A2 los rótulos pintados se dibujan donde los pintas · A3 los puntos naturales
  (volcán, cueva, cascada, garganta, fuente) los lee `resolveWorldLandmarks`
- A4 el trazo en vivo del 2D lleva cabeza, caída, afilado, sesgo y espejo
- A5 mares, cordilleras, llanuras y ruinas en el 2D · A6 fronteras
  (`cartography/realmOverlay.ts`, 9 939 segmentos extraídos una vez, 5 ms a
  escala planetaria, 0 dentro de un mismo reino)
- B1-B5 un solo registro `painted` de lo dibujado; los tres tests de impacto
  leen de ahí · botón derecho ya no abre planos bajo el menú del navegador
- C1 `MIN_SPAN_KM` 3 → 0,25 km · C2 el doble clic no aleja (4 001 spans probados)
- Guardia en `conformance` para que A1 no pueda volver en silencio

**Tanda 2**
- C3 el 2D adopta el viewport compartido · C4 vuelve a acotar al bajar el techo
- D1 `journeyPick` se limpia al salir de Viaje · D2 el pincel sobrevive a mirar
  otra pestaña · D3 las pestañas devuelven a la vista de la que veníais
- D4 regenerar limpia viaje, ruta, paleo, índice, ciudad y comarca
- D6 el contador del Pincel cuenta ediciones · el botón de chincheta ya puede
  cancelar (`pinning` era demostrablemente siempre falso)
- E1 la pirámide ya no desaparece al apretar el pincel
- E2 histéresis de zoom semántico (`nextSemanticTier` no la llamaba nadie)
- E3 las ciudades ya no se dibujan dos veces en hondo · E5 el compuesto regional
  sólo en modo atlas + equirect · E6 retícula por tier + escala gráfica
- E7 el sobrevuelo ya no dice «Océano» a un manglar · E8 las chinchetas pasan
  por el desatascador y `textBaseline` se fija una vez por fotograma

**Tanda 3**
- F1 la sonda reserva la sesión del worker y sólo recupera su propio manejador
  (era lo que podía dejar la pirámide sin cargar para el resto de la sesión)
- F2 un trazo en vivo pertenece a un objeto-mundo: se deshace al desmontar y no
  puede escribirse sobre otro mundo
- F3 las claves de caché identifican el OBJETO mundo, no la semilla · F4 la
  identidad de la geografía entra en la clave de teselas
- F5 la rama envuelta se mide contra el CENTRO de la vista
- F6 Ctrl+Z no toca el mundo dentro de un campo de texto, y 2D y 3D comparten
  keymap · Espacio se suelta al perder el foco
- F7 `pointercancel` limpia el arrastre · F8 el lienzo ya no se repinta entero
  al mover el ratón · E4 los nombres profundos son LRU y con guarda de generación

**Tanda 4 (parcial)**
- G2 las tres pistas ya no prometen «ver en 3D» ni «bajar a la comarca»
- G1a `COVER_LABEL_ES` ya no cambia el idioma del sobrevuelo con el zoom
  (20 claves `worldgen.cover.*` nuevas en los dos catálogos)

## Pendiente

- **G1b el barrido de idioma grande**: ~230 cadenas en duro en PaintPanel (~146),
  World3D (~40), WorldView (~41), CartoMap y los seis paneles sin
  `useTranslation`. Mecánico, mucho fichero, ningún riesgo de comportamiento.
- F9 `want()` en cada fotograma y el `cancel` de `requestTile` que se tira
- F10 fugas menores del `tileStore` · F11 el ancla del pincel sin `spec.inverse`
- F12 el radio oculto de los borradores de Punto y Camino
- B6 el anillo del pincel media celda al sur-este · D5 el chip para quitar el
  nivel paleo · E9/E10 los interruptores que no llegan a las teselas profundas
- D3b el Índice y Viaje siguen forzando la Carta porque `annotations` sólo se
  le pasa a ella (dibujar la ruta en el 2D quitaría el forzado)


---

# SEGUNDA PASADA — 2026-08-04, misma sesión

Auditoría adversarial de lo que la primera pasada cambió, más una pasada de
funcionalidad. **Ocho de los hallazgos graves eran regresiones mías.** Eso es lo
que vale de haber vuelto a mirar.

## Regresiones propias, corregidas y medidas
- [x] 🔴 **El registro `painted` mataba TODO clic en poblaciones bajo ~850 km.**
  Salté el bloque entero cuando las teselas profundas dibujan la ciudad — y ese
  bloque es donde se empujan los impactos. Resultado: el plano de ciudad, el
  pincel Camino y el selector de Viaje, muertos justo en los zooms donde se
  trabaja. Ahora se salta sólo el PUNTO; el impacto y el anillo de la punta
  pendiente se empujan siempre.
- [x] 🔴 **Quitar `!stroke.current` dejó el pincel MÁS ciego, no menos.** La
  pirámide se dibuja DESPUÉS de la ventana nítida, así que tapaba la única
  superficie que `patchLive` actualiza. El orden es condicional ahora
  (`blitSharp` antes o después según haya gesto vivo).
- [x] 🔴 **La sonda reservaba la sesión del worker y no despertaba la cola.**
  Faltaba `notifyFree()`: una tesela pedida durante los 400 ms de una sonda se
  quedaba esperando una notificación que ya no podía llegar.
- [x] 🔴 **`worldId(geography)` en la clave de teselas** tiraba la pirámide
  entera cuando aterrizaba la segunda pasada de geografía. Ahora la clave son los
  recuentos de lo que las teselas entintan.
- [x] 🔴 **`geoBusy` colgado y la pasada honda bloqueada por el pincel** — justo
  la pasada que produce los caminos que el pincel Camino necesita.
- [x] 🔴 **`abandonLive` tiraba el trazo de bioma en vez de deshacerlo.**
- [x] 🟠 **Las fronteras costaban 15 ms/fotograma en la vista por defecto.** El
  recorte estaba desactivado justo ahí (`view.w ≈ 1,02·W`). Ventana por copia +
  camino afín para equirect + fusión de tiradas colineales: **15 → 6 ms**, y
  9 939 → 5 781 segmentos dibujando la misma línea.
- [x] 🟠 El tier avanzaba un escalón por FOTOGRAMA (salto a punto fijo ahora);
  `paintable` seguía atado a la pestaña (el botón de chincheta decía «Cancelar» y
  no ponía nada); el orden de impacto pasó de distancia² a distancia lineal y
  cambiaba de ganador; la adopción de cámara guardaba lo pedido y no lo logrado;
  `realmBorders` recorría 2 M celdas desde un rAF; `regionalResolution` fijado a
  768 subía 1,44× el coste regional.
- [x] El banco no veía nada de esto: sólo muestreaba spans, nunca la vista
  ajustada. **Añadido el caso, y es el que fallaba.**

## Funcionalidad nueva
- [x] **Regenerar pide confirmación** y copia las ediciones al portapapeles antes
  de borrarlas. Un clic destruía horas de trabajo sin aviso ni deshacer.
- [x] **El sobrevuelo dice qué es lo que hay debajo**: nombre, rango, habitantes,
  reino, puerto o río — en vez del suelo. Y el reino aparece en la lectura de
  terreno, que era lo que faltaba para que las fronteras significaran algo.
- [x] **Ruinas, mares con nombre y tus propios rótulos responden al puntero.**

## Idioma — barrido completo
- [x] 453 claves nuevas, **1 618 en el catálogo**, es/en sin divergencia, cero
  claves sin resolver en todo el motor. `PaintPanel` (162), los siete paneles
  (177), `World3D` (43), `WorldView` + `Map2D` (71).

## Sigue pendiente
- F9 `want()` en cada fotograma y el `cancel` de `requestTile` que se tira
- F10 fugas del `tileStore` · F11 ancla del pincel sin `spec.inverse` · F12 el
  radio oculto de los borradores · B6 el anillo media celda al sur-este
- `tilesInView` devuelve la `tx` ya envuelta, así que las dos columnas de costura
  colapsan y el contador «terreno · n/m» cuenta de más
- Exportar PNG sigue capturando el ráster del mundo, no el mapa que estás viendo
- Nada se puede MOVER arrastrándolo; `AppliedEdits.moves` sólo lo lee
  `spatialEntities`
- Los nombres de río no salen en el 2D (`f.kind === 'river'` se salta)
- Índice y Viaje siguen forzando la Carta porque `annotations` sólo se le pasa a ella
- Tablas de etiquetas en `core/` (`MODE_ES`, `RUIN_KIND_ES`, `LINK_KIND_ES`…) sin traducir

## TERCERA TANDA — lo pendiente, hecho

- [x] **Exportar el mapa que estás mirando.** `Map2D` expone un renderizador por
  `exportRef`; el menú ofrece resolución de pantalla y doble. Antes exportaba el
  ráster del planeta entero sin ciudades, caminos, fronteras, nombres ni satélite.
- [x] **`exportCarta` ya no congela la pestaña en silencio**: cede un fotograma,
  enseña que está trabajando y avisa si falla.
- [x] **El pincel, en el 2D**: Ctrl+rueda cambia el tamaño, Alt toma el bioma de
  debajo, y la pista de abajo lo dice.
- [x] **Ancho de río en metros** (20 m – 5 km) en vez de en celdas de 39 km. La
  unidad guardada sigue siendo celdas, así que lo ya pintado se reproduce igual.
- [x] **El radio oculto de los borradores**: Ctrl+clic con Camino borraba todo
  camino en ~350 km. Ahora 2 celdas, independiente del pincel.
- [x] **El canal de teselas**: las peticiones se cancelan al salir de la ventana,
  al cambiar de generación y al desmontar; épocas para que una promesa caduca no
  borre el marcador de la nueva ni pise un bitmap sin cerrarlo; `dispose()` para
  las llegadas tardías; y `want()` deja de pedir en cada fotograma de un arrastre.
- [x] **Las dos columnas de costura ya no colapsan**: `tilesInView` devuelve la
  columna sin envolver junto al identificador envuelto, así que cada aparición se
  coloca y el contador «terreno · n/m» deja de contar de más.
- [x] **La franja basta al redimensionar en alto**: faltaba `vh` en la prueba de
  obsolescencia de la ventana nítida.
- [x] **Nombres de reino y de río en el mapa.**
- [x] El ancla del pincel ya no cae a la celda (0,0) en el margen de una
  proyección curva.

### Sigue pendiente
- Mover cosas arrastrándolas (`AppliedEdits.moves` sólo lo lee `spatialEntities`)
- Índice y Viaje fuerzan la Carta porque `annotations` sólo se le pasa a ella
- Localizador / tecla Inicio / pila de vistas anteriores
- Las comarcas guardadas no se dibujan sobre el mapa
- `eraseRivers` sigue con el radio derivado del ancho de río
- Tablas de etiquetas en `core/` (`MODE_ES`, `RUIN_KIND_ES`, `LINK_KIND_ES`…)
- El anillo del pincel miente media celda (B6)

import JSZip from 'jszip';
import { db } from '@/db';
import '@/engines/timeline';
import '@/engines/gallery';
import '@/engines/board';
import '@/engines/annotations';
import '@/engines/scrapper';
import '@/engines/writings';
import '@/engines/codex';
import '@/engines/dialog-scene';
import '@/engines/diary';
import '@/engines/notes';
import '@/engines/outline';
import '@/services/projectToolsBackup';
import { getAllBackupStrategies } from '@/engines/_shared/backupRegistry';
import {
  deleteWriting,
  deleteWritingRestorable,
  expectDeletedWriting,
  restoreDeletedWriting,
  takeLastDeletedWriting,
} from '@/engines/writings/operations';
import { deleteBoardNode } from '@/engines/board/operations';
import {
  clearWritingRecoveryDraft,
  readWritingRecoveryDraft,
  writeWritingRecoveryDraft,
} from '@/engines/writings/recoveryJournal';
import { toLocalDateKey } from '@/engines/writing-stats/date';
import {
  getCurrentProjectIdFromUrl,
  installNavigator,
} from '@/engines/_shared/anchoring/navigation';
import { getAnchorAdapter } from '@/engines/_shared/anchoring/registry';
import { registerFallbackAnchorAdapters } from '@/engines/_shared/anchoring/registerFallbackAdapters';
import type { Scene, DialogBlock } from '@/engines/dialog-scene/types';
import { testWorldgenSpatialEntities } from './worldgen-spatial-entities';
import { testWorldgenSemanticZoom } from './worldgen-semantic-zoom';
import { testAiBridgeContracts } from './ai-bridge';
import { testAiRuntimeContracts } from './ai-runtime';
import { runRegionInfraTests } from './worldgen-region-infra.test';
import { testWorldgenDetailShader } from './worldgen-rendering';
import { testWorldgenBridgeAccess } from './worldgen-bridge';
import {
  createProjectZipArchive,
  importProjectZip,
  previewProjectZipImport,
} from '@/services/zipBackup';
import { sanitizeRichHtml } from '@/utils/sanitizeRichHtml';
import {
  foldSearchText,
  parseSearchQuery,
  hasExcludedText,
  findRequiredMatch,
} from '@/services/searchQuery';
import {
  calculateCoverage,
  deriveNarrativeContinuity,
  deriveProjectHealthStatus,
  loadProjectCockpit,
} from '@/services/projectIntelligence';
import { readWorldRenameEdits } from '@/engines/worldgen/core/readRenameEdits';
import {
  buildPublishingArtifacts,
  citationFromSnapshot,
  formatCitation,
  normalizePublishingProfile,
  resolvePublishingWritings,
} from '@/services/projectTools';
import {
  buildCommandCenterActions,
  commandCenterSearchKey,
  filterCommandCenterActions,
  moveCommandCenterSelection,
} from '@/services/commandCenter';
import {
  COCKPIT_GROUPS,
  getCockpitGroup,
  resolveCockpitTab,
} from '@/components/project/cockpitNavigation';
import type { Writing } from '@/types';
import type { Citation, PublishingProfile } from '@/types/projectTools';
import type { ProofreaderInput, ProofreaderWritingRow } from '@/services/proofreader';
import type { AiMessage } from '@/services/copilot/types';

registerFallbackAnchorAdapters();

declare global {
  interface Window {
    __criticalResult?: {
      ok: boolean;
      tests: string[];
      error?: string;
    };
    // Live view of `passed`, so a harness timeout can name the test that hung
    // instead of only reporting that the whole suite stopped answering.
    __criticalProgress?: string[];
    __criticalStage?: string;
  }
}

const passed: string[] = [];
window.__criticalProgress = passed;
const stage = (label: string): void => { window.__criticalStage = label; };

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

async function testMigration(): Promise<void> {
  await db.delete();
  await db.open();
  assert(db.verno === 28, `expected schema v28, received v${db.verno}`);
  for (const table of [
    'entityLinks', 'citations', 'publishingProfiles', 'conversionReceipts',
    'boards', 'boardNodes', 'boardEdges', 'boardLayers', 'boardViews',
    'canonTiles', 'renderedTiles',
    'aiThreads', 'aiMessages', 'aiProjectSettings',
    'atlasPlaces', 'atlasDivergences',
  ]) {
    assert(db.tables.some(row => row.name === table), `missing migrated table ${table}`);
  }
  // The two engines `board` replaced must be gone, not merely unused: a
  // leftover store is a leftover code path waiting to be revived by accident.
  for (const retired of [
    'yarnBoards', 'yarnNodes', 'yarnEdges',
    'brainstormBoards', 'brainstormItems', 'brainstormConnections',
  ]) {
    assert(!db.tables.some(row => row.name === retired), `retired table ${retired} still exists`);
  }
  passed.push('Dexie migration v28');
}

async function seedBackupFixture(projectId: string): Promise<string[]> {
  const now = Date.now();
  await db.timelines.add({ id: 'timeline-1', projectId, title: 'Main', color: '#fff', createdAt: now, updatedAt: now });
  await db.timelineEvents.add({
    id: 'event-1', projectId, timelineId: 'timeline-1', title: 'Inciting event',
    description: '', date: 'Day one', dateMode: 'text', eventType: 'point',
    order: 0, lane: 'main', color: '#fff', createdAt: now, updatedAt: now,
  });
  await db.timelineConnections.add({
    id: 'timeline-link-1', projectId, timelineId: 'timeline-1',
    sourceEventId: 'event-1', targetEventId: 'event-1', color: '#fff',
    style: 'dashed', createdAt: now,
  });
  await db.imageCollections.add({ id: 'collection-empty', projectId, title: 'Empty survives', createdAt: now });
  await db.boards.add({ id: 'board-1', projectId, title: 'Board', surface: 'cork', createdAt: now, updatedAt: now });
  await db.boardNodes.bulkAdd([
    { id: 'board-node-1', projectId, boardId: 'board-1', kind: 'card', title: 'A', content: '', color: '#fff', position: { x: 0, y: 0 }, size: { width: 200, height: 120 }, zIndex: 0, tags: [], createdAt: now, updatedAt: now },
    { id: 'board-node-2', projectId, boardId: 'board-1', kind: 'card', title: 'B', content: '', color: '#fff', position: { x: 1, y: 1 }, size: { width: 200, height: 120 }, zIndex: 0, tags: [], createdAt: now, updatedAt: now },
    { id: 'board-node-3', projectId, boardId: 'board-1', kind: 'card', title: 'C', content: '', color: '#fff', position: { x: 2, y: 2 }, size: { width: 200, height: 120 }, zIndex: 0, tags: [], createdAt: now, updatedAt: now },
  ]);
  // A hyper-edge plus a relation anchored on that relation: the two shapes
  // React Flow cannot express, and the two the backup must round-trip.
  await db.boardEdges.bulkAdd([
    {
      id: 'board-edge-1', projectId, boardId: 'board-1',
      sourceId: 'board-node-1', targetId: 'board-node-3',
      sources: [{ id: 'board-node-1', on: 'node' }, { id: 'board-node-2', on: 'node' }],
      targets: [{ id: 'board-node-3', on: 'node' }],
      kind: 'causes', color: '#fff', style: 'solid', width: 0, direction: 'forward',
      curvature: 'curved', weight: 1, certainty: 1, tags: [], createdAt: now, updatedAt: now,
    },
    {
      id: 'board-edge-2', projectId, boardId: 'board-1',
      sourceId: 'board-node-3', targetId: 'board-edge-1',
      sources: [{ id: 'board-node-3', on: 'node' }],
      targets: [{ id: 'board-edge-1', on: 'edge' }],
      kind: 'mystery', color: '#fff', style: 'dashed', width: 0, direction: 'forward',
      curvature: 'curved', weight: 1, certainty: 0.5, tags: [], createdAt: now, updatedAt: now,
    },
  ]);
  await db.boardLayers.add({
    id: 'board-layer-1', projectId, boardId: 'board-1', name: 'Act I',
    color: '#fff', visible: true, locked: false, opacity: 1, order: 0,
    createdAt: now, updatedAt: now,
  });
  await db.boardViews.add({
    id: 'board-view-1', projectId, boardId: 'board-1', name: 'Suspects',
    query: 'role:character', layerIds: ['board-layer-1'], mode: 'highlight',
    order: 0, createdAt: now, updatedAt: now,
  });
  await db.annotations.add({
    id: 'annotation-1', projectId, sourceEngineId: 'writings',
    sourceEntityId: 'writing-anchor', anchor: { type: 'entity' }, noteType: 'reference',
    isOrphaned: false, position: 0, createdAt: now, updatedAt: now,
  });
  await db.annotationReferences.add({
    id: 'annotation-ref-1', annotationId: 'annotation-1',
    targetEngineId: 'timeline', targetEntityId: 'event-1', createdAt: now,
  });
  await db.snapshots.add({
    id: 'snapshot-1', projectId, url: 'https://example.com', title: 'Source',
    source: 'url', status: 'success', notes: '', tags: [], preservedAt: now,
    createdAt: now, localMediaPath: `${projectId}/snapshot-1.mp4`,
    downloadState: 'done',
  });
  await db.citations.add({
    id: 'citation-1', projectId, title: 'Source', authors: ['Writer'],
    accessedAt: '2026-07-27', writingIds: [], tags: [], createdAt: now, updatedAt: now,
  });
  await db.publishingProfiles.add({
    id: 'publishing-profile-1', projectId, name: 'Editorial', format: 'manuscript',
    includeTitlePage: true, includeSynopsis: true, includeBibliography: true,
    citationStyle: 'apa', selectionMode: 'selected',
    selectedWritingIds: ['chapter-2', 'chapter-1'],
    writingOrder: ['chapter-2', 'missing-writing', 'chapter-1'],
    createdAt: now, updatedAt: now,
  });
  return ['timeline', 'gallery', 'board', 'annotations', 'scrapper', 'project-tools'];
}

async function testBackupRoundTrip(): Promise<void> {
  const projectId = 'critical-project';
  const projectDir = `projects/Critical__${projectId}`;
  const strategyIds = await seedBackupFixture(projectId);
  const strategies = getAllBackupStrategies().filter(strategy => strategyIds.includes(strategy.engineId));
  assert(strategies.length === strategyIds.length, 'not every critical backup strategy registered');
  const zip = new JSZip();
  for (const strategy of strategies) {
    await strategy.exportProject({ zip, projectId, projectDir });
  }
  const archive = await JSZip.loadAsync(await zip.generateAsync({ type: 'uint8array' }));
  const tables = [...new Set(strategies.flatMap(strategy => strategy.tables))];
  await db.transaction('rw', tables.map(name => db.table(name)), async () => {
    for (const table of tables) await db.table(table).clear();
  });
  for (const strategy of strategies) {
    await strategy.importProject({ zip: archive, projectId, projectDir });
  }
  assert(await db.timelines.get('timeline-1'), 'timeline root did not round-trip');
  assert(await db.timelineEvents.get('event-1'), 'timeline event did not round-trip');
  assert(await db.timelineConnections.get('timeline-link-1'), 'timeline connection did not round-trip');
  assert(await db.imageCollections.get('collection-empty'), 'empty Gallery collection did not round-trip');
  const hyperEdge = await db.boardEdges.get('board-edge-1');
  assert(hyperEdge?.sources.length === 2, 'board hyper-edge did not round-trip with both sources');
  const metaEdge = await db.boardEdges.get('board-edge-2');
  assert(metaEdge?.targets[0]?.on === 'edge', 'board edge-to-edge anchor did not round-trip');
  assert(await db.boardLayers.get('board-layer-1'), 'board layer did not round-trip');
  assert(await db.boardViews.get('board-view-1'), 'board view did not round-trip');
  assert(await db.annotationReferences.get('annotation-ref-1'), 'child-only annotation reference did not round-trip');
  const snapshot = await db.snapshots.get('snapshot-1');
  assert(snapshot && !snapshot.localMediaPath && snapshot.downloadState !== 'done', 'Scrapper restored unavailable external media as available');
  assert(await db.citations.get('citation-1'), 'project tools did not round-trip');
  const publishingProfile = await db.publishingProfiles.get('publishing-profile-1');
  assert(
    publishingProfile?.selectionMode === 'selected'
      && publishingProfile.selectedWritingIds.join(',') === 'chapter-2,chapter-1'
      && publishingProfile.writingOrder?.join(',') === 'chapter-2,missing-writing,chapter-1',
    'publishing profile selection and explicit order did not round-trip',
  );
  passed.push('structured backup round-trip');
}

async function testProjectImportCollisionGuard(): Promise<void> {
  const projectId = 'critical-import-collision';
  const now = Date.now();
  await db.projects.put({
    id: projectId,
    title: 'Incoming archive title',
    mode: 'novelist',
    type: 'standalone',
    color: '#7c3aed',
    description: '',
    status: 'in-progress',
    enabledEngines: [],
    engineOrder: [],
    createdAt: now,
    updatedAt: now,
  });
  stage('collision:createArchive');
  const { blob, fileName } = await createProjectZipArchive(projectId);
  const archive = new File([blob], fileName, { type: 'application/zip' });
  await db.projects.update(projectId, { title: 'Current local title', updatedAt: now + 1 });

  stage('collision:preview');
  const preview = await previewProjectZipImport(archive);
  assert(preview.collisions.length === 1, 'project ZIP collision was not detected');
  assert(
    preview.collisions[0].existingTitle === 'Current local title'
      && preview.collisions[0].incomingTitle === 'Incoming archive title',
    'project ZIP collision preview did not identify both versions',
  );

  stage('collision:blockedImport');
  let blocked = false;
  try {
    await importProjectZip(archive);
  } catch {
    blocked = true;
  }
  assert(blocked, 'unapproved project replacement was allowed');
  assert(
    (await db.projects.get(projectId))?.title === 'Current local title',
    'blocked project import mutated the existing project',
  );

  stage('collision:approvedImport');
  await importProjectZip(archive, { replaceProjectIds: [projectId] });
  assert(
    (await db.projects.get(projectId))?.title === 'Incoming archive title',
    'explicitly approved project replacement did not restore the archive',
  );
  await db.projects.delete(projectId);
  passed.push('project import collision guard + explicit replacement');
}

function testPersistedHtmlSanitizer(): void {
  const hostile = sanitizeRichHtml(`
    <p style="position:fixed" onclick="window.__owned=1">
      Safe <strong>formatting</strong>
      <a href="javascript:alert(1)">bad link</a>
      <img src="data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=" onerror="alert(1)">
      <img src="data:image/png;base64,iVBORw0KGgo=" alt="safe raster">
      <script>window.__owned=2</script><iframe srcdoc="evil"></iframe>
    </p>
  `);
  assert(hostile.includes('<p>') && hostile.includes('<strong>formatting</strong>'), 'safe rich text was removed');
  assert(!/script|iframe|onclick|onerror|style=|javascript:/i.test(hostile), 'active HTML survived sanitization');
  assert(!hostile.includes('image/svg+xml'), 'active SVG data URL survived sanitization');
  assert(hostile.includes('data:image/png;base64,'), 'safe raster data URL was removed');
  passed.push('persisted rich HTML allowlist');
}

async function testPublishingStudioSemantics(): Promise<void> {
  const projectId = 'publishing-project';
  const writing = (value: Partial<Writing> & Pick<Writing, 'id' | 'title'>): Writing => ({
    id: value.id,
    projectId,
    title: value.title,
    status: 'draft',
    content: '<p>Draft content</p>',
    wordCount: 2,
    tags: [],
    createdAt: 1,
    updatedAt: 1,
    ...value,
  });
  const writings = [
    writing({ id: 'chapter-2', title: 'Second', chapter: 2, createdAt: 20 }),
    writing({
      id: 'chapter-1',
      title: 'First',
      chapter: 1,
      createdAt: 10,
      content: '<p>Safe <strong>draft</strong><img src="x" onerror="alert(1)"></p><script>owned()</script>',
      wordCount: 3,
    }),
    writing({ id: 'google-cached', title: 'Cached Doc', chapter: 3, isGoogleDoc: true, content: '<p>Cached text</p>' }),
    writing({ id: 'google-empty', title: 'Empty Doc', chapter: 4, isGoogleDoc: true, content: '<p> </p>', wordCount: 0 }),
    writing({ id: 'foreign', projectId: 'another-project', title: 'Foreign', chapter: 0 }),
  ];
  const baseProfile: PublishingProfile = {
    id: 'profile',
    projectId,
    name: 'Editorial',
    format: 'manuscript',
    includeTitlePage: true,
    includeSynopsis: false,
    includeBibliography: true,
    citationStyle: 'mla',
    selectionMode: 'selected',
    selectedWritingIds: ['chapter-1', 'google-cached'],
    writingOrder: ['google-cached', 'missing-writing', 'chapter-1', 'chapter-2'],
    createdAt: 1,
    updatedAt: 1,
  };

  const selected = resolvePublishingWritings(writings, baseProfile);
  assert(selected.writings.map(item => item.id).join(',') === 'google-cached,chapter-1', 'publishing order or selected-only scope changed');
  assert(selected.missingWritingIds.join(',') === 'missing-writing', 'missing writing references were not reported');
  assert(selected.googleDocsWithoutContent.length === 0, 'cached Google Doc was treated as unavailable');

  const googleBlocked = resolvePublishingWritings(writings, {
    ...baseProfile,
    selectedWritingIds: ['google-empty'],
  });
  assert(googleBlocked.googleDocsWithoutContent[0]?.id === 'google-empty', 'empty Google Doc did not block publishing');

  const explicitEmpty = resolvePublishingWritings(writings, {
    ...baseProfile,
    selectedWritingIds: [],
  });
  assert(explicitEmpty.writings.length === 0, 'new selected-empty profile was interpreted as all writings');

  const legacyAll = normalizePublishingProfile({
    ...baseProfile,
    selectionMode: undefined,
    selectedWritingIds: [],
    writingOrder: undefined,
  });
  assert(legacyAll.selectionMode === 'all', 'legacy empty profile compatibility changed');
  assert(
    resolvePublishingWritings(writings, legacyAll).writings.map(item => item.id).join(',')
      === 'chapter-1,chapter-2,google-cached,google-empty',
    'legacy all-writings profile order changed',
  );

  const citation: Citation = {
    id: 'citation-hostile',
    projectId,
    title: '</p><script>owned()</script>',
    authors: [],
    accessedAt: '2026-08-24',
    writingIds: [],
    tags: [],
    createdAt: 1,
    updatedAt: 1,
  };
  const artifactWritings = selected.writings.filter(item => item.id === 'chapter-1');
  const english = buildPublishingArtifacts(
    { id: projectId, title: 'Project' },
    baseProfile,
    artifactWritings,
    [citation],
    {
      labels: {
        locale: 'en-US', wordLabel: 'words', chapterLabel: 'Chapter', bibliographyTitle: 'Bibliography',
        unknownAuthor: 'Unknown author', noDate: 'n.d.', accessedLabel: 'Accessed',
      },
      generatedAt: Date.UTC(2026, 7, 24),
    },
  );
  const spanish = buildPublishingArtifacts(
    { id: projectId, title: 'Proyecto' },
    baseProfile,
    artifactWritings,
    [citation],
    {
      labels: {
        locale: 'es-ES', wordLabel: 'palabras', chapterLabel: 'Capítulo', bibliographyTitle: 'Bibliografía',
        unknownAuthor: 'Autor desconocido', noDate: 's. f.', accessedLabel: 'Consultado el',
      },
      generatedAt: Date.UTC(2026, 7, 24),
    },
  );
  assert(english.markdown.includes('Chapter 1') && english.markdown.includes('# Bibliography'), 'English publishing labels were not applied');
  assert(spanish.markdown.includes('Capítulo 1') && spanish.markdown.includes('# Bibliografía'), 'Spanish publishing labels were not applied');
  assert(english.markdown.includes('Unknown author') && english.markdown.includes('n.d.') && english.markdown.includes('Accessed'), 'English citation labels were not applied');
  assert(spanish.markdown.includes('Autor desconocido') && spanish.markdown.includes('s. f.') && spanish.markdown.includes('Consultado el'), 'Spanish citation labels were not applied');
  assert(english.html.includes('Bibliography') && spanish.html.includes('Bibliografía'), 'bibliography missing from printable artifact');
  assert(!/<script|onerror=/i.test(`${english.markdown}\n${english.html}`), 'active writing or citation markup survived publishing');
  assert(english.markdown.includes('&lt;/p&gt;'), 'citation markup was not escaped in Markdown');

  assert(english.document.omittedPortableImageCount === 1, 'portable image policy did not report the omitted image');
  assert(!/<img/i.test(english.document.sections[0]?.portableHtml ?? ''), 'portable publishing IR retained an image');
  assert(english.docxFilename === 'Editorial.docx' && english.epubFilename === 'Editorial.epub', 'portable filenames changed');

  const [{ buildPublishingDocx }, { buildPublishingEpub }] = await Promise.all([
    import('@/engines/writings/publishingDocx'),
    import('@/engines/writings/publishingEpub'),
  ]);
  const [docxBlob, epubBlob] = await Promise.all([
    buildPublishingDocx(english.document),
    buildPublishingEpub(english.document),
  ]);

  const docx = await JSZip.loadAsync(await docxBlob.arrayBuffer());
  const docxDocument = await docx.file('word/document.xml')?.async('string');
  assert(Boolean(docx.file('[Content_Types].xml')), 'DOCX is missing its content-types manifest');
  assert(Boolean(docxDocument?.includes('Chapter 1 — First')), 'DOCX lost the ordered section heading');
  assert(Boolean(docxDocument?.includes('Safe')) && Boolean(docxDocument?.includes('draft')), 'DOCX lost manuscript text');
  assert(!/onerror=|javascript:|<script/i.test(docxDocument ?? ''), 'DOCX retained active markup');
  assert(!Object.keys(docx.files).some(path => path.startsWith('word/media/')), 'DOCX embedded an omitted image');

  const epubBytes = new Uint8Array(await epubBlob.arrayBuffer());
  const epubHeader = new DataView(epubBytes.buffer, epubBytes.byteOffset, epubBytes.byteLength);
  const firstFilenameLength = epubHeader.getUint16(26, true);
  const firstFilename = new TextDecoder().decode(epubBytes.slice(30, 30 + firstFilenameLength));
  assert(epubHeader.getUint32(0, true) === 0x04034b50, 'ePub does not begin with a ZIP local header');
  assert(firstFilename === 'mimetype' && epubHeader.getUint16(8, true) === 0, 'ePub mimetype must be the first uncompressed member');
  const epub = await JSZip.loadAsync(epubBytes);
  assert(await epub.file('mimetype')?.async('string') === 'application/epub+zip', 'ePub mimetype is invalid');
  const opf = await epub.file('EPUB/package.opf')?.async('string');
  const chapter = await epub.file('EPUB/section-1.xhtml')?.async('string');
  assert(Boolean(epub.file('META-INF/container.xml')) && Boolean(epub.file('EPUB/nav.xhtml')), 'ePub package metadata is incomplete');
  assert(Boolean(opf?.includes('<itemref idref="section-1" />')), 'ePub spine lost the manuscript order');
  assert(Boolean(chapter?.includes('Chapter 1 — First')) && Boolean(chapter?.includes('<strong>draft</strong>')), 'ePub lost semantic manuscript content');
  assert(!/script|onerror|<img/i.test(chapter ?? ''), 'ePub retained active or image markup');

  passed.push('publishing selection, compatibility, i18n, safe IR, DOCX, and EPUB3');
}

async function testCascades(): Promise<void> {
  const now = Date.now();
  await db.writings.add({
    id: 'writing-delete', projectId: 'critical-project', title: 'Delete me',
    status: 'draft', content: '<p>x</p>', wordCount: 1, tags: [],
    createdAt: now, updatedAt: now,
  });
  await db.writingSnapshots.add({
    id: 'writing-snapshot-delete', writingId: 'writing-delete',
    projectId: 'critical-project', title: 'Delete me', content: '<p>x</p>',
    wordCount: 1, reason: 'manual', createdAt: now,
  });
  await deleteWriting('writing-delete');
  assert(!(await db.writingSnapshots.get('writing-snapshot-delete')), 'writing snapshot cascade failed');

  // Deleting one node must take the relation it was part of *and* the
  // relation anchored on that relation — the transitive case neither legacy
  // engine could even represent.
  await db.boards.add({ id: 'board-delete', projectId: 'critical-project', title: 'Board', surface: 'cork', createdAt: now, updatedAt: now });
  const stub = (id: string, x: number) => ({
    id, projectId: 'critical-project', boardId: 'board-delete', kind: 'card' as const,
    title: id, content: '', color: '#fff', position: { x, y: 0 },
    size: { width: 200, height: 120 }, zIndex: 0, tags: [], createdAt: now, updatedAt: now,
  });
  await db.boardNodes.bulkAdd([stub('node-delete', 0), stub('node-keep', 1), stub('node-third', 2)]);
  await db.boardEdges.bulkAdd([
    {
      id: 'edge-delete', projectId: 'critical-project', boardId: 'board-delete',
      sourceId: 'node-delete', targetId: 'node-keep',
      sources: [{ id: 'node-delete', on: 'node' }], targets: [{ id: 'node-keep', on: 'node' }],
      kind: 'related', color: '#fff', style: 'solid', width: 0, direction: 'none',
      curvature: 'curved', weight: 1, certainty: 1, tags: [], createdAt: now, updatedAt: now,
    },
    {
      id: 'edge-meta', projectId: 'critical-project', boardId: 'board-delete',
      sourceId: 'node-third', targetId: 'edge-delete',
      sources: [{ id: 'node-third', on: 'node' }], targets: [{ id: 'edge-delete', on: 'edge' }],
      kind: 'mystery', color: '#fff', style: 'solid', width: 0, direction: 'forward',
      curvature: 'curved', weight: 1, certainty: 1, tags: [], createdAt: now, updatedAt: now,
    },
    {
      id: 'edge-hyper', projectId: 'critical-project', boardId: 'board-delete',
      sourceId: 'node-delete', targetId: 'node-third',
      sources: [{ id: 'node-delete', on: 'node' }, { id: 'node-keep', on: 'node' }],
      targets: [{ id: 'node-third', on: 'node' }],
      kind: 'causes', color: '#fff', style: 'solid', width: 0, direction: 'forward',
      curvature: 'curved', weight: 1, certainty: 1, tags: [], createdAt: now, updatedAt: now,
    },
  ]);
  await deleteBoardNode('node-delete');
  assert(!(await db.boardEdges.get('edge-delete')), 'board incident-relation cascade failed');
  assert(!(await db.boardEdges.get('edge-meta')), 'board relation-on-relation cascade failed');
  const survivor = await db.boardEdges.get('edge-hyper');
  assert(survivor?.sources.length === 1, 'board hyper-edge kept a deleted endpoint');
  assert(survivor?.sourceId === 'node-keep', 'board hyper-edge did not renormalise its index field');

  // Deleting a project must sweep the copilot tables too — including the one
  // keyed BY projectId, which Dexie keeps out of `idxByName`.
  const { deleteProject } = await import('@/db/operations');
  const doomed = 'critical-project-doomed';
  await db.aiThreads.add({ id: 'ai-thread-doomed', projectId: doomed, title: 'Doomed', policy: 'ask', archived: false, createdAt: now, updatedAt: now });
  await db.aiMessages.add({ id: 'ai-message-doomed', threadId: 'ai-thread-doomed', projectId: doomed, role: 'user', content: 'x', status: 'complete', createdAt: now });
  await db.aiProjectSettings.put({ projectId: doomed, defaultPolicy: 'ask', remoteConsent: false, updatedAt: now });
  await deleteProject(doomed);
  assert(!(await db.aiThreads.get('ai-thread-doomed')), 'project deletion left an AI thread behind');
  assert(!(await db.aiMessages.get('ai-message-doomed')), 'project deletion left an AI message behind');
  assert(!(await db.aiProjectSettings.get(doomed)), 'project deletion left the AI project settings behind');
  passed.push('writing and board cascades, project sweep of copilot tables');
}

// The dock refreshes its message list on every data bump — which the runner
// fires once per streamed token. settleStaleMessages runs on that refresh, so
// if it cancelled *any* streaming row it would cancel the in-flight assistant
// row out from under a live run (the answer would show "cancelled" while
// generating, then snap in at the end). It must only settle orphans — rows with
// no run in flight (a crash or reload). Also guards "one turn at a time".
async function testCopilotRunGuards(): Promise<void> {
  const { settleStaleMessages, addMessage, listMessages } = await import('@/services/copilot/threads');
  const { sendCopilotTurn } = await import('@/services/copilot/runner');
  const { useCopilotStore } = await import('@/stores/copilotStore');
  const now = Date.now();
  const projectId = 'critical-project';
  const threadId = 'copilot-thread-guards';
  await db.aiThreads.add({ id: threadId, projectId, title: 'Guards', policy: 'ask', archived: false, createdAt: now, updatedAt: now });

  const stubRun = (runId: string) => ({
    runId, threadId, projectId,
    handle: { runId, cancel: () => {}, approve: () => {} },
    assistantMessageId: null, buffer: '', reasoning: '',
    startedAt: now, pendingApprovals: [], toolNames: [], chatOnly: false,
  });

  // A live run owns its streaming row: a refresh must NOT cancel it.
  const row = await addMessage({ id: 'copilot-guard-streaming', threadId, projectId, role: 'assistant', content: '', status: 'streaming' });
  useCopilotStore.getState().startRun(stubRun('run-guard-1'));
  await settleStaleMessages(threadId);
  assert((await db.aiMessages.get(row.id))?.status === 'streaming', "settleStaleMessages cancelled a live run's streaming row");

  // One turn at a time: a send is refused while a run is in flight (no dup row).
  const before = (await listMessages(threadId)).length;
  await sendCopilotTurn({
    projectId, threadId, text: 'second turn',
    route: { connectionId: 'x', modelId: 'y' }, policy: 'ask',
    briefing: { projectTitle: 'P', enabledEngines: [], locale: 'es' },
  });
  assert((await listMessages(threadId)).length === before, 'a second turn started while one was already running');

  // Once no run is in flight, an orphaned streaming row IS settled.
  useCopilotStore.getState().endRun(threadId);
  await settleStaleMessages(threadId);
  assert((await db.aiMessages.get(row.id))?.status === 'cancelled', 'settleStaleMessages left an orphaned streaming row unsettled');

  passed.push('copilot run guards: live streaming survives refresh, one turn at a time, orphans settled');
}

// The Escritos→Studio hand-off is a single-slot store the studio drains once.
// It must be one-shot (a second drain gets nothing) and a newer request must
// replace an undrained one (rapid re-selection), or a stale prompt would
// generate unexpectedly on a later studio visit.
async function testImageHandoffStore(): Promise<void> {
  const { useImageHandoffStore } = await import('@/stores/imageHandoffStore');
  const store = () => useImageHandoffStore.getState();
  store().take(); // clear any residue from earlier tests
  assert(store().take() === null, 'hand-off store should be empty once drained');
  store().request({ prompt: 'a red door', autoGenerate: true });
  const first = store().take();
  assert(first?.prompt === 'a red door' && first.autoGenerate === true, 'take() must return the requested hand-off');
  assert(store().take() === null, 'hand-off must be one-shot: a second take() returns null');
  store().request({ prompt: 'A', autoGenerate: false });
  store().request({ prompt: 'B', autoGenerate: true });
  assert(store().take()?.prompt === 'B', 'a newer request must replace an undrained one');
  // A gallery image handed over as an img2img reference travels with no prompt.
  store().request({ prompt: '', autoGenerate: false, initImage: 'data:image/png;base64,AAAA' });
  const reference = store().take();
  assert(reference?.initImage === 'data:image/png;base64,AAAA' && reference.prompt === '', 'a reference hand-off lost its image');
  passed.push('image hand-off store: one-shot take, newer request wins, reference image rides along');
}

function testRecoveryAndNavigation(): void {
  const persisted = {
    id: 'journal-writing',
    projectId: 'critical-project',
    title: 'Persisted',
    content: '<p>old</p>',
  };
  writeWritingRecoveryDraft(
    persisted.projectId,
    persisted.id,
    'Recovered',
    '<p>new</p>',
    persisted.title,
    persisted.content,
  );
  const recovered = readWritingRecoveryDraft(persisted);
  assert(recovered?.title === 'Recovered', 'writing recovery journal did not recover a divergent draft');
  clearWritingRecoveryDraft(persisted.projectId, persisted.id);
  assert(readWritingRecoveryDraft(persisted) === null, 'writing recovery journal did not clear');

  const lateLocal = new Date(2026, 6, 27, 23, 45);
  assert(toLocalDateKey(lateLocal) === '2026-07-27', 'writing stats date key is not local-calendar based');
  window.location.hash = '#/project/project%20with%20spaces/codex';
  assert(getCurrentProjectIdFromUrl() === 'project with spaces', 'HashRouter project navigation parsing failed');
  passed.push('recovery journal, local dates, and hash navigation');
}

function testRecentEntityNavigation(): void {
  let destination: string | null = null;
  installNavigator((path) => {
    destination = path;
  });

  const projectId = 'project with spaces';
  const cases = [
    ['writings', 'writing/1', '/project/project%20with%20spaces/writings?writing=writing%2F1'],
    ['codex', 'entry/1', '/project/project%20with%20spaces/codex?entry=entry%2F1'],
    ['dialog-scene', 'scene/1', '/project/project%20with%20spaces/dialog-scene?entity=scene%2F1'],
    ['notes', 'note/1', '/project/project%20with%20spaces/notes?note=note%2F1'],
    ['scrapper', 'snapshot/1', '/project/project%20with%20spaces/scrapper?entity=snapshot%2F1'],
    ['diary', 'diary/1', '/project/project%20with%20spaces/diary?entity=diary%2F1'],
  ] as const;

  for (const [engineId, entityId, expected] of cases) {
    destination = null;
    const adapter = getAnchorAdapter(engineId);
    assert(adapter, `recent-work engine ${engineId} has no entity navigator`);
    adapter.navigateToEntity(entityId, projectId);
    assert(destination === expected, `${engineId} recent-work navigation lost its exact entity`);
  }

  passed.push('recent-work exact entity navigation');
}

async function testScriptImportRoundTrip(): Promise<void> {
  const { buildFountain } = await import('@/engines/dialog-scene/fountainExport');
  const { parseFountain } = await import('@/engines/dialog-scene/fountainImport');
  const { parseFdx } = await import('@/engines/dialog-scene/fdxImport');
  const { importScript, stripContD, castKeyOf } = await import('@/engines/dialog-scene/importPersist');

  // ── Cue helpers ──
  assert(stripContD("EMISORA (V.O.) (CONT'D)") === 'EMISORA (V.O.)', 'stripContD kept the pagination artifact');
  assert(castKeyOf('EMISORA (V.O.)') === 'EMISORA', 'castKeyOf did not strip the extension');

  // ── Fountain: export → import round trip ──
  const projectId = 'script-import-rt';
  const now = Date.now();
  const mkScene = (id: string, order: number, extra: Partial<Scene>): Scene => ({
    id, projectId, title: '', order, tags: [], createdAt: now, updatedAt: now, ...extra,
  });
  const mkBlock = (id: string, sceneId: string, order: number, extra: Partial<DialogBlock>): DialogBlock => ({
    id, sceneId, projectId, type: 'action', characterName: '', characterColor: '',
    content: '', order, createdAt: now, updatedAt: now, ...extra,
  });
  const scenes: Scene[] = [
    mkScene('s1', 0, { title: 'Bar', setting: 'INT. BAR - NIGHT', sceneNumber: 3 }),
    mkScene('s2', 1, { title: 'Callejón', isOmitted: true }),
    mkScene('s3', 2, { title: 'La azotea', description: 'Amanece.' }),
  ];
  const blocks: DialogBlock[] = [
    mkBlock('b1', 's1', 0, { content: 'La barra está vacía.' }),
    mkBlock('b2', 's1', 1, { type: 'dialog', characterName: 'Alice', characterColor: '#fff', parenthetical: 'susurra', content: 'Hola.' }),
    mkBlock('b3', 's1', 2, { type: 'dialog', characterName: 'Bob', characterColor: '#fff', content: 'Ahora.', dualGroupId: 'dual_x' }),
    mkBlock('b4', 's1', 3, { type: 'dialog', characterName: 'Carla', characterColor: '#fff', content: 'Nunca.', dualGroupId: 'dual_x' }),
    mkBlock('b5', 's1', 4, { type: 'stage-direction', content: 'Se apagan las luces' }),
    mkBlock('b6', 's1', 5, { type: 'transition', content: 'CUT TO:' }),
    mkBlock('b7', 's1', 6, { type: 'note', content: 'Nota del director' }),
    mkBlock('b8', 's1', 7, { type: 'slug', content: 'Más tarde' }),
    mkBlock('b9', 's3', 0, { type: 'dialog', characterName: 'EMISORA (V.O.)', characterColor: '#fff', content: 'Buenos días.' }),
  ];
  const fountainText = buildFountain({ projectTitle: 'RT', scenes, blocks });
  const parsed = parseFountain(fountainText, { preambleTitle: 'Apertura' });

  // The exported mid-scene slug re-imports as a scene boundary — documented loss.
  assert(parsed.scenes.length === 4, `expected 4 scenes after round trip, got ${parsed.scenes.length}`);
  const [rt1, rtSlug, rtOmitted, rt3] = parsed.scenes;
  assert(rt1.title === 'INT. BAR - NIGHT' && rt1.sceneNumber === 3, 'heading title/number did not survive');
  assert(rt1.blocks.length === 7, `expected 7 blocks in scene 1, got ${rt1.blocks.length}`);
  assert(rt1.blocks[0].type === 'action' && rt1.blocks[0].content === 'La barra está vacía.', 'action lost');
  assert(rt1.blocks[1].type === 'dialog' && rt1.blocks[1].characterName === 'ALICE'
    && rt1.blocks[1].parenthetical === 'susurra' && rt1.blocks[1].content === 'Hola.', 'dialog+parenthetical lost');
  assert(rt1.blocks[2].type === 'dialog' && rt1.blocks[3].type === 'dialog'
    && rt1.blocks[2].dualGroup !== undefined && rt1.blocks[2].dualGroup === rt1.blocks[3].dualGroup,
    'dual pairing lost');
  assert(rt1.blocks[4].type === 'stage-direction' && rt1.blocks[4].content === 'Se apagan las luces', 'stage-direction lost');
  assert(rt1.blocks[5].type === 'transition' && rt1.blocks[5].content === 'CUT TO:', 'transition lost');
  assert(rt1.blocks[6].type === 'note' && rt1.blocks[6].content === 'Nota del director', 'note lost');
  assert(rtSlug.title === 'MÁS TARDE' && rtSlug.blocks.length === 0, 'slug boundary scene wrong');
  assert(rtOmitted.title === 'CALLEJÓN' && rtOmitted.isOmitted === true, 'omitted scene lost');
  assert(rt3.blocks[0]?.type === 'action' && rt3.blocks[0]?.content === 'Amanece.', 'description-as-action lost');
  const emisora = rt3.blocks[1];
  assert(emisora?.type === 'dialog' && emisora.characterName === 'EMISORA (V.O.)' && emisora.castKey === 'EMISORA',
    'V.O. cue handling wrong');

  // ── FDX ──
  const fdx = `<?xml version="1.0" encoding="UTF-8"?>
<FinalDraft DocumentType="Script" Template="No" Version="5">
  <Content>
    <Paragraph Type="Scene Heading" Number="7"><Text>INT. COCINA - DIA</Text></Paragraph>
    <Paragraph Type="Action"><Text>Huele a </Text><Text>café.</Text></Paragraph>
    <Paragraph Type="Character"><Text>MARTA (CONT'D)</Text></Paragraph>
    <Paragraph Type="Parenthetical"><Text>(seca)</Text></Paragraph>
    <Paragraph Type="Dialogue"><Text>No empieces.</Text></Paragraph>
    <Paragraph Type="Dialogue"><Text>Otra vez no.</Text></Paragraph>
    <Paragraph Type="Transition"><Text>CORTE A:</Text></Paragraph>
    <Paragraph Type="Shot"><Text>DETALLE DEL RELOJ</Text></Paragraph>
  </Content>
</FinalDraft>`;
  const fdxParsed = parseFdx(fdx, { preambleTitle: 'Apertura' });
  assert(fdxParsed.scenes.length === 1, 'fdx scene count wrong');
  const fs1 = fdxParsed.scenes[0];
  assert(fs1.title === 'INT. COCINA - DIA' && fs1.sceneNumber === 7, 'fdx heading wrong');
  assert(fs1.blocks[0].type === 'action' && fs1.blocks[0].content === 'Huele a café.', 'fdx text runs not joined');
  assert(fs1.blocks[1].type === 'dialog' && fs1.blocks[1].characterName === 'MARTA'
    && fs1.blocks[1].parenthetical === 'seca' && fs1.blocks[1].content === 'No empieces.\nOtra vez no.',
    'fdx dialogue merge wrong');
  assert(fs1.blocks[2].type === 'transition' && fs1.blocks[3].type === 'slug', 'fdx transition/shot mapping wrong');

  // ── Persistence: append-only rows, locked numbers, codex stamping ──
  await db.codexEntries.add({
    id: 'codex-marta', projectId, type: 'character', title: 'Marta',
    fields: {}, content: '', tags: [], relations: [], createdAt: now, updatedAt: now,
  });
  const result = await importScript(projectId, fdxParsed);
  assert(result.sceneCount === 1 && result.blockCount === 4, 'importScript counts wrong');
  const storedScenes = await db.scenes.where('projectId').equals(projectId).toArray();
  assert(storedScenes.length === 1 && storedScenes[0].sceneNumber === 7 && storedScenes[0].isLocked === true,
    'imported numbered scene must be locked');
  const storedCast = await db.sceneCasts.where('sceneId').equals(storedScenes[0].id).toArray();
  assert(storedCast.length === 1 && storedCast[0].characterName === 'MARTA'
    && storedCast[0].characterId === 'codex-marta', 'cast row / codex stamping wrong');
  const storedBlocks = await db.dialogBlocks.where('projectId').equals(projectId).toArray();
  const martaBlock = storedBlocks.find((b) => b.type === 'dialog');
  assert(martaBlock?.characterId === 'codex-marta', 'dialog block missing stamped characterId');

  // Clean up the fixture rows so later suites see an untouched project set.
  await db.transaction('rw', db.scenes, db.dialogBlocks, db.sceneCasts, db.codexEntries, async () => {
    const sceneIds = storedScenes.map((s) => s.id);
    await db.dialogBlocks.where('projectId').equals(projectId).delete();
    await db.sceneCasts.where('sceneId').anyOf(sceneIds).delete();
    await db.scenes.where('projectId').equals(projectId).delete();
    await db.codexEntries.delete('codex-marta');
  });

  passed.push('Fountain/FDX import round trip + persistence');
}

async function testAiTextParsing(): Promise<void> {
  const { sanitizeModelText, parseJsonFromModel } = await import('@/services/aiText');

  // Reasoning-block hygiene: paired, truncated-open, and orphan-close shapes.
  assert(sanitizeModelText('<think>razono un rato</think>\nHola') === 'Hola', 'paired think block not stripped');
  assert(sanitizeModelText('Antes<think>truncado sin cierre…') === 'Antes', 'unclosed think block not truncated');
  assert(sanitizeModelText('razonamiento suelto…</think>Respuesta') === 'Respuesta', 'orphan think closer not handled');
  assert(sanitizeModelText('sin nada raro') === 'sin nada raro', 'plain text mangled');

  // JSON extraction: plain, fenced-with-preamble, bracket-slice, think+fence.
  const plain = parseJsonFromModel<number[]>('[1,2]');
  assert(Array.isArray(plain) && plain.length === 2 && plain[1] === 2, 'plain JSON array failed');
  const fenced = parseJsonFromModel<Array<{ a: number }>>('Claro, aquí tienes:\n```json\n[{"a":1}]\n```');
  assert(fenced.length === 1 && fenced[0].a === 1, 'fenced JSON with preamble failed');
  const sliced = parseJsonFromModel<{ a: number[] }>('El resultado es {"a":[1]} — espero que sirva.');
  assert(sliced.a.length === 1 && sliced.a[0] === 1, 'bracket-slice extraction failed');
  const combo = parseJsonFromModel<string[]>('<think>pienso</think>\n```\n["x"]\n```\nListo.');
  assert(combo.length === 1 && combo[0] === 'x', 'think+fence combination failed');

  // The safeAiCall contract: unparseable output throws a SyntaxError.
  let threw: unknown = null;
  try {
    parseJsonFromModel('sin json aquí');
  } catch (err) {
    threw = err;
  }
  assert(threw instanceof SyntaxError, 'non-JSON output must throw SyntaxError');

  passed.push('AI model-output sanitizer and JSON extraction');
}

function testProjectIntelligenceSemantics(): void {
  assert(calculateCoverage(0, 0) === null, 'empty coverage must be not applicable');
  assert(calculateCoverage(0, 4) === 0, 'zero coverage with eligible items must remain zero');
  assert(calculateCoverage(3, 4) === 75, 'coverage percentage calculation changed');
  assert(
    deriveProjectHealthStatus(0, 0) === 'not-applicable',
    'an empty project must not be presented as clean',
  );
  assert(deriveProjectHealthStatus(0, 1) === 'clean', 'assessed content without issues must be clean');
  assert(deriveProjectHealthStatus(1, 0) === 'issues', 'detected issues must take precedence over emptiness');
  passed.push('empty-project intelligence semantics');
}

function testNarrativeContinuitySemantics(): void {
  const continuity = deriveNarrativeContinuity(
    [
      { id: 'beat-unlinked', storyPosition: 10 },
      { id: 'beat-writing', storyPosition: 20, linkedWritingId: 'writing-valid' },
      { id: 'beat-scene', storyPosition: 30, linkedSceneId: 'scene-valid' },
      { id: 'beat-stale', storyPosition: 40, linkedWritingId: 'writing-missing' },
      { id: 'beat-payoff', storyPosition: 50, linkedWritingId: 'writing-valid' },
      { id: 'beat-setup', storyPosition: 70, linkedWritingId: 'writing-valid' },
    ],
    [
      { id: 'seed-unpaid', title: 'Unpaid', status: 'planted', linkedBeatId: 'beat-unlinked' },
      { id: 'seed-cut', title: 'Cut', status: 'cut' },
      { id: 'seed-early', title: 'Early', status: 'paid', linkedBeatId: 'beat-setup' },
      { id: 'seed-equal', title: 'Equal', status: 'paid', plantedAt: 50 },
      { id: 'seed-unknown', title: 'Unknown', status: 'paid' },
    ],
    [
      { id: 'payoff-early', seedId: 'seed-early', title: 'Too soon', linkedBeatId: 'beat-payoff' },
      { id: 'payoff-equal', seedId: 'seed-equal', title: 'Same position', paidAt: 50 },
      { id: 'payoff-unknown', seedId: 'seed-unknown', title: 'Unknown position' },
    ],
    new Set(['writing-valid']),
    new Set(['scene-valid']),
  );

  assert(continuity.counts['unlinked-beat'] === 2, 'continuity must flag empty and stale beat links');
  assert(continuity.counts['unpaid-seed'] === 1, 'continuity must ignore cut seeds and count unpaid active seeds');
  assert(continuity.counts['payoff-before-setup'] === 1, 'continuity must only flag a strictly early known payoff');
  assert(
    continuity.signals.map(signal => signal.id).join(',')
      === 'unlinked-beat:beat-unlinked,unlinked-beat:beat-stale,unpaid-seed:seed-unpaid,payoff-before-setup:payoff-early',
    'continuity signal order or stable identifiers changed',
  );
  passed.push('deterministic narrative continuity signals');
}

function testLightweightWorldgenRenameReader(): void {
  const legacy = readWorldRenameEdits(JSON.stringify([
    { kind: 'rename', key: 'city:1', name: 'Aster' },
    { kind: 'paint', key: 'ignored', name: 'Ignored' },
  ]));
  const current = readWorldRenameEdits(JSON.stringify({ version: 2, edits: [
    { kind: 'rename', key: 'realm:1', name: 'Northreach' },
  ] }));
  assert(legacy.length === 1 && legacy[0].name === 'Aster', 'legacy Worldgen rename edits changed');
  assert(current.length === 1 && current[0].key === 'realm:1', 'current Worldgen rename envelope changed');
  assert(readWorldRenameEdits('{broken').length === 0, 'malformed Worldgen edits must fail closed');
  passed.push('lightweight Worldgen rename reader compatibility');
}

async function testOutlineBeatDeepLink(): Promise<void> {
  const projectId = 'outline-link-project';
  await db.outlines.add({
    id: 'outline/deep', projectId, title: 'Deep outline', createdAt: 1, updatedAt: 1,
  });
  await db.outlineBeats.add({
    id: 'beat/deep', outlineId: 'outline/deep', projectId, order: 0, level: 'beat',
    title: 'Exact beat', description: '', status: 'outlined', createdAt: 1, updatedAt: 1,
  });

  let destination: string | null = null;
  installNavigator(path => { destination = path; });
  getAnchorAdapter('outline')?.navigateToEntity('beat/deep', projectId);
  for (let attempt = 0; attempt < 20 && !destination; attempt += 1) {
    await new Promise(resolve => window.setTimeout(resolve, 5));
  }
  assert(
    destination === '/project/outline-link-project/outline?outline=outline%2Fdeep&beat=beat%2Fdeep',
    'outline beat navigation did not preserve the exact outline and beat',
  );
  await db.outlineBeats.delete('beat/deep');
  await db.outlines.delete('outline/deep');
  passed.push('outline exact beat deep-link navigation');
}

function testEditorialNavigationContracts(): void {
  const cockpitTabs = COCKPIT_GROUPS.flatMap(group => group.tabs);
  assert(cockpitTabs.length === 11, 'Cockpit grouping lost a project view');
  assert(new Set(cockpitTabs).size === cockpitTabs.length, 'Cockpit grouping duplicated a project view');
  assert(resolveCockpitTab('research') === 'research', 'valid Cockpit panel did not survive URL resolution');
  assert(resolveCockpitTab('unknown') === 'overview', 'unknown Cockpit panel did not fall back to overview');
  assert(getCockpitGroup('publishing').id === 'prepare', 'publishing left the prepare workflow');

  const actions = buildCommandCenterActions({
    id: 'project with spaces',
    enabledEngines: ['codex', 'writings', 'codex'],
    engineOrder: ['writings', 'disabled', 'codex'],
  });
  const target = (id: string) => actions.find(action => action.id === id)?.target;
  assert(target('review') === '/project/project%20with%20spaces/overview?panel=health', 'review command lost its Cockpit panel');
  assert(target('edit') === '/project/project%20with%20spaces/overview?edit=1', 'edit command lost its modal request');
  assert(target('publishing') === '/project/project%20with%20spaces/overview?panel=publishing', 'publishing command lost its studio route');
  assert(target('manage') === '/project/project%20with%20spaces/overview?manage=1', 'manage command lost its modal request');
  assert(
    actions.filter(action => action.engineId).map(action => action.engineId).join(',') === 'writings,codex',
    'command center engine order or deduplication changed',
  );
  assert(
    filterCommandCenterActions(actions, 'publicacion', action => (
      action.id === 'publishing' ? 'Preparar publicación' : action.id
    )).some(action => action.id === 'publishing'),
    'command filtering stopped being accent-insensitive',
  );
  assert(moveCommandCenterSelection(0, 4, -1) === 3, 'command selection no longer wraps upward');
  assert(moveCommandCenterSelection(3, 4, 1) === 0, 'command selection no longer wraps downward');
  assert(
    commandCenterSearchKey({ type: 'entity', id: 'same', projectId: 'a', engineId: 'notes' })
      !== commandCenterSearchKey({ type: 'entity', id: 'same', projectId: 'b', engineId: 'notes' }),
    'command search identity no longer includes the owning project',
  );
  passed.push('Cockpit workflow and command-center navigation contracts');
}

// A reorder is a partial statement about a scope, never a complete one: the
// client sends the ids IT rendered. A row created after that render — by the
// AI bridge, by another window — is in the scope but not in the list, and it
// must keep the order it already has.
//
// Old bug: `orderedIds.indexOf(item.id)` answered -1 for exactly that row, so
// it was stamped with order -1 and jumped to the head of the list.
async function testReorderKeepsUnlistedRows(): Promise<void> {
  const { reorderItems } = await import('@/engines/_shared/reorderItems');
  const projectId = 'reorder-scope-project';
  const outlineId = 'reorder-scope-outline';
  const beat = (id: string, order: number) => ({
    id, outlineId, projectId, order, level: 'beat' as const,
    title: id, description: '', status: 'outlined' as const,
    createdAt: 1, updatedAt: 1,
  });
  await db.outlines.add({ id: outlineId, projectId, title: 'Reorder scope', createdAt: 1, updatedAt: 1 });
  await db.outlineBeats.bulkAdd([
    beat('reorder-listed-a', 0),
    beat('reorder-unlisted', 5),
    beat('reorder-listed-c', 2),
  ]);

  await reorderItems('outlineBeats', 'outlineId', outlineId, ['reorder-listed-c', 'reorder-listed-a']);

  const [first, second, unlisted] = await Promise.all([
    db.outlineBeats.get('reorder-listed-c'),
    db.outlineBeats.get('reorder-listed-a'),
    db.outlineBeats.get('reorder-unlisted'),
  ]);
  assert(first?.order === 0 && second?.order === 1, 'reorderItems did not apply the order the caller sent');
  assert(
    unlisted?.order === 5,
    `a row absent from the ordered list was restamped to order ${String(unlisted?.order)}`,
  );
  assert(unlisted?.updatedAt === 1, 'a row absent from the ordered list was rewritten at all');

  await db.outlineBeats.bulkDelete(['reorder-listed-a', 'reorder-unlisted', 'reorder-listed-c']);
  await db.outlines.delete(outlineId);
  passed.push('reorder leaves rows outside the ordered list at their existing order');
}

// A margin note anchored on an entity is pure link: when the entity goes, the
// note has nothing left to point at, so it goes too — with its reference row.
// A beat is the author's own text and survives, unlinked.
//
// Old bug: `deleteWriting` took only the snapshots, so every note anchored on
// the chapter stayed behind (unreachable, still counted, still in the backup)
// and `outlineBeats.linkedWritingId` kept pointing at a dead id. `deleteScene`
// had the same hole on the annotation side.
async function testEntityAnnotationCascades(): Promise<void> {
  const { deleteScene } = await import('@/engines/dialog-scene/operations');
  const projectId = 'annotation-cascade-project';
  const now = Date.now();
  const note = (id: string, sourceEngineId: string, sourceEntityId: string) => ({
    id, projectId, sourceEngineId, sourceEntityId,
    anchor: { type: 'entity' as const }, noteType: 'reference' as const,
    isOrphaned: false, position: 0, createdAt: now, updatedAt: now,
  });
  const reference = (id: string, annotationId: string) => ({
    id, annotationId, targetEngineId: 'codex', targetEntityId: 'codex-target', createdAt: now,
  });
  const beat = (id: string, link: { linkedWritingId?: string; linkedSceneId?: string }) => ({
    id, outlineId: 'cascade-outline', projectId, order: 0, level: 'beat' as const,
    title: id, description: '', status: 'outlined' as const,
    createdAt: now, updatedAt: now, ...link,
  });

  await db.outlines.add({ id: 'cascade-outline', projectId, title: 'Cascade', createdAt: now, updatedAt: now });
  await db.writings.bulkAdd([
    { id: 'cascade-writing', projectId, title: 'Doomed chapter', status: 'draft', content: '<p>x</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now },
    { id: 'cascade-writing-keep', projectId, title: 'Innocent chapter', status: 'draft', content: '<p>y</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now },
  ]);
  await db.scenes.bulkAdd([
    { id: 'cascade-scene', projectId, title: 'Doomed scene', order: 0, tags: [], createdAt: now, updatedAt: now },
    { id: 'cascade-scene-keep', projectId, title: 'Innocent scene', order: 1, tags: [], createdAt: now, updatedAt: now },
  ]);
  await db.annotations.bulkAdd([
    note('cascade-note-writing', 'writings', 'cascade-writing'),
    note('cascade-note-writing-keep', 'writings', 'cascade-writing-keep'),
    note('cascade-note-scene', 'dialog-scene', 'cascade-scene'),
    note('cascade-note-scene-keep', 'dialog-scene', 'cascade-scene-keep'),
  ]);
  await db.annotationReferences.bulkAdd([
    reference('cascade-ref-writing', 'cascade-note-writing'),
    reference('cascade-ref-writing-keep', 'cascade-note-writing-keep'),
    reference('cascade-ref-scene', 'cascade-note-scene'),
    reference('cascade-ref-scene-keep', 'cascade-note-scene-keep'),
  ]);
  await db.outlineBeats.bulkAdd([
    beat('cascade-beat-writing', { linkedWritingId: 'cascade-writing' }),
    beat('cascade-beat-writing-keep', { linkedWritingId: 'cascade-writing-keep' }),
    beat('cascade-beat-scene', { linkedSceneId: 'cascade-scene' }),
    beat('cascade-beat-scene-keep', { linkedSceneId: 'cascade-scene-keep' }),
  ]);

  await deleteWriting('cascade-writing');
  assert(!(await db.annotations.get('cascade-note-writing')), 'deleting a writing left its margin note behind');
  assert(!(await db.annotationReferences.get('cascade-ref-writing')), 'deleting a writing left an orphan annotation reference');
  assert(await db.annotations.get('cascade-note-writing-keep'), 'deleting a writing swept another writing’s note');
  assert(await db.annotationReferences.get('cascade-ref-writing-keep'), 'deleting a writing swept another writing’s reference');
  assert(
    (await db.outlineBeats.get('cascade-beat-writing'))?.linkedWritingId === undefined,
    'deleting a writing left an outline beat pointing at a dead id',
  );
  assert(
    (await db.outlineBeats.get('cascade-beat-writing-keep'))?.linkedWritingId === 'cascade-writing-keep',
    'deleting a writing unlinked a beat that pointed somewhere else',
  );

  await deleteScene('cascade-scene');
  assert(!(await db.annotations.get('cascade-note-scene')), 'deleting a scene left its margin note behind');
  assert(!(await db.annotationReferences.get('cascade-ref-scene')), 'deleting a scene left an orphan annotation reference');
  assert(await db.annotations.get('cascade-note-scene-keep'), 'deleting a scene swept another scene’s note');
  assert(
    (await db.outlineBeats.get('cascade-beat-scene'))?.linkedSceneId === undefined,
    'deleting a scene left an outline beat pointing at a dead id',
  );
  assert(
    (await db.outlineBeats.get('cascade-beat-scene-keep'))?.linkedSceneId === 'cascade-scene-keep',
    'deleting a scene unlinked a beat that pointed somewhere else',
  );

  await db.annotations.bulkDelete(['cascade-note-writing-keep', 'cascade-note-scene-keep']);
  await db.annotationReferences.bulkDelete(['cascade-ref-writing-keep', 'cascade-ref-scene-keep']);
  await db.outlineBeats.bulkDelete([
    'cascade-beat-writing', 'cascade-beat-writing-keep', 'cascade-beat-scene', 'cascade-beat-scene-keep',
  ]);
  await db.scenes.bulkDelete(['cascade-scene-keep']);
  await db.writings.bulkDelete(['cascade-writing-keep']);
  await db.outlines.delete('cascade-outline');
  passed.push('writing and scene deletion cascades to margin notes and unlinks outline beats');
}

// The Cockpit's "outline beats connected" gauge counted a beat as connected on
// the mere presence of `linkedWritingId`, without checking the writing still
// existed — so a beat holding a stale pointer (a row deleted by an older build,
// or restored from an archive taken by one) kept the coverage up for ever and
// the gauge could only rise. The row is deleted here WITHOUT the engine's own
// unlink precisely to reproduce that stale pointer.
async function testOutlineCoverageIgnoresDeletedWritings(): Promise<void> {
  const projectId = 'outline-coverage-project';
  const now = Date.now();
  await db.projects.put({
    id: projectId, title: 'Coverage', mode: 'novelist', type: 'standalone',
    color: '#7c3aed', description: '', status: 'in-progress',
    enabledEngines: [], engineOrder: [], createdAt: now, updatedAt: now,
  });
  await db.outlines.add({ id: 'coverage-outline', projectId, title: 'Spine', createdAt: now, updatedAt: now });
  await db.writings.bulkAdd([
    { id: 'coverage-writing-1', projectId, title: 'One', status: 'draft', content: '<p>a</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now },
    { id: 'coverage-writing-2', projectId, title: 'Two', status: 'draft', content: '<p>b</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now },
  ]);
  await db.outlineBeats.bulkAdd([
    { id: 'coverage-beat-1', outlineId: 'coverage-outline', projectId, order: 0, level: 'beat', title: 'B1', description: '', status: 'outlined', linkedWritingId: 'coverage-writing-1', createdAt: now, updatedAt: now },
    { id: 'coverage-beat-2', outlineId: 'coverage-outline', projectId, order: 1, level: 'beat', title: 'B2', description: '', status: 'outlined', linkedWritingId: 'coverage-writing-2', createdAt: now, updatedAt: now },
  ]);

  const before = await loadProjectCockpit(projectId);
  assert(before.intelligence.outlineCoverage === 100, 'two linked beats out of two must read as full coverage');

  await db.writings.delete('coverage-writing-1');

  const after = await loadProjectCockpit(projectId);
  assert(
    after.intelligence.outlineCoverage === 50,
    `outline coverage must drop when a linked chapter is gone, got ${String(after.intelligence.outlineCoverage)}`,
  );
  assert(
    after.health.find(row => row.id === 'broken-spine-links')?.count === 1,
    'the dead beat link was not reported as a broken narrative link',
  );

  await db.outlineBeats.bulkDelete(['coverage-beat-1', 'coverage-beat-2']);
  await db.writings.delete('coverage-writing-2');
  await db.outlines.delete('coverage-outline');
  await db.projects.delete(projectId);
  passed.push('outline coverage stops counting beats whose writing is gone');
}

// A citation records the day the author consulted the source, and that is a
// calendar day on their wall — not a UTC one. Old bug: the accessed date was
// derived through `toISOString()`, so a snapshot preserved late in the evening
// (or early in the morning, on the other side of UTC) was filed under the
// neighbouring day and `formatCitation` then printed a date the author never
// saw. Both edges of the local day are checked so any non-zero UTC offset in
// the harness reproduces it.
async function testCitationAccessedDayIsLocal(): Promise<void> {
  const projectId = 'citation-date-project';
  const cases = [
    { id: 'citation-snapshot-early', preservedAt: new Date(2026, 6, 27, 0, 30).getTime() },
    { id: 'citation-snapshot-late', preservedAt: new Date(2026, 6, 27, 23, 30).getTime() },
  ];
  const citationIds: string[] = [];
  for (const { id, preservedAt } of cases) {
    await db.snapshots.add({
      id, projectId, url: 'https://example.com/article', title: 'Article',
      source: 'url', status: 'success', notes: '', tags: [],
      preservedAt, createdAt: preservedAt,
    });
    const citation = await citationFromSnapshot(id);
    citationIds.push(citation.id);
    assert(
      citation.accessedAt === toLocalDateKey(new Date(preservedAt)),
      `accessedAt ${String(citation.accessedAt)} is not the local calendar day of the snapshot`,
    );
    assert(citation.accessedAt === '2026-07-27', 'the local calendar day of the fixture drifted');
    const stored = await db.citations.get(citation.id);
    assert(stored?.accessedAt === citation.accessedAt, 'the citation was stored with a different accessed date');
    // The round trip that the reader actually sees: the stored key is parsed
    // back as a local date, so it must render as the day of the snapshot.
    assert(
      formatCitation(citation, 'mla').includes(new Date(preservedAt).toLocaleDateString('en-US')),
      'the formatted citation shows a different day than the snapshot was preserved on',
    );
  }
  await db.citations.bulkDelete(citationIds);
  await db.snapshots.bulkDelete(cases.map(row => row.id));
  passed.push('citation accessed date is the local day of the snapshot and round-trips');
}

// One row, two owners: the Image Studio writes `imageRoute`, the copilot dock
// writes `chatRoute`, `defaultPolicy` and `remoteConsent`. Old bug: the save
// read the whole row, merged, and put it back outside a transaction, so the
// later of two saves reverted the other's field — and a partial save could
// resurrect stale values it had read before.
async function testCopilotSettingsPartialSaves(): Promise<void> {
  const { getProjectSettings, saveProjectSettings } = await import('@/services/copilot/threads');
  const projectId = 'copilot-settings-project';
  await db.aiProjectSettings.delete(projectId);

  // First save creates the row; a partial save must then leave the rest alone.
  await saveProjectSettings(projectId, { defaultPolicy: 'allow', remoteConsent: true });
  await saveProjectSettings(projectId, { chatRoute: { connectionId: 'c0', modelId: 'm0' } });
  let settings = await getProjectSettings(projectId);
  assert(settings.defaultPolicy === 'allow', 'a partial save cleared the policy it never mentioned');
  assert(settings.remoteConsent === true, 'a partial save cleared the remote consent it never mentioned');
  assert(settings.chatRoute?.modelId === 'm0', 'a partial save did not persist its own field');

  // Two saves of DIFFERENT fields, in flight at the same time: both survive.
  await Promise.all([
    saveProjectSettings(projectId, { chatRoute: { connectionId: 'chat', modelId: 'chat-model' } }),
    saveProjectSettings(projectId, { imageRoute: { connectionId: 'image', modelId: 'image-model' } }),
  ]);
  settings = await getProjectSettings(projectId);
  assert(settings.chatRoute?.modelId === 'chat-model', 'a concurrent save reverted the chat route');
  assert(settings.imageRoute?.modelId === 'image-model', 'a concurrent save reverted the image route');
  assert(
    settings.defaultPolicy === 'allow' && settings.remoteConsent === true,
    'concurrent partial saves reverted a field neither of them mentioned',
  );

  await db.aiProjectSettings.delete(projectId);
  passed.push('copilot project settings survive partial and concurrent saves');
}

// The legacy `fullExport: true` JSON only ever carried sixteen tables. Old bug:
// the restore cleared the WHOLE database first, so importing one of those files
// silently destroyed every engine added since — diary, notes, outline, seeds —
// with nothing in the payload to put back. It is a partial restore, and only
// the tables the payload actually carries may be replaced.
async function testLegacyFullImportKeepsTablesItDoesNotCarry(): Promise<void> {
  const { importFullDatabase } = await import('@/db/operations');
  const projectId = 'legacy-import-project';
  const now = Date.now();
  await db.diaryEntries.put({
    id: 'legacy-diary', projectId, entryDate: '2026-07-27T10:00', title: 'Survivor',
    content: '<p>still here</p>', tags: [], pinned: false, createdAt: now, updatedAt: now,
  });
  await db.writings.put({
    id: 'legacy-writing-old', projectId, title: 'Replaced', status: 'draft',
    content: '<p>old</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now,
  });

  await importFullDatabase({
    version: 1,
    fullExport: true,
    exportedAt: now,
    writings: [{
      id: 'legacy-writing-new', projectId, title: 'Restored', status: 'draft',
      content: '<p>new</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now,
    }],
  } as unknown as Parameters<typeof importFullDatabase>[0]);

  assert(
    (await db.diaryEntries.get('legacy-diary'))?.title === 'Survivor',
    'a legacy import cleared a table its payload cannot restore',
  );
  assert(
    !(await db.writings.get('legacy-writing-old')),
    'a legacy import did not replace the table its payload does carry',
  );
  assert(
    (await db.writings.get('legacy-writing-new'))?.title === 'Restored',
    'a legacy import did not load the rows it carried',
  );

  await db.diaryEntries.delete('legacy-diary');
  await db.writings.delete('legacy-writing-new');
  passed.push('legacy full-export import only replaces the tables it carries');
}


// A delete has to be takeable back WHOLE: the chapter, its entire version
// history, the margin notes anchored on it, and the outline beats it was
// linked to. `writingSnapshots` is never pruned, so losing that history with
// the row loses the only durable copy of everything the chapter used to say.
//
// The bundle slot is armed BY ID. Old bug: it was a single unnamed slot, so
// `takeLastDeletedWriting()` handed back whatever the LAST delete had produced
// — a delete landing between the writer's own delete and the Undo bar picking
// its bundle up (the AI bridge answering a client, another window) meant the
// Undo bar restored a chapter into a different project. Now asking for one id
// can only ever yield that id's bundle, or nothing.
async function testWritingDeleteIsRestorable(): Promise<void> {
  const projectId = 'writing-undo-project';
  const otherProjectId = 'writing-undo-other-project';
  const writingId = 'undo-writing';
  const otherWritingId = 'undo-other-writing';
  const now = Date.now();

  await db.writings.bulkAdd([
    { id: writingId, projectId, title: 'Doomed chapter', status: 'draft', content: '<p>La torre negra</p>', wordCount: 3, tags: [], createdAt: now, updatedAt: now },
    { id: otherWritingId, projectId: otherProjectId, title: 'Another project', status: 'draft', content: '<p>Otra</p>', wordCount: 1, tags: [], createdAt: now, updatedAt: now },
  ]);
  await db.writingSnapshots.bulkAdd([
    { id: 'undo-snapshot-1', writingId, projectId, title: 'Doomed chapter', content: '<p>v1</p>', wordCount: 1, reason: 'manual', createdAt: now - 2 },
    { id: 'undo-snapshot-2', writingId, projectId, title: 'Doomed chapter', content: '<p>v2</p>', wordCount: 1, reason: 'auto', createdAt: now - 1 },
  ]);
  await db.annotations.add({
    id: 'undo-note', projectId, sourceEngineId: 'writings', sourceEntityId: writingId,
    anchor: { type: 'entity' }, noteType: 'reference', isOrphaned: false,
    position: 0, createdAt: now, updatedAt: now,
  });
  await db.annotationReferences.add({
    id: 'undo-note-ref', annotationId: 'undo-note',
    targetEngineId: 'codex', targetEntityId: 'codex-target', createdAt: now,
  });
  await db.outlines.add({ id: 'undo-outline', projectId, title: 'Spine', createdAt: now, updatedAt: now });
  await db.outlineBeats.add({
    id: 'undo-beat', outlineId: 'undo-outline', projectId, order: 0, level: 'beat',
    title: 'Linked beat', description: '', status: 'outlined',
    linkedWritingId: writingId, createdAt: now, updatedAt: now,
  });

  // A delete nobody armed parks nothing — the AI bridge's deletes must not pin
  // a whole manuscript in the heap waiting for an Undo bar that does not exist.
  expectDeletedWriting(writingId);
  const unarmed = await deleteWritingRestorable(otherWritingId);
  assert(unarmed?.writing.projectId === otherProjectId, 'an unarmed delete must still report what it removed');
  assert(takeLastDeletedWriting(otherWritingId) === null, 'a delete nobody armed parked a bundle anyway');

  const returned = await deleteWritingRestorable(writingId);
  assert(returned, 'deleting an existing writing must hand back its bundle');
  assert(returned.snapshots.length === 2, `the bundle carried ${returned.snapshots.length} snapshots, not the whole history`);
  assert(returned.annotations.length === 1, 'the bundle lost the margin note anchored on the chapter');
  assert(returned.annotationReferences.length === 1, 'the bundle lost the reference row hanging off that note');
  assert(returned.unlinkedBeatIds.join(',') === 'undo-beat', 'the bundle did not record the beat it unlinked');
  assert(!(await db.writings.get(writingId)), 'the writing was not deleted');
  assert((await db.writingSnapshots.where('writingId').equals(writingId).count()) === 0, 'the version history was not deleted');
  assert(!(await db.annotations.get('undo-note')), 'the margin note was not deleted');
  assert(!(await db.annotationReferences.get('undo-note-ref')), 'the annotation reference was not deleted');
  assert((await db.outlineBeats.get('undo-beat'))?.linkedWritingId === undefined, 'the outline beat was not unlinked');

  // The armed slot answers to ONE id: this is the cross-project restore bug.
  assert(takeLastDeletedWriting(otherWritingId) === null, 'the undo slot handed one writing’s id another writing’s bundle');
  const bundle = takeLastDeletedWriting(writingId);
  assert(bundle, 'the armed id could not collect its own bundle');
  assert(takeLastDeletedWriting(writingId) === null, 'the bundle must be one-shot');

  await restoreDeletedWriting(bundle);
  assert((await db.writings.get(writingId))?.title === 'Doomed chapter', 'the writing did not come back');
  assert((await db.writingSnapshots.where('writingId').equals(writingId).count()) === 2, 'the version history did not come back');
  assert(await db.annotations.get('undo-note'), 'the margin note did not come back');
  assert(await db.annotationReferences.get('undo-note-ref'), 'the annotation reference did not come back');
  assert((await db.outlineBeats.get('undo-beat'))?.linkedWritingId === writingId, 'the outline beat was not relinked');

  // Idempotent by construction — every row goes back with put/bulkPut, so a
  // double-click on Undo (or a re-render that restores again) changes nothing.
  await restoreDeletedWriting(bundle);
  assert((await db.writingSnapshots.where('writingId').equals(writingId).count()) === 2, 'a second restore duplicated the version history');
  assert(
    (await db.annotations.where('[sourceEngineId+sourceEntityId]').equals(['writings', writingId]).count()) === 1,
    'a second restore duplicated the margin note',
  );

  await db.writings.delete(writingId);
  await db.writingSnapshots.bulkDelete(['undo-snapshot-1', 'undo-snapshot-2']);
  await db.annotations.delete('undo-note');
  await db.annotationReferences.delete('undo-note-ref');
  await db.outlineBeats.delete('undo-beat');
  await db.outlines.delete('undo-outline');
  passed.push('deleted writing restores its history, notes and beats; the undo slot is armed by id');
}

// Several settings values are JSON collections changed one member at a time —
// the dismissed proofreader findings, the saved searches, the sprint log.
//
// Old bug: that was `getSetting` → mutate → `setSetting`, two awaits apart. Two
// overlapping calls both read the same starting value and the later write
// dropped the earlier one: a dismissal that came back, a saved search that
// never arrived. The read and the write are now one transaction, which
// IndexedDB serialises against any other write to the same store.
async function testConcurrentSettingUpdatesBothSurvive(): Promise<void> {
  const { getSetting, updateSetting } = await import('@/db/operations');
  const key = 'critical.updateSetting.concurrent';
  await db.settings.where('key').equals(key).delete();

  // The update callback must stay synchronous: it runs INSIDE the transaction.
  const addMember = (member: string) => (current: string | undefined): string => {
    const members = current ? (JSON.parse(current) as string[]) : [];
    return JSON.stringify(members.includes(member) ? members : [...members, member]);
  };

  await Promise.all([
    updateSetting(key, addMember('alpha')),
    updateSetting(key, addMember('beta')),
  ]);

  const stored = JSON.parse((await getSetting(key)) ?? '[]') as string[];
  assert(stored.includes('alpha'), 'a concurrent setting update dropped the first member');
  assert(stored.includes('beta'), 'a concurrent setting update dropped the second member');
  assert(stored.length === 2, `expected exactly two members, got ${JSON.stringify(stored)}`);
  assert(
    (await db.settings.where('key').equals(key).count()) === 1,
    'a concurrent setting update wrote a second row for the same key',
  );

  await db.settings.where('key').equals(key).delete();
  passed.push('two concurrent updates of one settings key both survive');
}

// `settings` is a flat key/value store with no `projectId` index, so the
// generic per-project sweep cannot see it: the sprint log, the live sprint, the
// dismissed findings, the saved searches and the grounded-AI flags used to
// outlive their project — and be INHERITED by a re-import that reused its id.
// Both paths that wipe a project now sweep exactly `projectSettingKeys(id)`:
// `deleteProject`, and the ZIP restore's `clearProjectForRestore`.
async function testProjectSweepsItsSettingsKeys(): Promise<void> {
  const { deleteProject, getSetting, projectSettingKeys, setSetting } = await import('@/db/operations');
  const now = Date.now();
  const scratchProject = (id: string, title: string) => ({
    id, title, mode: 'novelist' as const, type: 'standalone' as const,
    color: '#7c3aed', description: '', status: 'in-progress' as const,
    enabledEngines: [], engineOrder: [], createdAt: now, updatedAt: now,
  });

  const projectId = 'settings-sweep-project';
  // Its id STARTS WITH the doomed one: the sweep matches whole keys, never a
  // prefix, so this project's rows must be untouched.
  const neighbourId = `${projectId}-2`;
  const doomedKeys = projectSettingKeys(projectId);
  assert(doomedKeys.length >= 3, 'the per-project settings declaration lost its keys');

  await db.projects.put(scratchProject(projectId, 'Doomed'));
  await db.projects.put(scratchProject(neighbourId, 'Neighbour'));
  for (const key of doomedKeys) await setSetting(key, '["seeded"]');
  for (const key of projectSettingKeys(neighbourId)) await setSetting(key, '["neighbour"]');

  await deleteProject(projectId);
  for (const key of doomedKeys) {
    assert(await getSetting(key) === undefined, `project deletion left the settings key ${key} behind`);
  }
  for (const key of projectSettingKeys(neighbourId)) {
    assert(await getSetting(key) === '["neighbour"]', `project deletion swept a neighbouring project's key ${key}`);
  }

  // Same sweep on the ZIP restore path: a project archive carries no
  // settings.json at all, so anything left here is the PREVIOUS instance's.
  const zipProjectId = 'settings-sweep-zip-project';
  await db.projects.put(scratchProject(zipProjectId, 'Archivable'));
  const { blob, fileName } = await createProjectZipArchive(zipProjectId);
  const archive = new File([blob], fileName, { type: 'application/zip' });
  // Renaming locally is how the assertion below tells a real replacement from
  // an import that quietly did nothing.
  await db.projects.update(zipProjectId, { title: 'Locally renamed' });
  for (const key of projectSettingKeys(zipProjectId)) await setSetting(key, '["stale"]');

  await importProjectZip(archive, { replaceProjectIds: [zipProjectId] });
  assert(
    (await db.projects.get(zipProjectId))?.title === 'Archivable',
    'the approved replacement did not restore the archived project',
  );
  for (const key of projectSettingKeys(zipProjectId)) {
    assert(
      await getSetting(key) === undefined,
      `a project restored over itself inherited the settings key ${key}`,
    );
  }

  await deleteProject(zipProjectId);
  await deleteProject(neighbourId);
  passed.push('project deletion and ZIP replacement both sweep the per-project settings keys');
}

// Old bug: the thirds were cut from EVERY writing row. `compareManuscriptOrder`
// parks a chapter with no number at the end, so a project mixing twelve
// numbered chapters with eight unnumbered idea stubs had a "closing third" made
// of empty stubs — nobody appears there, so every main character in the opening
// chapters was reported as disappearing and the panel was useless. The thirds
// are now cut from the rows that actually carry prose.
async function testDisappearingCharactersReadsProseOnly(): Promise<void> {
  const { findDisappearingCharacters } = await import('@/services/proofreader');

  const chapter = (index: number, appearances: string[]): ProofreaderWritingRow => ({
    id: `thirds-chapter-${index}`,
    title: `Capítulo ${index}`,
    status: 'draft',
    chapter: index,
    createdAt: index,
    updatedAt: index,
    hasProse: true,
    appearances: new Set(appearances),
  });
  const stub = (id: string, status: 'idea' | 'draft', hasProse: boolean): ProofreaderWritingRow => ({
    id, title: id, status, createdAt: 100, updatedAt: 100, hasProse, appearances: new Set<string>(),
  });

  // Aurelia is in the first three chapters and then gone; the other two run
  // through the whole book. Manuscript order, exactly as `collectProofreaderInput`
  // hands it over: numbered chapters first, unnumbered rows parked at the end.
  const writings: ProofreaderWritingRow[] = [
    ...Array.from({ length: 12 }, (_unused, index) => chapter(
      index + 1,
      index < 3
        ? ['codex-marta', 'codex-bruno', 'codex-aurelia']
        : ['codex-marta', 'codex-bruno'],
    )),
    // Both kinds of row the filter drops: ideas (even ones with some text in
    // them) and drafts that are still empty. Neither is a page of the book.
    stub('thirds-idea-1', 'idea', true),
    stub('thirds-idea-2', 'idea', true),
    stub('thirds-idea-3', 'idea', false),
    stub('thirds-idea-4', 'idea', false),
    stub('thirds-empty-1', 'draft', false),
    stub('thirds-empty-2', 'draft', false),
    stub('thirds-empty-3', 'draft', false),
    stub('thirds-empty-4', 'draft', false),
  ];

  const input: ProofreaderInput = {
    projectId: 'proofreader-thirds-project',
    mode: 'novelist',
    enabledEngines: ['writings', 'codex'],
    todayKey: '2026-08-31',
    writings,
    codexEntries: [
      { id: 'codex-marta', type: 'character', title: 'Marta Ovalle' },
      { id: 'codex-bruno', type: 'character', title: 'Bruno Salas' },
      { id: 'codex-aurelia', type: 'character', title: 'Aurelia Vega' },
    ],
    scenes: [],
    blocks: [],
    casts: [],
    outlineBeats: [],
    seeds: [],
    payoffs: [],
    relationships: [],
    timelineEventIds: new Set<string>(),
  };

  const findings = findDisappearingCharacters(input);
  assert(
    !findings.some(finding => finding.entityId === 'codex-marta' || finding.entityId === 'codex-bruno'),
    'a character present in the last chapters was reported as disappearing',
  );
  assert(findings.length === 1, `expected only the character who really vanishes, got ${findings.length}`);
  assert(findings[0].id === 'character-disappears:codex-aurelia', 'the finding identity changed');
  assert(findings[0].engineId === 'codex' && findings[0].entityId === 'codex-aurelia', 'the finding does not point at the codex entry');
  assert(findings[0].severity === 'warning', 'a character with three appearances is a recurring one, not a walk-on');

  // Below three rows of prose, "first third" and "last third" mean nothing.
  assert(
    findDisappearingCharacters({ ...input, writings: writings.slice(0, 2) }).length === 0,
    'a two-chapter manuscript cannot have thirds',
  );

  passed.push('disappearing-character check cuts its thirds from prose, not from idea stubs');
}

// Old bug: the outline checks reported one row per entity even when the reason
// was the same for every one of them. A project with nine chapters and three
// beats, none of them linked — which is every project on the day the outline is
// written — produced nine identical "no beat links to this chapter" findings
// plus three identical "this beat links to nothing", burying the two checks that
// had found something real. A check that fires for EVERY eligible row is
// describing a habit, not a list of omissions, and now says so once.
async function testOutlineChecksCollapseWhenNothingIsLinkedYet(): Promise<void> {
  const { findWritingsOutsideOutline, findBeatsWithoutScene } = await import('@/services/proofreader');

  const writing = (index: number, status: 'draft' | 'finished' | 'idea'): ProofreaderWritingRow => ({
    id: `collapse-writing-${index}`,
    title: `Capítulo ${index}`,
    status,
    chapter: index,
    createdAt: index,
    updatedAt: index,
    hasProse: true,
    appearances: new Set<string>(),
  });
  const beat = (index: number, links?: { writing?: string; scene?: string }) => ({
    id: `collapse-beat-${index}`,
    projectId: 'collapse-project',
    title: `Hito ${index}`,
    description: '',
    order: index,
    actId: 'collapse-act',
    linkedWritingId: links?.writing,
    linkedSceneId: links?.scene,
    createdAt: index,
    updatedAt: index,
  } as unknown as ProofreaderInput['outlineBeats'][number]);

  const base: ProofreaderInput = {
    projectId: 'collapse-project',
    mode: 'novelist',
    enabledEngines: ['writings', 'outline'],
    todayKey: '2026-08-31',
    writings: [writing(1, 'draft'), writing(2, 'draft'), writing(3, 'finished'), writing(4, 'idea')],
    codexEntries: [],
    scenes: [],
    blocks: [],
    casts: [],
    outlineBeats: [beat(1), beat(2), beat(3)],
    seeds: [],
    payoffs: [],
    relationships: [],
    timelineEventIds: new Set<string>(),
  };

  // Nothing linked anywhere: one finding per check, not one per row.
  const orphaned = findWritingsOutsideOutline(base);
  assert(orphaned.length === 1, `expected one collapsed finding, got ${orphaned.length}`);
  assert(orphaned[0].id === 'writing-outside-outline:none-linked', 'the collapsed finding identity changed');
  assert(orphaned[0].severity === 'info', 'an outline nobody has started linking is not a warning');
  assert(orphaned[0].route === 'outline', 'the collapsed finding must open the spine, not an entity');
  assert(orphaned[0].detail.includes('3') && orphaned[0].detail.includes('3'), 'the collapsed finding must carry the counts');

  const empty = findBeatsWithoutScene(base);
  assert(empty.length === 1, `expected one collapsed beat finding, got ${empty.length}`);
  assert(empty[0].id === 'beat-without-scene:none-linked', 'the collapsed beat finding identity changed');
  assert(empty[0].route === 'outline', 'the collapsed beat finding must open the spine');

  // One link is enough to make the rest real omissions again: the writer HAS
  // started, so the ones left behind are worth naming individually.
  const started: ProofreaderInput = {
    ...base,
    outlineBeats: [beat(1, { writing: 'collapse-writing-1' }), beat(2), beat(3)],
  };
  const named = findWritingsOutsideOutline(started);
  assert(named.length === 2, `expected the two unlinked chapters by name, got ${named.length}`);
  assert(
    named.every(finding => finding.id.startsWith('writing-outside-outline:collapse-writing-')),
    'a per-chapter finding must still name its chapter',
  );
  assert(
    !named.some(finding => finding.entityId === 'collapse-writing-4'),
    'an idea is not a chapter missing from the outline',
  );
  assert(
    named.some(finding => finding.entityId === 'collapse-writing-3' && finding.severity === 'warning'),
    'a FINISHED chapter outside the outline is still a warning',
  );

  const stillOpen = findBeatsWithoutScene(started);
  assert(stillOpen.length === 2, `expected the two empty beats by name, got ${stillOpen.length}`);

  // A pointer at a deleted chapter is dead data, never a habit: it keeps its
  // own row and its own fix even when every other beat is empty.
  const broken = findBeatsWithoutScene({
    ...base,
    outlineBeats: [beat(1, { writing: 'deleted-chapter' }), beat(2), beat(3)],
  });
  assert(
    broken.some(finding => finding.id === 'beat-without-scene:broken:collapse-beat-1' && Boolean(finding.fix)),
    'a dead pointer must keep its own repairable finding',
  );
  assert(broken.length === 3, `a dead pointer must stop the collapse, got ${broken.length} findings`);

  // Below the threshold, naming each row is still the clearest report.
  const tiny = findWritingsOutsideOutline({
    ...base,
    writings: [writing(1, 'draft'), writing(2, 'draft')],
    outlineBeats: [beat(1)],
  });
  assert(tiny.length === 2, `two chapters is a list, not a habit, got ${tiny.length}`);

  passed.push('outline checks collapse to one finding when the project links nothing yet');
}

// Old bug: reading progress was measured from the TOP of the viewport, so a
// manuscript short enough to fit on one screen could not be scrolled at all and
// sat at 0 % however long it was read — and the last screenful of any book was
// unreachable, leaving a finished manuscript short of 100 %.
async function testReadingProgressCountsWhatIsOnScreen(): Promise<void> {
  const { readOffset, manuscriptProgress, positionAt } = await import('@/engines/writings/readingWindow');

  // One piece, 400px tall, in an 800px viewport: the whole book is on screen.
  const one = () => 400;
  const fitsOnScreen = positionAt(readOffset(0, 800, 400), 1, one);
  assert(
    manuscriptProgress(fitsOnScreen, [0, 500], 500) === 1,
    'a manuscript that fits on one screen must read 100 %, not 0 %',
  );

  // Three 1 000px chapters of 100 words each, in a 500px viewport. Scrolled to
  // the very bottom, `scrollTop` is 2 500 — a viewport short of the end.
  const three = () => 1000;
  const prefixes = [0, 100, 200, 300];
  const atBottom = positionAt(readOffset(2500, 500, 3000), 3, three);
  assert(
    manuscriptProgress(atBottom, prefixes, 300) === 1,
    'the end of the manuscript must read 100 %',
  );

  // …and the reader has genuinely read more than the top of the viewport says.
  const fromTop = manuscriptProgress(positionAt(1000, 3, three), prefixes, 300);
  const fromBottom = manuscriptProgress(positionAt(readOffset(1000, 500, 3000), 3, three), prefixes, 300);
  assert(fromBottom > fromTop, 'progress must count the screenful the reader can see');
  assert(Math.abs(fromBottom - 0.5) < 1e-9, `expected half the book read, got ${fromBottom}`);

  // Degenerate inputs stay in range instead of throwing or overshooting.
  assert(readOffset(0, 800, 0) === 0, 'an empty manuscript has no read offset');
  assert(readOffset(-50, -50, 1000) === 0, 'a negative scroll must not read backwards');
  assert(readOffset(9999, 800, 1000) === 1000, 'the read offset must never pass the end');

  passed.push('reading progress is measured from the bottom of the viewport');
}

// The proofreader's `seed-without-payoff` finding exists to provoke exactly one
// action — naming the place where the seed finally lands — and the seeds card
// now performs it without opening the seed at all. `buildQuickPayoff` is that
// step: two dropdown ids in, the row that closes the orphan out.
//
// The rule worth pinning is the one about stale ids. Those two lists are the
// only statement of what the writer was offered; an id missing from one means
// the chapter or scene went away between the render and the click, and writing
// it onto the payoff anyway would mint precisely the dead reference the
// proofreader is there to catch — while the other half of the choice, still
// live, has to survive on its own.
async function testOrphanSeedClosesInOneStep(): Promise<void> {
  const { buildQuickPayoff } = await import('@/engines/seeds/quickPayoff');
  const { computeSeedStatus } = await import('@/engines/seeds/types');

  const seed = {
    id: 'seed/raven',
    projectId: 'seed-quick-payoff-project',
    title: 'The raven on the windowsill',
    description: '',
    kind: 'foreshadow' as const,
    status: 'planted' as const,
    tags: [],
    createdAt: 1,
    updatedAt: 1,
  };
  const writings = [{ id: 'w/6', label: 'Chapter 6' }, { id: 'w/7', label: 'Chapter 7' }];
  const scenes = [{ id: 'sc/3', label: '#3 The duel' }];
  const build = (writingId: string, sceneId: string, offered = { writings, scenes }) =>
    buildQuickPayoff({
      seed,
      writingId,
      sceneId,
      writings: offered.writings,
      scenes: offered.scenes,
      titleTemplate: 'Pays off in {target}',
      id: 'payoff/quick',
      now: 4242,
    });

  assert(build('', '') === null, 'a payoff was built for a target the writer never chose');
  assert(build('w/deleted', '') === null, 'a payoff was linked to a chapter that is no longer on offer');

  const both = build('w/7', 'sc/3');
  assert(both !== null, 'picking a chapter and a scene produced no payoff at all');
  assert(
    both?.seedId === 'seed/raven' && both?.projectId === 'seed-quick-payoff-project',
    'the quick payoff lost the seed it closes or the project it belongs to',
  );
  assert(
    both?.linkedWritingId === 'w/7' && both?.linkedSceneId === 'sc/3',
    'the quick payoff dropped one of the two targets the writer picked',
  );
  assert(
    both?.title === 'Pays off in Chapter 7 · #3 The duel',
    `the quick payoff titled itself "${String(both?.title)}"`,
  );
  assert(both?.locationLabel === 'Chapter 7 · #3 The duel', 'the quick payoff did not record where it lands');
  assert(
    both?.strength === 3 && both?.createdAt === 4242 && both?.updatedAt === 4242,
    'the quick payoff no longer lands as a middling, freshly stamped row',
  );

  // Half a stale choice is still a whole answer: the scene vanished, the
  // chapter the writer picked has to outlive it.
  const chapterOnly = build('w/7', 'sc/gone');
  assert(chapterOnly !== null, 'a dead scene id took the live chapter down with it');
  assert(
    chapterOnly?.linkedWritingId === 'w/7' && chapterOnly?.linkedSceneId === undefined,
    'a scene id that was no longer on offer was written onto the payoff anyway',
  );
  assert(chapterOnly?.locationLabel === 'Chapter 7', 'a dropped scene left its separator behind');

  // An untitled chapter is a real row with nothing to read: it must link
  // without padding the label with an empty half.
  const untitled = build('w/blank', 'sc/3', { writings: [{ id: 'w/blank', label: '  ' }], scenes });
  assert(untitled?.linkedWritingId === 'w/blank', 'an untitled chapter could not be pointed at');
  assert(
    untitled?.locationLabel === '#3 The duel',
    `an untitled chapter padded the label: "${String(untitled?.locationLabel)}"`,
  );

  // The point of the whole action: the card reads back as paid off with no seed
  // row touched — and a seed the author cut stays cut, payoff or no payoff.
  assert(computeSeedStatus(seed, []) === 'orphaned', 'the seed under test was not an orphan to begin with');
  assert(
    computeSeedStatus(seed, both ? [both] : []) === 'paid',
    'the payoff the card creates does not close the orphan',
  );
  assert(
    computeSeedStatus({ ...seed, status: 'cut' as const }, both ? [both] : []) === 'cut',
    'a cut seed was resurrected by a quick payoff',
  );

  passed.push('quick payoff closes an orphan seed against the targets the picker actually offered');
}

// `Writing.chapter` is the manuscript's only order, and the manuscript import
// appends after the highest number the project already used — a forty-chapter
// novel brought into six scratch drafts arrives as chapters 7..46. Both ways
// back from that are planned by pure functions in `chapterOrder.ts`, and this
// is where they are held to what the view promises about them.
//
// Three rules are load-bearing.
//
//   A move must MOVE. Two chapters both numbered 7 is the shape that makes an
//   arrow a no-op: exchanging their numbers writes 7 to both, the tie falls
//   back to `id`, and the button sits enabled forever doing nothing. The
//   timeline's lane reorder was rewritten once already for exactly this.
//
//   A move must not renumber. A writer numbering 1, 2, 5, 9 left room at 3
//   and 4 on purpose, and an arrow press is not permission to take it away.
//
//   Renumbering must be idempotent. The view disables the button on an empty
//   plan and tells the writer nothing else changes; both statements are only
//   true if a second pass over an already-numbered book plans no writes — the
//   one thing standing between a renumber and forty rows stamped with a fresh
//   `updatedAt` in the "changed recently" panel.
async function testChapterOrderPlans(): Promise<void> {
  const { moveChapter, numberedInOrder, renumberChapters } =
    await import('@/engines/writings/chapterOrder');

  interface Row { id: string; chapter?: number }
  interface Plan { id: string; chapter: number }

  const rows = (...pairs: Array<[string, number | undefined]>): Row[] =>
    pairs.map(([id, chapter]) => ({ id, chapter }));

  /** The plan applied, the way `applyChapterNumbers` writes one. */
  const apply = (base: Row[], plan: readonly Plan[]): Row[] => {
    const byId = new Map(plan.map(item => [item.id, item.chapter]));
    return base.map(row => {
      const next = byId.get(row.id);
      return next === undefined ? row : { ...row, chapter: next };
    });
  };

  /** The manuscript as the list would read it: `id:number`, in order. */
  const reads = (base: Row[]): string =>
    numberedInOrder(base).map(row => `${row.id}:${row.chapter}`).join(',');

  // ── A move is an exchange of two numbers, and keeps the gaps ──
  const spaced = rows(['a', 1], ['b', 2], ['c', 5], ['d', 9], ['idea', undefined]);
  const lifted = moveChapter(spaced, 'c', -1);
  assert(lifted.length === 2, `moving one chapter rewrote ${lifted.length} rows, not two`);
  assert(
    reads(apply(spaced, lifted)) === 'a:1,c:2,b:5,d:9',
    `a move renumbered the book: ${reads(apply(spaced, lifted))}`,
  );
  assert(
    apply(spaced, lifted).find(row => row.id === 'idea')?.chapter === undefined,
    'a move gave a number to a writing that had none',
  );

  // Down is up's inverse, so the pair of them leaves the book as it was.
  const there = apply(spaced, moveChapter(spaced, 'b', 1));
  assert(
    reads(apply(there, moveChapter(there, 'b', -1))) === reads(spaced),
    'down then up did not put the chapter back',
  );

  // ── Totality: nothing here throws, and nothing off the ends moves ──
  assert(moveChapter(spaced, 'a', -1).length === 0, 'the first chapter moved up out of the book');
  assert(moveChapter(spaced, 'd', 1).length === 0, 'the last chapter moved down out of the book');
  assert(moveChapter(spaced, 'idea', -1).length === 0, 'an unnumbered writing was given a place');
  assert(moveChapter(spaced, 'gone', 1).length === 0, 'an id the project does not hold planned a write');
  assert(moveChapter([], 'a', 1).length === 0 && renumberChapters([]).length === 0, 'an empty project planned a write');

  // ── Duplicates: the move has to take, not tie ──
  const tied = rows(['p', 7], ['q', 7]);
  const untied = apply(tied, moveChapter(tied, 'q', -1));
  assert(reads(untied) === 'q:7,p:8', `two chapters numbered 7 did not come apart: ${reads(untied)}`);

  // ── Renumbering: 1..n over what is numbered, and nothing else ──
  const imported = rows(['old', 1], ['ch1', 7], ['ch2', 8], ['ch3', 9], ['stub', undefined]);
  const numbered = apply(imported, renumberChapters(imported));
  assert(
    reads(numbered) === 'old:1,ch1:2,ch2:3,ch3:4',
    `renumbering did not produce 1..n in the order it found: ${reads(numbered)}`,
  );
  assert(
    numbered.find(row => row.id === 'stub')?.chapter === undefined,
    'renumbering turned an idea into a chapter',
  );

  // The claim the confirmation dialog makes, and the button's disabled state.
  assert(
    renumberChapters(numbered).length === 0,
    'renumbering twice rewrote rows the second time — the plan is not idempotent',
  );

  passed.push('chapter moves exchange numbers without renumbering, and renumbering is idempotent');
}

// The spine's one verb. Turning a beat into the chapter that writes it used to
// be six screens of hand-work, so the writer did it once and then stopped —
// which is why every project the proofreader looked at had an outline linked to
// nothing. Two rules are load-bearing here and neither is visible in the UI: a
// second press must not mint a second chapter, and the beat's description must
// reach the SYNOPSIS rather than the page, because a plan in the writer's
// shorthand is not prose they wrote.
async function testWritingABeatCreatesOneLinkedChapter(): Promise<void> {
  const { writeChapterForBeat, beatNeedsChapter, chapterTitleFromBeat } =
    await import('@/engines/outline/beatToChapter');
  const { db } = await import('@/db');

  const projectId = 'beat-to-chapter-project';
  const beat = {
    id: 'beat-to-chapter-1',
    projectId,
    outlineId: 'beat-to-chapter-outline',
    title: 'Aurelia quema la carta',
    description: 'Se queda sola en la cocina. No se lo cuenta a Marek.',
    order: 0,
    level: 0,
    status: 'planned',
    createdAt: 1,
    updatedAt: 1,
  } as unknown as Parameters<typeof writeChapterForBeat>[0];

  await db.outlineBeats.put(beat as never);
  // A chapter already numbered 4, so the append-only rule has something to
  // append after — a beat written out of order must not renumber written work.
  await db.writings.put({
    id: 'beat-to-chapter-existing', projectId, title: 'Capítulo cuatro', status: 'draft',
    content: '<p>ya escrito</p>', wordCount: 2, chapter: 4, tags: [], createdAt: 1, updatedAt: 1,
  } as never);

  try {
    assert(beatNeedsChapter(beat, new Set<string>()), 'an unlinked beat needs a chapter');

    const first = await writeChapterForBeat(beat);
    assert(first.chapter === 5, `the chapter must append after the highest number, got ${first.chapter}`);
    assert(first.title === 'Aurelia quema la carta', 'the chapter takes the beat title');

    const created = await db.writings.get(first.writingId);
    assert(Boolean(created), 'the chapter was not written');
    assert(created?.status === 'draft', 'a chapter minted from a beat starts as a draft');
    assert(created?.content === '', 'the beat description must NOT be written into the page as prose');
    assert(
      created?.synopsis === 'Se queda sola en la cocina. No se lo cuenta a Marek.',
      'the beat description belongs in the synopsis',
    );
    assert(created?.wordCount === 0, 'an empty page has no words');

    const linked = await db.outlineBeats.get(beat.id);
    assert(
      (linked as { linkedWritingId?: string } | undefined)?.linkedWritingId === first.writingId,
      'the beat was not linked to the chapter it just created',
    );
    assert(
      !beatNeedsChapter(linked as never, new Set([first.writingId])),
      'a beat with a live chapter must stop offering to write one',
    );

    // The double click. The second call reads committed state inside its own
    // transaction, so it hands back the same row instead of a duplicate.
    const second = await writeChapterForBeat(linked as never);
    assert(second.writingId === first.writingId, 'a second press minted a second chapter');
    const all = await db.writings.where('projectId').equals(projectId).toArray();
    assert(all.length === 2, `expected the existing chapter plus one new one, got ${all.length}`);

    // A pointer at a deleted chapter is not "written": the action comes back.
    assert(
      beatNeedsChapter(linked as never, new Set(['some-other-id'])),
      'a beat pointing at a deleted chapter must offer to write one again',
    );

    // A beat with no title of its own still mints a findable row: the first
    // LINE of the plan, not the whole plan, because a description is often a
    // paragraph and a chapter list is not the place to read one.
    assert(
      chapterTitleFromBeat(
        { ...beat, title: '   ', description: 'Quema la carta.\nMarek no lo sabe.' } as never,
        7,
      ) === 'Quema la carta.',
      'an untitled beat falls back to the first line of its description',
    );
    assert(
      chapterTitleFromBeat({ ...beat, title: '   ' } as never, 7)
        === 'Se queda sola en la cocina. No se lo cuenta a Marek.',
      'a one-line description is used whole',
    );
    assert(
      chapterTitleFromBeat({ ...beat, title: '', description: '' } as never, 7) === '7',
      'a beat with nothing to say still gets a title',
    );
  } finally {
    await db.writings.where('projectId').equals(projectId).delete();
    await db.outlineBeats.delete(beat.id);
  }

  passed.push('writing a beat creates exactly one linked chapter, with the plan in its synopsis');
}

// ===========================================================================
// The compile/publish path — the one artefact that leaves the app
// ===========================================================================
//
// A defect anywhere below is invisible from inside Writers Hoard: the list on
// screen still looks right, and the file is already in an editor's inbox. So
// these three hold the export to the three things a writer assumes about it
// without ever checking — that the chapters are in the order the list shows,
// that the file opens at all, and that the words in it are the words typed.

/**
 * ORDER. `compareManuscriptOrder` is the manuscript's only order, and the
 * export has to be in it.
 *
 * `defaultPublishingOrder` used to be a second, hand-written comparator —
 * chapter, then `createdAt`, then id — which agreed with the list on exactly
 * one shape: a book whose chapters are all numbered, all differently. The
 * manuscript import made the other two ordinary, and this fixture is built out
 * of both of them:
 *
 *   `stub-a`/`stub-b` carry NO chapter number. The list shows them last, most
 *   recently touched first; the old comparator sorted them oldest-created
 *   first, which is the opposite here on purpose.
 *
 *   `a-seven`/`z-seven` SHARE chapter 7 — legal, and what an import landing
 *   beside hand-numbered chapters produces. The list breaks that tie on the
 *   id; the old comparator broke it on `createdAt`, which is the opposite here
 *   on purpose too.
 */
async function testPublishingOrderMatchesTheList(): Promise<void> {
  const { defaultPublishingOrder } = await import('@/services/projectTools');
  const { compareManuscriptOrder } = await import('@/engines/writings/chapterOrder');

  const projectId = 'publishing-order-project';
  const writing = (value: Partial<Writing> & { id: string }): Writing => ({
    projectId,
    title: value.id,
    status: 'draft',
    content: '<p>Prose</p>',
    wordCount: 1,
    tags: [],
    createdAt: 1,
    updatedAt: 1,
    ...value,
  });

  const book = [
    writing({ id: 'ch-1', chapter: 1, createdAt: 300, updatedAt: 300 }),
    writing({ id: 'z-seven', chapter: 7, createdAt: 100, updatedAt: 400 }),
    writing({ id: 'a-seven', chapter: 7, createdAt: 500, updatedAt: 200 }),
    writing({ id: 'ch-9', chapter: 9, createdAt: 200, updatedAt: 250 }),
    writing({ id: 'stub-a', createdAt: 10, updatedAt: 100 }),
    writing({ id: 'stub-b', createdAt: 90, updatedAt: 900 }),
  ];
  const ids = (rows: readonly Writing[]): string => rows.map(row => row.id).join(',');

  // The order the Writings list is showing, read off the single source of
  // truth rather than restated here.
  const onScreen = ids([...book].sort(compareManuscriptOrder));
  assert(
    onScreen === 'ch-1,a-seven,z-seven,ch-9,stub-b,stub-a',
    `the fixture no longer exercises both divergences: ${onScreen}`,
  );
  assert(
    ids(defaultPublishingOrder(book)) === onScreen,
    `the export ordered chapters differently from the list: ${ids(defaultPublishingOrder(book))}`,
  );

  // End to end through the layer the exporters actually call. A profile with
  // no pinned order falls back to `defaultPublishingOrder`, and that fallback
  // is also what seeds a quick compile — the shortcut most writers use.
  const profile: PublishingProfile = {
    id: 'order-profile',
    projectId,
    name: 'Editorial',
    format: 'manuscript',
    includeTitlePage: false,
    includeSynopsis: false,
    includeBibliography: false,
    citationStyle: 'apa',
    selectionMode: 'all',
    selectedWritingIds: [],
    writingOrder: [],
    createdAt: 1,
    updatedAt: 1,
  };
  const resolvedIds = ids(resolvePublishingWritings(book, profile).writings);
  assert(resolvedIds === onScreen, `the resolved export order left the list order: ${resolvedIds}`);

  // A pinned order still wins — that is the writer arranging the book by hand
  // — and only the rows it does not name fall back to manuscript order.
  const pinned = resolvePublishingWritings(book, { ...profile, writingOrder: ['ch-9', 'stub-a'] });
  assert(
    ids(pinned.writings) === 'ch-9,stub-a,ch-1,a-seven,z-seven,stub-b',
    `a hand-arranged order was not honoured, or its tail left manuscript order: ${ids(pinned.writings)}`,
  );

  passed.push('the exported chapter order is the order the writings list shows');
}

/**
 * MARKUP AND ENCODING. Both portable formats are XML containers — an .epub is
 * XHTML, a .docx is OOXML — so every title, synopsis and citation that reaches
 * either one has to arrive escaped, and no character XML cannot carry may
 * reach either one at all.
 *
 * The fixture is a title an editor would actually send back: `Marek & Aurelia
 * <fin>`, which is three separate ways to end a document early. Around it sit
 * the Spanish accents, guillemets and em dashes the app is written for, and
 * the characters the manuscript importer can carry in — `decodeXml` in
 * `manuscriptDocx` turns `&#12;` into a real form feed, nothing between there
 * and here removes it, and one of them anywhere in the file is the difference
 * between a manuscript and "Word cannot open this document".
 *
 * The load-bearing assertion is not a substring: it is that every XML part of
 * both files PARSES. A corrupt export is corrupt as a whole, so that is the
 * shape the test has to take.
 */
async function testPublishingMarkupAndEncoding(): Promise<void> {
  const { composePublishingDocument } = await import('@/engines/writings/publishingDocument');
  const [{ buildPublishingDocx }, { buildPublishingEpub }] = await Promise.all([
    import('@/engines/writings/publishingDocx'),
    import('@/engines/writings/publishingEpub'),
  ]);

  /** Everything XML 1.0 refuses, minus the tab, LF and CR it accepts. */
  const xmlHostile = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/;

  const hostile = 'Marek & Aurelia <fin>';
  const accented = '—Corazón —dijo Aurelia—, «ven aquí».';
  const writings: Writing[] = [
    {
      id: 'hostile',
      projectId: 'p',
      // A form feed mid-title, where `trim()` cannot reach it, and a lone high
      // surrogate at the end — exactly as an imported chapter title carries
      // them out of somebody else's .docx.
      title: 'Marek\u000C & Aurelia <fin>\uD800',
      status: 'draft',
      content: `<p>${accented}</p><blockquote><p>“Ni&nbsp;así”</p></blockquote>`,
      synopsis: 'Un capítulo & su <resumen>',
      wordCount: 7,
      chapter: 5,
      tags: [],
      createdAt: 1,
      updatedAt: 1,
    },
  ];

  const document = composePublishingDocument(writings, {
    projectTitle: hostile,
    includeTitlePage: true,
    includeSynopsis: true,
    chapterLabel: 'Capítulo',
    untitledLabel: 'Sin título',
    wordLabel: 'palabras',
    locale: 'es-ES',
    generatedAt: Date.UTC(2026, 7, 24),
    bibliographyTitle: 'Bibliografía & <fuentes>',
    bibliography: ['Ortiz, «El mar» & otros <1987>'],
  });

  // Cleaned once, on the IR, so both writers inherit it. Half a character is
  // not a character any encoder can write, so a lone surrogate becomes U+FFFD
  // rather than vanishing and closing the gap over itself.
  const composedTitle = document.sections[0]?.title ?? '';
  assert(!xmlHostile.test(composedTitle), 'a control character survived into the publishing IR');
  assert(
    composedTitle === `Capítulo 5 — ${hostile}\uFFFD`,
    `the composed heading changed shape: ${JSON.stringify(composedTitle)}`,
  );

  /** A part is only correct if the whole document it belongs to parses. */
  const wellFormed = (xml: string): boolean =>
    new DOMParser().parseFromString(xml, 'application/xml')
      .getElementsByTagName('parsererror').length === 0;

  // -- ePub --
  const epub = await JSZip.loadAsync(await (await buildPublishingEpub(document)).arrayBuffer());
  const epubParts = Object.keys(epub.files).filter(path => /\.(?:xhtml|opf|xml)$/.test(path));
  assert(epubParts.length >= 4, `ePub is missing XML parts: ${epubParts.join(',')}`);
  for (const path of epubParts) {
    const xml = await epub.file(path)?.async('string') ?? '';
    assert(wellFormed(xml), `ePub part ${path} is not well-formed XML`);
  }
  const chapter = await epub.file('EPUB/section-1.xhtml')?.async('string') ?? '';
  const nav = await epub.file('EPUB/nav.xhtml')?.async('string') ?? '';
  const opf = await epub.file('EPUB/package.opf')?.async('string') ?? '';
  assert(chapter.includes('Marek &amp; Aurelia &lt;fin&gt;'), 'ePub did not escape the chapter title');
  assert(!/<fin>/.test(`${chapter}${nav}${opf}`), 'a raw tag out of a title reached the ePub');
  assert(nav.includes('Marek &amp; Aurelia &lt;fin&gt;'), 'the ePub table of contents did not escape the title');
  assert(opf.includes('<dc:title>Marek &amp; Aurelia &lt;fin&gt;</dc:title>'), 'ePub package metadata did not escape the title');
  assert(chapter.includes('Un capítulo &amp; su &lt;resumen&gt;'), 'ePub did not escape the synopsis');
  assert(chapter.includes('«ven aquí»') && chapter.includes('—Corazón'), 'ePub lost non-ASCII prose');

  // -- DOCX --
  const docx = await JSZip.loadAsync(await (await buildPublishingDocx(document)).arrayBuffer());
  const body = await docx.file('word/document.xml')?.async('string') ?? '';
  assert(wellFormed(body), 'word/document.xml is not well-formed XML — this is the file Word calls corrupt');
  const core = await docx.file('docProps/core.xml')?.async('string');
  if (core) assert(wellFormed(core), 'docProps/core.xml is not well-formed XML');
  assert(body.includes('Marek &amp; Aurelia &lt;fin&gt;'), 'DOCX did not escape the chapter title');
  assert(!xmlHostile.test(body), 'a control character reached word/document.xml');
  assert(body.includes('«ven aquí»') && body.includes('Corazón'), 'DOCX lost non-ASCII prose');

  passed.push('titles, synopses and citations are escaped and XML-safe in both DOCX and ePub');
}

/**
 * EDGE MANUSCRIPTS, and the promise the preview makes.
 *
 * The editor's title field is an unguarded input with a placeholder, so a
 * blanked title is a real row — and it used to reach the file as an empty
 * `<h1></h1>`, an empty `<title></title>`, a table-of-contents entry with
 * nothing to click, and a heading reading "Capítulo 5 — " with the em dash
 * left hanging off the end.
 *
 * The second half is the worst bug this path can have: a preview that
 * disagrees with the file. There is one composer, and this is what says so.
 */
async function testPublishingEdgeManuscripts(): Promise<void> {
  const { composePublishingDocument } = await import('@/engines/writings/publishingDocument');
  const { buildPublishingPreview } = await import('@/services/projectTools');
  const { buildPublishingEpub } = await import('@/engines/writings/publishingEpub');

  const projectId = 'publishing-edge-project';
  const writing = (value: Partial<Writing> & { id: string }): Writing => ({
    projectId,
    title: value.id,
    status: 'draft',
    content: '<p>Prose</p>',
    wordCount: 1,
    tags: [],
    createdAt: 1,
    updatedAt: 1,
    ...value,
  });

  // A whitespace-only title on a numbered chapter, a blank one on a writing
  // with no number at all, and a chapter whose body is empty.
  const ragged = [
    writing({ id: 'blank-numbered', title: '   ', chapter: 5 }),
    writing({ id: 'blank-unnumbered', title: '', updatedAt: 900 }),
    writing({ id: 'hollow', title: 'Silencio', chapter: 6, content: '', wordCount: 0 }),
  ];
  const document = composePublishingDocument(ragged, {
    projectTitle: 'Proyecto',
    includeTitlePage: true,
    includeSynopsis: true,
    chapterLabel: 'Capítulo',
    untitledLabel: 'Sin título',
    wordLabel: 'palabras',
    locale: 'es-ES',
    generatedAt: Date.UTC(2026, 7, 24),
  });
  const headings = document.sections.map(section => section.title);
  assert(
    headings.join(' | ') === 'Capítulo 5 — Sin título | Sin título | Capítulo 6 — Silencio',
    `a blank title did not fall back to the placeholder: ${headings.join(' | ')}`,
  );
  assert(
    !headings.some(heading => heading.trim() === '' || /—\s*$/.test(heading)),
    'a heading came out empty, or with the em dash hanging off the end',
  );
  // An empty body is a real chapter, not a dropped one.
  assert(document.sections.length === 3, `an edge chapter was dropped from the document: ${document.sections.length}`);
  assert(document.sections[2].html === '' && document.sections[2].portableHtml === '', 'an empty chapter grew a body');

  const epub = await JSZip.loadAsync(await (await buildPublishingEpub(document)).arrayBuffer());
  const nav = await epub.file('EPUB/nav.xhtml')?.async('string') ?? '';
  const hollow = await epub.file('EPUB/section-3.xhtml')?.async('string') ?? '';
  assert(!/<a href="[^"]*">\s*<\/a>/.test(nav), 'the ePub table of contents holds an entry with nothing to click');
  assert(!/<title>\s*<\/title>|<h1>\s*<\/h1>/.test(hollow), 'an empty chapter produced an empty title or heading');

  // -- The preview against the file --
  //
  // Both sides are built WITHOUT explicit labels on purpose: that is how the
  // app calls them, and it makes this a comparison of two code paths rather
  // than of two label sets.
  const profile: PublishingProfile = {
    id: 'edge-profile',
    projectId,
    name: 'Editorial',
    format: 'manuscript',
    includeTitlePage: true,
    includeSynopsis: false,
    includeBibliography: false,
    citationStyle: 'apa',
    selectionMode: 'all',
    selectedWritingIds: [],
    writingOrder: [],
    createdAt: 1,
    updatedAt: 1,
  };
  const project = { id: projectId, title: 'Proyecto' };
  const generatedAt = Date.UTC(2026, 7, 24);

  for (const selection of [ragged, [ragged[0]]]) {
    const resolved = resolvePublishingWritings(selection, profile);
    const file = buildPublishingArtifacts(project, profile, resolved.writings, [], { generatedAt });
    const preview = buildPublishingPreview(project, profile, selection, [], { generatedAt });
    assert(
      preview.pieces.map(piece => piece.title).join('|')
        === file.document.sections.map(section => section.title).join('|'),
      'the preview showed different headings, or a different order, from the file',
    );
    assert(
      preview.pieceCount === file.document.sections.length && preview.unlistedPieceCount === 0,
      'the preview counted a different number of writings than the file carries',
    );
    // The number under the preview is the number the file's title page prints.
    assert(
      preview.wordCount === file.document.wordCount,
      `the preview total disagreed with the exported title page: ${preview.wordCount} vs ${file.document.wordCount}`,
    );
  }

  // One chapter opens the book, so the ePub spine is the title page and that
  // single section — no empty spine, and nothing invented to pad it.
  const single = buildPublishingArtifacts(project, profile, [ragged[0]], [], { generatedAt });
  const soloEpub = await JSZip.loadAsync(await (await buildPublishingEpub(single.document)).arrayBuffer());
  const soloOpf = await soloEpub.file('EPUB/package.opf')?.async('string') ?? '';
  assert(
    (soloOpf.match(/<itemref /g) ?? []).length === 2 && soloOpf.includes('<itemref idref="section-1" />'),
    'a one-chapter manuscript did not produce a title page plus one section in the spine',
  );

  passed.push('blank titles, empty chapters and one-chapter books export intact, and the preview matches the file');
}

// `await testProjectRestoreCarriesEngineRows();` to run(), after
// testProjectImportCollisionGuard(). No new top-level imports are needed:
// `db`, `createProjectZipArchive` and `importProjectZip` are already imported,
// and the copilot strategy registers itself through `@/engines`, which
// `zipBackup` pulls in.

// The project-ZIP restore hung for ever on 2026-08-31, and the two tests that
// covered it never noticed because both of their fixtures were a bare
// `projects` row: with no engine data in the archive, every strategy read a
// file that was not there, wrote nothing, and the transaction sailed through.
//
// The hang was one strategy write away the whole time. A strategy reads its
// JSON out of JSZip, and JSZip pumps every read through its own
// `setImmediate` — one hop to the event loop. Dexie only carries a
// transaction's zone across MICROtasks, so the code resuming after that hop was
// outside the restore's transaction and its `bulkPut` opened a SECOND readwrite
// transaction over the same store. IndexedDB queued it behind the first; the
// first could not commit until the strategy returned; neither ever moved — and
// the `Dexie.waitFor` around the strategy is what made that silent rather than
// a "transaction committed too early" error, because its spin loop holds the
// first transaction alive for exactly as long as the deadlock lasts. The cure
// is to read the whole archive BEFORE the transaction opens, so nothing inside
// it ever yields.
//
// So this test seeds what a real project has and a bare fixture does not:
// a plain engine table (`diaryEntries`, restored by the shared simple
// strategy) and the copilot's `aiProjectSettings`, whose primary key IS the
// project. Both wedged the old code — diary first, because its strategy is
// registered earlier — so the archive here fails the old restore twice over.
//
// It also holds the restore to the two things that must be true once it
// returns: the trust fields never travel, and a project restored over itself
// does not inherit rows of its previous instance that the archive is silent
// about — including the row keyed BY the project, which the sweep used to skip.
async function testProjectRestoreCarriesEngineRows(): Promise<void> {
  const projectId = 'restore-hang-project';
  const now = Date.now();

  const scratchProject = (title: string) => ({
    id: projectId, title, mode: 'novelist' as const, type: 'standalone' as const,
    color: '#7c3aed', description: '', status: 'in-progress' as const,
    enabledEngines: [], engineOrder: [], createdAt: now, updatedAt: now,
  });

  const archiveOf = async (): Promise<File> => {
    const { blob, fileName } = await createProjectZipArchive(projectId);
    return new File([blob], fileName, { type: 'application/zip' });
  };

  // A deadlocked restore used to take the whole suite down with it, and the
  // harness could only report that the suite had stopped answering. Racing it
  // turns the hang into this test's own failed assertion — and a real
  // BackupOperationError still propagates untouched.
  const restore = async (archive: File, what: string): Promise<void> => {
    const outcome = await Promise.race([
      importProjectZip(archive, { replaceProjectIds: [projectId] })
        .then(() => 'returned' as const),
      new Promise<'hung'>(resolve => { setTimeout(() => resolve('hung'), 10_000); }),
    ]);
    assert(outcome === 'returned', `${what}: the project restore never returned`);
  };

  stage('restore-hang:export');
  await db.projects.put(scratchProject('Archived title'));
  await db.diaryEntries.put({
    id: 'restore-hang-diary', projectId, entryDate: '2026-08-31T10:00',
    title: 'Archived page', content: '<p>archived</p>', tags: [], pinned: false,
    createdAt: now, updatedAt: now,
  });
  await db.aiProjectSettings.put({
    projectId, defaultPolicy: 'allow', remoteConsent: true,
    chatRoute: { connectionId: 'archived', modelId: 'archived-model' },
    updatedAt: now,
  });
  const withEngineRows = await archiveOf();

  // Everything the restore is supposed to undo: a rename, a page that is not
  // in the archive, and a copilot row that trusts a remote model.
  await db.projects.update(projectId, { title: 'Locally renamed' });
  await db.diaryEntries.delete('restore-hang-diary');
  await db.diaryEntries.put({
    id: 'restore-hang-stale', projectId, entryDate: '2026-08-31T18:00',
    title: 'Written after the export', content: '<p>stale</p>', tags: [],
    pinned: false, createdAt: now + 1, updatedAt: now + 1,
  });
  await db.aiProjectSettings.put({
    projectId, defaultPolicy: 'allow', remoteConsent: true,
    chatRoute: { connectionId: 'local', modelId: 'local-model' },
    imageRoute: { connectionId: 'local', modelId: 'local-painter' },
    updatedAt: now + 1,
  });

  stage('restore-hang:restore');
  await restore(withEngineRows, 'an archive carrying engine rows');

  assert(
    (await db.projects.get(projectId))?.title === 'Archived title',
    'the approved replacement did not restore the archived project',
  );
  assert(
    (await db.diaryEntries.get('restore-hang-diary'))?.title === 'Archived page',
    'a plain engine table did not come back from the archive',
  );
  assert(
    !(await db.diaryEntries.get('restore-hang-stale')),
    'a row written after the export survived the restore',
  );

  const restored = await db.aiProjectSettings.get(projectId);
  assert(restored?.chatRoute?.modelId === 'archived-model', 'the copilot settings row did not round-trip');
  assert(
    restored?.defaultPolicy === 'ask' && restored.remoteConsent === false,
    'the archive raised the local trust in a remote model',
  );
  assert(
    !restored?.imageRoute,
    'the restored project inherited the image route of its previous instance',
  );

  // Second pass: an archive with NO copilot row at all — every project
  // exported before the copilot existed is one. The row is keyed BY the
  // project, so Dexie keeps it out of `idxByName` and the generic
  // "every table with a projectId" sweep used to walk straight past it.
  stage('restore-hang:silentArchive');
  await db.aiProjectSettings.delete(projectId);
  const withoutCopilot = await archiveOf();
  await db.projects.update(projectId, { title: 'Locally renamed again' });
  await db.aiProjectSettings.put({
    projectId, defaultPolicy: 'allow', remoteConsent: true,
    chatRoute: { connectionId: 'local', modelId: 'left-behind' },
    updatedAt: now + 2,
  });

  await restore(withoutCopilot, 'an archive with no copilot row');
  assert(
    (await db.projects.get(projectId))?.title === 'Archived title',
    'the second replacement did not restore the archived project',
  );
  assert(
    !(await db.aiProjectSettings.get(projectId)),
    'a project restored from an archive that carries no copilot row kept the old one',
  );

  await db.diaryEntries.delete('restore-hang-diary');
  await db.projects.delete(projectId);
  passed.push('project ZIP restore writes engine rows inside its transaction and sweeps what the archive is silent about');
}

// Critical tests for the command-palette ranking added to
// `src/services/searchQuery.ts`. Splice into `tests/critical.browser.ts`:
// add `scoreSearchMatch` and `selectRankedMatches` to the existing
// `@/services/searchQuery` import, and call both functions from `run()` right
// after `testSearchQueryGrammar()`.

const RANK_DAY_MS = 86_400_000;

/**
 * The shape the index hands to the ranker: folded `title\nbody`, and where the
 * body starts in it. Built through the real folding so an accented title is
 * ranked the same way it is matched.
 */
function rankableDocument(title: string, body: string, updatedAt = 0): {
  haystack: string;
  bodyOffset: number;
  updatedAt: number;
} {
  const foldedTitle = foldSearchText(title);
  return {
    haystack: `${foldedTitle}\n${foldSearchText(body)}`,
    bodyOffset: foldedTitle.length + 1,
    updatedAt,
  };
}

async function testSearchRelevanceRanking(): Promise<void> {
  const now = Date.UTC(2026, 0, 15);
  const marta = parseSearchQuery('marta');

  // A title match beats a body match. This is the whole reason ranking exists:
  // scanning tables in order puts chapter three above the codex entry that is
  // literally named after the character.
  const titled = scoreSearchMatch(marta, rankableDocument('Marta', 'nada aqui'), now);
  const mentioned = scoreSearchMatch(
    marta,
    rankableDocument('Capítulo 3', 'marta cruzó el patio', now),
    now,
  );
  assert(titled > mentioned, 'a title match no longer outranks a body mention');

  // An exact word beats a fragment of a longer word, with neither in prefix
  // position so only the whole-word band separates them.
  const art = parseSearchQuery('art');
  const wholeWord = scoreSearchMatch(art, rankableDocument('el art de la guerra', ''), now);
  const fragment = scoreSearchMatch(art, rankableDocument('la cartografia', ''), now);
  assert(wholeWord > fragment, 'a whole word no longer outranks a substring');

  // Being exactly what the writer typed beats merely starting with it.
  const exact = scoreSearchMatch(marta, rankableDocument('Marta', ''), now);
  const prefixed = scoreSearchMatch(marta, rankableDocument('Marta Ruiz', ''), now);
  assert(exact > prefixed, 'an exact title no longer outranks a longer title');

  // Recency separates rows that are otherwise the same...
  const fresh = scoreSearchMatch(
    marta,
    rankableDocument('Capítulo 3', 'marta cruzó el patio', now - RANK_DAY_MS),
    now,
  );
  const stale = scoreSearchMatch(
    marta,
    rankableDocument('Capítulo 3', 'marta cruzó el patio', now - 400 * RANK_DAY_MS),
    now,
  );
  assert(fresh > stale, 'a recently edited row no longer outranks a stale one');

  // ...and never more than that: a chapter edited this morning must not push a
  // codex entry that carries the name in its title off the top of the palette.
  const staleTitle = scoreSearchMatch(
    marta,
    rankableDocument('Marta', 'ficha del personaje', now - 900 * RANK_DAY_MS),
    now,
  );
  assert(staleTitle > fresh, 'recency outranked a title match');

  // An accented title is ranked by the unaccented word the writer typed.
  const cancion = parseSearchQuery('cancion');
  assert(
    scoreSearchMatch(cancion, rankableDocument('La Canción', ''), now)
      > scoreSearchMatch(cancion, rankableDocument('Capítulo 9', 'la canción sonaba'), now),
    'folding stopped at matching and never reached ranking',
  );

  // A filters-only query names no word to weigh, so recency is the only order
  // it implies — and an undated row (a map pin) still scores, it just scores 0.
  const untagged = parseSearchQuery('is:untagged');
  assert(untagged.needles.length === 0, 'a filters-only query grew a needle');
  assert(
    scoreSearchMatch(untagged, rankableDocument('Pin', 'sin fecha', now), now)
      > scoreSearchMatch(untagged, rankableDocument('Pin', 'sin fecha'), now),
    'a filters-only query is not ordered by recency',
  );

  // Ranking runs on every keystroke's worth of half-typed queries, so an empty
  // document and a future timestamp both have to produce a number, not a throw.
  assert(
    typeof scoreSearchMatch(marta, rankableDocument('', ''), now) === 'number',
    'ranking an empty document did not return a score',
  );
  assert(
    scoreSearchMatch(marta, rankableDocument('Marta', '', now + 5 * RANK_DAY_MS), now)
      >= scoreSearchMatch(marta, rankableDocument('Marta', '', now), now),
    'a clock-skewed future timestamp scored below the present',
  );

  passed.push('search ranking: title over body, whole word over fragment, recency only as a tiebreaker');
}

async function testSearchResultPaging(): Promise<void> {
  const page = selectRankedMatches(
    [
      { id: 'low', engineId: 'writings', score: 10 },
      { id: 'high', engineId: 'writings', score: 90 },
      { id: 'mid', engineId: 'writings', score: 50 },
    ],
    3,
  );
  assert(
    page.map(item => item.id).join(',') === 'high,mid,low',
    'a page of matches is no longer ordered strongest first',
  );

  // The case this exists for: a protagonist's name in a long manuscript. Every
  // chapter outscores the codex entry, and without a reserved place the codex
  // section is not merely pushed down — it is not drawn at all, because the
  // palette only draws sections it has a row for.
  const flooded = selectRankedMatches(
    [
      { id: 'w1', engineId: 'writings', score: 400 },
      { id: 'w2', engineId: 'writings', score: 380 },
      { id: 'w3', engineId: 'writings', score: 360 },
      { id: 'w4', engineId: 'writings', score: 340 },
      { id: 'c1', engineId: 'codex', score: 120 },
      { id: 'n1', engineId: 'notes', score: 60 },
    ],
    3,
  );
  assert(flooded.length === 3, 'the page ignored its limit');
  assert(flooded.some(item => item.engineId === 'codex'), 'one loud engine took the whole page');
  assert(flooded.some(item => item.engineId === 'notes'), 'the last engine to match lost its place');
  assert(flooded[0].id === 'w1', 'the reserved places cost the strongest match its top spot');

  // Whatever survives is still ordered by score, so a caller that takes the
  // first hit — grounded answers, the AI bridge — takes the best one.
  const scores = flooded.map(item => item.score);
  assert(
    scores.every((score, index) => index === 0 || scores[index - 1] >= score),
    'the reserved places broke the score ordering',
  );

  // Equal scores keep the order the scan found them in: the same query on an
  // unchanged project must not shuffle its answer between keystrokes.
  const tied = selectRankedMatches(
    [
      { id: 'first', engineId: 'writings', score: 100 },
      { id: 'second', engineId: 'writings', score: 100 },
      { id: 'third', engineId: 'writings', score: 100 },
    ],
    2,
  );
  assert(tied.map(item => item.id).join(',') === 'first,second', 'tied matches are not ordered stably');

  assert(selectRankedMatches([{ id: 'a', engineId: 'notes', score: 1 }], 0).length === 0,
    'a zero-sized page returned rows');
  assert(selectRankedMatches([], 10).length === 0, 'an empty result set produced a page');
  assert(selectRankedMatches([{ id: 'a', engineId: 'notes', score: 1 }], 10).length === 1,
    'a result set smaller than the page was truncated');

  passed.push('search paging: best matches first, with a place kept for every engine that matched');
}

// A sprint stores its SCHEDULED end, never a countdown, so the app being shut
// across the finish line cannot turn a 25-minute sprint into a three-day one.
//
// Old bug: `endedAt` was already clamped, but the WORDS were `now - baseline`
// with nothing bounding `now`. A sprint that ended at 10:25 unwatched and was
// reconciled at 11:00 — after the copilot added a chapter at 10:40 — was logged
// with nine hundred words nobody typed inside it, and that number went on to be
// the "best sprint". A measurement taken long after the window is now ignored:
// the sprint is filed with the last total that was SEEN while it ran.
async function testExpiredSprintIsFiledAtItsScheduledEnd(): Promise<void> {
  const { beginSprint, listSprints, readActiveSprint, reconcileSprint } =
    await import('@/engines/writing-stats/sprints');
  const { PROJECT_SETTING_PREFIXES, getSetting, setSetting } = await import('@/db/operations');

  const projectId = 'sprint-window-project';
  const activeKey = `${PROJECT_SETTING_PREFIXES.activeSprint}${projectId}`;
  const settingsBefore = new Set((await db.settings.toArray()).map(row => row.key));

  // The chapter that arrived AFTER the sprint was over.
  await db.writings.add({
    id: 'sprint-late-chapter', projectId, title: 'Late arrival', status: 'draft',
    content: '<p>x</p>', wordCount: 900, tags: [], createdAt: 1, updatedAt: 1,
  });

  // Backdating a real sprint rather than hand-writing the payload keeps the
  // stored shape whatever this module currently writes.
  const backdate = async (endsAt: number, startedAt: number, observedWords: number, observedAt: number) => {
    const raw = await getSetting(activeKey);
    assert(raw, 'beginSprint did not persist an active sprint');
    const payload = JSON.parse(raw) as { sprint: Record<string, unknown> };
    assert(payload.sprint, 'the stored active-sprint payload changed shape');
    payload.sprint.startedAt = startedAt;
    payload.sprint.endsAt = endsAt;
    payload.sprint.baselineWords = 100;
    payload.sprint.observedWords = observedWords;
    payload.sprint.observedAt = observedAt;
    await setSetting(activeKey, JSON.stringify(payload));
  };

  // ── Reconciled long after the window: the late words are not credited ──
  await beginSprint({ projectId, durationMinutes: 25, targetWords: 0, baselineWords: 100 });
  const lateNow = Date.now();
  const scheduledEnd = lateNow - 10 * 60_000;
  const scheduledStart = scheduledEnd - 25 * 60_000;
  // 140 words were on the page the last time anyone looked, inside the window.
  await backdate(scheduledEnd, scheduledStart, 140, scheduledEnd - 1_000);

  const late = await reconcileSprint(projectId);
  const lateRecord = late.finished;
  assert(late.active === null, 'an expired sprint was left running');
  assert(lateRecord, 'an expired sprint was not filed');
  assert(
    lateRecord.endedAt === scheduledEnd,
    `the sprint was filed at ${lateRecord.endedAt}, not at its scheduled end ${scheduledEnd}`,
  );
  assert(
    lateRecord.actualWords === 40,
    `a reconcile long after the window credited ${lateRecord.actualWords} words instead of the 40 that were seen inside it`,
  );
  assert(lateRecord.startedAt === scheduledStart, 'the filed sprint lost its start');
  assert(await readActiveSprint(projectId) === null, 'the filed sprint is still the active one');

  // ── Reconciled inside the grace window: the measurement IS used ──
  await beginSprint({ projectId, durationMinutes: 25, targetWords: 0, baselineWords: 100 });
  const freshNow = Date.now();
  const justEnded = freshNow - 1_000;
  await backdate(justEnded, justEnded - 60_000, 100, justEnded - 60_000);

  const fresh = await reconcileSprint(projectId, 175);
  const freshRecord = fresh.finished;
  assert(freshRecord, 'a sprint that expired a second ago was not filed');
  assert(
    freshRecord.actualWords === 75,
    `a measurement taken inside the grace window must still count, got ${freshRecord.actualWords}`,
  );
  assert(
    freshRecord.endedAt === justEnded,
    'even a promptly reconciled sprint is stamped with its scheduled end, not with the reconcile',
  );

  const log = await listSprints(projectId);
  assert(log.length === 2, `both sprints must be in the log, found ${log.length}`);
  assert(
    log.some(row => row.id === lateRecord.id) && log.some(row => row.id === freshRecord.id),
    'filing the second sprint dropped the first from the log',
  );

  await db.writings.delete('sprint-late-chapter');
  const settingsAfter = await db.settings.toArray();
  await db.settings.bulkDelete(
    settingsAfter.filter(row => !settingsBefore.has(row.key)).map(row => row.id),
  );
  passed.push('an expired sprint is filed at its scheduled end and credited only with the words seen inside it');
}

// Stored prose is HTML, and a string replace over it corrupts tags and matches
// inside attributes. The HTML is parsed and only TEXT NODES are rewritten, so
// `<strong>` boundaries and `<a href>` values are untouched by construction —
// and a match that formatting cuts in two is deliberately NOT rewritten,
// because neither half can be given the mark without moving a boundary the
// writer chose. Nothing is rewritten until a version has been saved.
async function testProjectReplaceRewritesTextNodesOnly(): Promise<void> {
  const { applyProjectReplace, forgetReplaceUndo, scanProjectReplace } =
    await import('@/services/projectReplace');

  const projectId = 'replace-html-project';
  const now = Date.now();
  const marks = '<p>Marta y <strong>Marta</strong></p>';
  const attribute = '<p><a href="/x/Marta">Marta</a></p>';
  // One plain occurrence and one the bold cuts in half, in the same field.
  const split = '<p>Marta llega. Mar<strong>ta</strong> se va.</p>';
  const ids = ['replace-marks', 'replace-attribute', 'replace-split'];
  await db.writings.bulkAdd([
    { id: ids[0], projectId, title: 'Capítulo uno', status: 'draft', content: marks, wordCount: 3, chapter: 1, tags: [], createdAt: now, updatedAt: now },
    { id: ids[1], projectId, title: 'Capítulo dos', status: 'draft', content: attribute, wordCount: 1, chapter: 2, tags: [], createdAt: now, updatedAt: now },
    { id: ids[2], projectId, title: 'Capítulo tres', status: 'draft', content: split, wordCount: 6, chapter: 3, tags: [], createdAt: now, updatedAt: now },
  ]);

  const plan = await scanProjectReplace({
    projectId,
    term: 'Marta',
    options: { caseSensitive: false, wholeWord: false, matchDiacritics: false },
    scopes: ['writings'],
  });
  assert(plan.total === 4, `expected four rewritable occurrences, got ${plan.total}`);
  assert(plan.splitTotal === 1, `expected one occurrence cut by formatting, got ${plan.splitTotal}`);
  assert(plan.documents.length === 3, `expected three chapters in the preview, got ${plan.documents.length}`);

  const attributeDocument = plan.documents.find(entry => entry.key === `writings:${ids[1]}`);
  assert(attributeDocument?.total === 1, 'the term inside the href was counted as an occurrence');
  const splitDocument = plan.documents.find(entry => entry.key === `writings:${ids[2]}`);
  assert(splitDocument?.total === 1, 'the plain occurrence beside a split one was not offered');
  assert(splitDocument.splitTotal === 1, 'a match cut by a mark was counted as rewritable');
  assert(
    splitDocument.occurrences.filter(occurrence => occurrence.split).length === 1,
    'the split occurrence was not reported to the writer as split',
  );

  const outcome = await applyProjectReplace(plan, 'Clara', {
    excludedDocuments: new Set<string>(),
    excludedOccurrences: new Set<string>(),
  });
  assert(outcome.replaced === 4, `expected four rewrites, got ${outcome.replaced}`);
  assert(outcome.rows === 3 && outcome.documents === 3, 'the rewritten row or document count changed');
  assert(outcome.snapshots === 3, 'a chapter was rewritten without a version being saved first');
  assert(outcome.skippedChanged === 0, 'a chapter nothing touched was reported as changed under the review');

  assert(
    (await db.writings.get(ids[0]))?.content === '<p>Clara y <strong>Clara</strong></p>',
    'rewriting either side of a mark boundary corrupted the markup',
  );
  const attributeAfter = (await db.writings.get(ids[1]))?.content ?? '';
  assert(attributeAfter.includes('href="/x/Marta"'), 'the replacement reached inside an attribute');
  assert(attributeAfter.includes('>Clara<'), 'the visible link text was not rewritten');
  assert(
    (await db.writings.get(ids[2]))?.content === '<p>Clara llega. Mar<strong>ta</strong> se va.</p>',
    'the occurrence a mark cuts in two was rewritten, or its neighbour was not',
  );

  const versions = await db.writingSnapshots.where('writingId').equals(ids[0]).toArray();
  assert(versions.length === 1 && versions[0].content === marks, 'the saved version does not hold the text as it was before the replace');
  assert(versions[0].reason === 'manual', 'the restore point was filed under a reason the history panel does not offer');

  forgetReplaceUndo(outcome.batchId);
  await db.writingSnapshots.where('writingId').anyOf(ids).delete();
  await db.writings.bulkDelete(ids);
  passed.push('project replace rewrites text nodes only: marks survive, attributes are untouched, split matches are left alone');
}

// Retry is decided from the STORED rows alone, so it works on a thread reopened
// days later as well as on one that failed a second ago. A turn is the last
// user row plus everything after it, and a retry replays that user row — it
// never sends the question twice — after deleting exactly the rows that turn
// left behind. A turn that produced a real answer offers no Retry at all:
// pressing it there would delete something the writer wants to keep.
async function testCopilotRetryPlan(): Promise<void> {
  const { planCopilotRetry } = await import('@/services/copilot/runner');
  const row = (
    id: string,
    role: AiMessage['role'],
    status: AiMessage['status'],
    content: string,
    toolCall?: AiMessage['toolCall'],
  ): AiMessage => ({
    id,
    threadId: 'retry-thread',
    projectId: 'retry-project',
    role,
    status,
    content,
    createdAt: 1,
    toolCall,
  });
  const card = (state: 'done' | 'failed' | 'rejected'): NonNullable<AiMessage['toolCall']> => ({
    callId: 'call-1', tool: 'writings.update', args: {}, risk: 'write', state,
  });
  const question = row('u1', 'user', 'complete', '¿Puedes revisar el capítulo?');

  // The model errored: replayable, and the failed row carries the control.
  const errored = planCopilotRetry([question, row('a1', 'assistant', 'error', '')]);
  assert(errored, 'a turn whose answer errored must be replayable');
  assert(errored.userMessageId === 'u1' && errored.text === question.content, 'the retry must replay the stored user row');
  assert(errored.dropIds.join(',') === 'a1', 'the retry must drop the failed answer and nothing else');
  assert(errored.anchorMessageId === 'a1', 'the Retry control lost the row that shows the failure');

  // Cancelled mid-turn: the whole turn goes, the question stays.
  const cancelled = planCopilotRetry([
    question,
    row('a1', 'assistant', 'complete', ''),
    row('t1', 'tool', 'complete', 'ok', card('done')),
    row('a2', 'assistant', 'cancelled', ''),
  ]);
  assert(cancelled?.dropIds.join(',') === 'a1,t1,a2', 'a cancelled turn must drop every row it left behind');
  assert(!cancelled.dropIds.includes('u1'), 'the retry must never drop the question it replays');
  assert(cancelled.anchorMessageId === 'a2', 'the Retry control lost the cancelled row');

  // Cut between a tool call and the answer: replayable, but nothing visible
  // failed, so the control hangs off no row rather than above the failure.
  const rejected = planCopilotRetry([
    question,
    row('a1', 'assistant', 'complete', 'Voy a reescribir el final.'),
    row('t1', 'tool', 'complete', 'rechazado', card('rejected')),
  ]);
  assert(rejected?.dropIds.join(',') === 'a1,t1', 'a turn ending on a rejected tool card must be replayable');
  assert(rejected.anchorMessageId === null, 'a turn with no visibly failed row must not anchor the control');

  // A real answer is never offered a Retry — it would delete the answer.
  assert(
    planCopilotRetry([question, row('a1', 'assistant', 'complete', 'Aquí tienes la revisión.')]) === null,
    'a turn that answered was offered a retry that would delete the answer',
  );
  assert(
    planCopilotRetry([
      question,
      row('a1', 'assistant', 'complete', 'Hecho.'),
      row('t1', 'tool', 'complete', 'ok', card('done')),
    ]) === null,
    'a turn that answered and then ran a tool successfully was offered a retry',
  );

  // A live run settles itself; a turn with no answer at all is replayable.
  assert(
    planCopilotRetry([question, row('a1', 'assistant', 'streaming', 'escribi')]) === null,
    'a streaming row belongs to a live run and must not be retried under it',
  );
  const unanswered = planCopilotRetry([question]);
  assert(unanswered, 'a turn stopped before the model answered must be replayable');
  assert(unanswered.dropIds.length === 0, 'a turn that never got an answer has nothing to drop');
  assert(unanswered.userMessageId === 'u1', 'the retry must replay the question that got no answer');
  assert(planCopilotRetry([]) === null, 'an empty thread cannot be retried');

  passed.push('copilot retry plan: failed turns replay the stored question and name exactly the rows to drop');
}

function testSearchQueryGrammar(): void {
  // Accent folding runs on BOTH sides: this app's writers work in Spanish, and
  // "cancion" has to find "canción" without the writer reaching for the accent.
  assert(foldSearchText('Canción') === 'cancion', 'folding did not strip the accent');
  assert(foldSearchText('ÁÉÍÓÚñ') === 'aeiouñ' || foldSearchText('ÁÉÍÓÚñ') === 'aeioun',
    'folding mangled accented capitals');

  const plain = parseSearchQuery('canción  MARTA');
  assert(plain.terms.length === 2 && plain.terms.includes('cancion') && plain.terms.includes('marta'),
    'bare words were not folded into terms');
  assert(findRequiredMatch(plain, 'la cancion de marta') !== null, 'AND over folded words failed');
  assert(findRequiredMatch(plain, 'la cancion') === null, 'a missing word still matched');

  // The longest needle is looked up first — that ordering is what makes a
  // non-matching document cheap, so it is a contract, not an accident.
  assert(plain.needles.length > 0 && plain.needles[0].length >= plain.needles[plain.needles.length - 1].length,
    'needles are no longer ordered longest-first');

  const phrase = parseSearchQuery('"la torre negra"');
  assert(phrase.phrases.length === 1 && phrase.terms.length === 0, 'a quoted phrase was split into words');
  assert(findRequiredMatch(phrase, 'subio a la torre negra al alba') !== null, 'phrase did not match');
  assert(findRequiredMatch(phrase, 'la torre era negra') === null, 'phrase matched non-contiguously');

  const excluded = parseSearchQuery('torre -negra');
  assert(excluded.exclusions.includes('negra'), 'exclusion was not parsed');
  assert(hasExcludedText(excluded, 'la torre negra'), 'exclusion did not disqualify');
  assert(!hasExcludedText(excluded, 'la torre blanca'), 'exclusion disqualified the wrong document');

  const filtered = parseSearchQuery('engine:codex tag:magia is:untagged');
  assert(filtered.hasEngineFilters && filtered.hasTagFilters, 'field filters were not recognised');
  assert(filtered.untagged === true, 'is:untagged was not parsed');

  // An unknown prefix is literal text, not a silently dropped filter: someone
  // searching for a URL or for "nota:" must still find it.
  const literal = parseSearchQuery('nota:algo');
  assert(!literal.hasFilters && literal.hasText, 'an unknown field: prefix was swallowed');
  assert(findRequiredMatch(literal, 'una nota:algo suelta') !== null, 'literal prefix did not match');

  // Malformed input must never throw — an unterminated quote just runs on.
  const unterminated = parseSearchQuery('"sin cerrar');
  assert(unterminated.phrases.length === 1, 'an unterminated quote was not treated as a phrase');
  assert(parseSearchQuery('').isEmpty, 'an empty query is not empty');

  passed.push('search grammar: folding, phrases, exclusions, filters, literal fallback');
}

async function run(): Promise<void> {
  await testMigration();
  await testBackupRoundTrip();
  await testProjectImportCollisionGuard();
  await testCascades();
  await testCopilotRunGuards();
  await testImageHandoffStore();
  await testScriptImportRoundTrip();
  await testAiTextParsing();
  testProjectIntelligenceSemantics();
  testNarrativeContinuitySemantics();
  testLightweightWorldgenRenameReader();
  await testOutlineBeatDeepLink();
  testEditorialNavigationContracts();
  testPersistedHtmlSanitizer();
  testSearchQueryGrammar();
  await testPublishingStudioSemantics();
  testRecoveryAndNavigation();
  testRecentEntityNavigation();
  await testReorderKeepsUnlistedRows();
  await testEntityAnnotationCascades();
  await testOutlineCoverageIgnoresDeletedWritings();
  await testCitationAccessedDayIsLocal();
  await testCopilotSettingsPartialSaves();
  await testLegacyFullImportKeepsTablesItDoesNotCarry();
  await testWritingDeleteIsRestorable();
  await testConcurrentSettingUpdatesBothSurvive();
  await testProjectSweepsItsSettingsKeys();
  await testDisappearingCharactersReadsProseOnly();
  await testOutlineChecksCollapseWhenNothingIsLinkedYet();
  await testReadingProgressCountsWhatIsOnScreen();
  await testOrphanSeedClosesInOneStep();
  await testChapterOrderPlans();
  await testWritingABeatCreatesOneLinkedChapter();
  await testPublishingOrderMatchesTheList();
  await testPublishingMarkupAndEncoding();
  await testPublishingEdgeManuscripts();
  await testProjectRestoreCarriesEngineRows();
  await testSearchRelevanceRanking();
  await testSearchResultPaging();
  await testExpiredSprintIsFiledAtItsScheduledEnd();
  await testProjectReplaceRewritesTextNodesOnly();
  await testCopilotRetryPlan();
  passed.push(await testAiBridgeContracts());
  passed.push(await testAiRuntimeContracts());
  passed.push(testWorldgenSpatialEntities());
  passed.push(testWorldgenSemanticZoom());
  await runRegionInfraTests();
  passed.push('Worldgen regional identity, coordinates, cache, and cancellation');
  passed.push(testWorldgenDetailShader());
  passed.push(await testWorldgenBridgeAccess());
}

void run()
  .then(() => {
    window.__criticalResult = { ok: true, tests: passed };
  })
  .catch(error => {
    window.__criticalResult = {
      ok: false,
      tests: passed,
      error: error instanceof Error ? error.stack || error.message : String(error),
    };
  })
  .finally(() => {
    void db.close();
  });

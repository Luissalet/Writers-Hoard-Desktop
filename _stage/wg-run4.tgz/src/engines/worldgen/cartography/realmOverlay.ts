// ============================================
// World Generator — realm borders, as screen polylines
// ============================================
// The Carta has drawn political boundaries since it existed; the 2D map, which
// is the view where realms can actually be renamed and where their capitals are
// placed, has never drawn them at all.
//
// The Carta's `drawBorders` re-derives the boundary from `realmOf` on every
// render, scanning every cell of the visible rect. That is affordable for a
// sheet that settles; it is not affordable for a canvas that redraws on every
// frame of a pan, where the visible rect at planetary zoom IS the whole grid —
// two million realm lookups per frame.
//
// So the boundary is extracted ONCE per geography into a segment list. A border
// is a perimeter, not an area: a world of a hundred and sixty towns comes out at
// a few thousand segments, which is nothing to project per frame. The extraction
// is keyed on the geography object itself, so a rebuild after a stroke gets a
// fresh one and nothing else pays.

import type { HumanGeography } from '../core/settlements';

/** Cell-corner coordinates: cell (x, y) spans [x, x+1) × [y, y+1). */
export interface BorderSegments {
  /** Flat runs of x0, y0, x1, y1 — one segment per four entries. */
  xy: Float32Array;
  /** Hue 0–360 of the more senior realm at each segment. */
  hue: Uint16Array;
  count: number;
}

/**
 * Keyed on `realmOf`, NOT on the geography wrapper.
 *
 * `patchGeography` builds a new `HumanGeography` object after every stroke and
 * hands back the SAME `realmOf` array — realms are not re-grown by a patch. On
 * the wrapper, the first frame after every brush stroke paid a fresh two-pass
 * scan of the whole grid (16 ms at 1024x512, ~60 ms at 2048x1024) from inside
 * a requestAnimationFrame callback, which is precisely when the reader has just
 * let go of the brush and is looking for it to feel quick.
 */
const CACHE = new WeakMap<Int32Array, BorderSegments>();

/**
 * Every edge where two realms meet, or where a realm meets unclaimed ground.
 *
 * Only the right and bottom edge of each cell are tested, which is the standard
 * way to visit every interior edge exactly once. The east–west wrap is included
 * (a realm that straddles the antimeridian has a real boundary there, not a
 * seam), and the south edge of the last row is not, because there is nothing
 * below it.
 */
export function realmBorders(world: { width: number; height: number }, geo: HumanGeography): BorderSegments {
  const cached = CACHE.get(geo.realmOf);
  if (cached) return cached;
  const W = world.width, H = world.height;
  const of = geo.realmOf;
  // Two passes: count, then fill. Growing a JS array of a few thousand entries
  // is fine, but the typed arrays are what make the per-frame projection cheap.
  let n = 0;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const a = of[i];
      if (a !== of[y * W + ((x + 1) % W)]) n++;
      if (y < H - 1 && a !== of[i + W]) n++;
    }
  }
  const xy = new Float32Array(n * 4);
  const hue = new Uint16Array(n);
  let k = 0;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const a = of[i];
      const r = of[y * W + ((x + 1) % W)];
      const d = y < H - 1 ? of[i + W] : a;
      if (a !== r) {
        xy[k * 4] = x + 1; xy[k * 4 + 1] = y;
        xy[k * 4 + 2] = x + 1; xy[k * 4 + 3] = y + 1;
        hue[k] = geo.realms[Math.max(a, r)]?.hue ?? 0;
        k++;
      }
      if (y < H - 1 && a !== d) {
        xy[k * 4] = x; xy[k * 4 + 1] = y + 1;
        xy[k * 4 + 2] = x + 1; xy[k * 4 + 3] = y + 1;
        hue[k] = geo.realms[Math.max(a, d)]?.hue ?? 0;
        k++;
      }
    }
  }
  const out: BorderSegments = { xy, hue, count: k };
  CACHE.set(geo.realmOf, out);
  return out;
}

export interface RealmOverlayOptions {
  worldWidth: number;
  worldHeight: number;
  /** Map coords (u east 0..1, v south 0..1) → screen pixels, for ONE copy. */
  toScreen: (u: number, v: number) => [number, number];
  width: number;
  height: number;
  /** Screen pixels per world cell — sets the weight and the visible-cell cull. */
  pxPerCell: number;
  /** World-cell rect on screen, for rejecting segments without projecting them. */
  view: { x: number; y: number; w: number; h: number };
  alpha?: number;
}

type Ctx = CanvasRenderingContext2D;

/**
 * Draw the boundary.
 *
 * Lines only — no political wash. The Carta tints because it is a drawn map on
 * paper; the 2D is photographic ground, and a translucent colour field over it
 * reads as haze rather than as a country. The line carries the realm's hue, so
 * two neighbours are still told apart.
 *
 * Segments are culled in CELL space before anything is projected, which is what
 * keeps a curved projection from paying a Robinson solve per off-screen edge.
 */
export function drawRealmBorders(
  ctx: Ctx,
  segs: BorderSegments,
  opts: RealmOverlayOptions,
): number {
  const alpha = opts.alpha ?? 1;
  if (alpha <= 0.01 || segs.count === 0) return 0;
  const { worldWidth: W, worldHeight: H, toScreen, view } = opts;
  // One cell of slack, plus the wrap: a segment at x=W is the same edge as x=0.
  const x0 = view.x - 1, x1 = view.x + view.w + 1;
  const y0 = view.y - 1, y1 = view.y + view.h + 1;
  /**
   * `view` is THIS COPY's window, in this copy's own cell coordinates.
   *
   * The first version took one window for the whole map and skipped the cull
   * whenever it spanned the world — which, because `fit()` sizes the map to 98 %
   * of the canvas, is the view the map OPENS in. Every segment was then
   * projected once per east–west copy: measured on the harness world (9 939
   * segments, 1400×800, three copies) at **15,4 ms per frame**, on every frame
   * of every pan.
   *
   * A copy at screen offset `ox` shows cells `x ∈ [-ox/scale, (cw-ox)/scale]`,
   * so each copy has its own window and the cull is a plain range test with no
   * modulo and no special case. Total work across the copies is then the
   * segments that are actually on screen, once.
   */

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.lineCap = 'round';
  ctx.lineWidth = Math.max(1, Math.min(2.6, 0.9 + opts.pxPerCell * 0.06));
  ctx.setLineDash([Math.max(3, opts.pxPerCell * 1.2), Math.max(2.5, opts.pxPerCell * 0.9)]);

  // Batched by hue: a `beginPath`/`stroke` per segment is a state change per
  // edge, and there are thousands. Ten or so realms means ten strokes.
  const byHue = new Map<number, number[]>();
  let drawn = 0;
  for (let k = 0; k < segs.count; k++) {
    const ax = segs.xy[k * 4], ay = segs.xy[k * 4 + 1];
    const by = segs.xy[k * 4 + 3];
    if (ay > y1 || by < y0) continue;
    if (ax < x0 || ax > x1) continue;
    let list = byHue.get(segs.hue[k]);
    if (!list) { list = []; byHue.set(segs.hue[k], list); }
    list.push(k);
    drawn++;
  }

  for (const [h, list] of byHue) {
    ctx.strokeStyle = `hsl(${h} 62% 62%)`;
    ctx.beginPath();
    for (const k of list) {
      const [sx0, sy0] = toScreen(segs.xy[k * 4] / W, segs.xy[k * 4 + 1] / H);
      const [sx1, sy1] = toScreen(segs.xy[k * 4 + 2] / W, segs.xy[k * 4 + 3] / H);
      ctx.moveTo(sx0, sy0);
      ctx.lineTo(sx1, sy1);
    }
    ctx.stroke();
  }

  ctx.setLineDash([]);
  ctx.globalAlpha = 1;
  ctx.restore();
  return drawn;
}
